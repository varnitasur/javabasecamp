package service.serviceimpl;

import java.util.Set;

import dao.daoimpl.StudentDaoImpl;
import entity.Student;
import service.StudentService;

public class StudentServiceImpl implements StudentService {

	static StudentDaoImpl ds=new StudentDaoImpl();
	@Override
	public boolean isInsertedfromclient(Set<Student> students) {
		
		boolean isVal=ds.insertStudentToDB(students);
		return isVal;
	}

	//@Override
	/*public Set<Student> gellalldatafromdao() {
		Set<Student> result=ds.getalldatafromdao();
		return result;
	}*/

}
