package service;

import java.util.Set;

import entity.Student;

public interface StudentService {

	boolean isInsertedfromclient(Set<Student> students);
	//Set<Student> gellalldatafromdao();
	
}
