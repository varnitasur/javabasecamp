package dao.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import dao.Studentdao;
import dbUtility.DBUtility;
import entity.Student;

public class StudentDaoImpl implements Studentdao {

	static DBUtility obj=new DBUtility();
	@Override
	public boolean insertStudentToDB(Set<Student> students) {
		//step 1: create conection
		Connection con=obj.getConnection();
		boolean val= false;
		int count=0;
		//step 2:create query
		String query="insert into students (studentname,studentadd) values (?,?);";
		//step 3:choose statement
		 PreparedStatement preparedst=null;
		 
		 try {
			preparedst=con.prepareStatement(query);
			
			for (Student student : students) {
				preparedst.setString(1, student.getStudentname());
				preparedst.setString(2,student.getStudentadd());
				count++;
				preparedst.executeUpdate();
				//2preparedst.getGeneratedKeys();
				
			}
			
			if(count !=0)
			{
				val=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return val;
	}
	/*@Override
	public Set<Student> getalldatafromdao() {
		Connection con=obj.getConnection();
		String query="select * from students";
		Statement st=null;
		ResultSet rs=null;
		Set<Student> result=new HashSet<>();
		try {
			 st=con.createStatement();
			rs=st.executeQuery(query);
			while(rs.next())
			{
				String name=rs.getString(2);
				String add=rs.getString(3);
				Student student=new Student();
				student.setStudentname(name);
				student.setStudentadd(add);
				result.add(student);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}*/

	
}
