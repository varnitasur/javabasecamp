package dao;

import java.util.Set;

import entity.Student;

public interface Studentdao {

	//insert the values of student
	boolean insertStudentToDB(Set<Student> students);
	//get all data from dao
	//Set<Student> getalldatafromdao();
	
}
