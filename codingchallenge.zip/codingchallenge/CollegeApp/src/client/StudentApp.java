package client;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import entity.Student;
import service.serviceimpl.StudentServiceImpl;

public class StudentApp {

	static Scanner sc=new Scanner(System.in);
	static StudentServiceImpl sd=new StudentServiceImpl();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Set<Student> students=createStudent();
		boolean val=sd.isInsertedfromclient(students);
		if(val)
		{
			System.out.println("Inserted succesfully");
		}
		else
			System.out.println("not inserted");
		
		/*System.out.println("=================================================");
		for (Student student : students) {
			System.out.println("Student id: "+student.getStudentroll());
			System.out.println("Student Name: "+student.getStudentname());
			System.out.println("Student add: "+student.getStudentadd());
		}*/

	}

	private static Set<Student> createStudent() {
		Set<Student> result=new HashSet<>();
		
		Student student= new Student();
			System.out.println("Enter the no of students");
			int studentcount=sc.nextInt();
			System.out.println("Enter the student roll");
			int roll=sc.nextInt();
			student.setStudentroll(roll);
			System.out.println("Enter the student name");
			String name=sc.next();
			System.out.println("Enter the student address");
			student.setStudentname(name);
			String address=sc.next();
			student.setStudentadd(address);
			result.add(student);
			for (int i = 1; i < studentcount; i++) {
			System.out.println("Enter the student name");
			String sname=sc.next();
			System.out.println("Enter the student address");
			String saddress=sc.next();
			Student student1 =new Student();
			student.setStudentname(sname);
			student.setStudentadd(saddress);
			result.add(student1);
		}
		
		return result;
	}

}
