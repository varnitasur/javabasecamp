package entity;

public class Student {
	 private int studentroll;
	 private String studentname;
	 private String studentadd;
	 
	public Student() {
		super();
		
	}

	public Student(int studentroll, String studentname, String studentadd) {
		super();
		this.studentroll = studentroll;
		this.studentname = studentname;
		this.studentadd = studentadd;
	}

	public int getStudentroll() {
		return studentroll;
	}

	public void setStudentroll(int studentroll) {
		this.studentroll = studentroll;
	}

	public String getStudentname() {
		return studentname;
	}

	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}

	public String getStudentadd() {
		return studentadd;
	}

	public void setStudentadd(String studentadd) {
		this.studentadd = studentadd;
	}

	
}
