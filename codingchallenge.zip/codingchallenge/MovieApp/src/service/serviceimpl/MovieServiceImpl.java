package service.serviceimpl;

import java.util.Set;

import dao.daoimpl.MovieDaoImpl;
import entity.Actor;
import entity.Movie;
import service.MovieService;

public class MovieServiceImpl implements MovieService {

	MovieDaoImpl obj=new MovieDaoImpl();

	@Override
	public Set<Actor> getalltheactorbymoviesid() {
		
		return null;
	}


	@Override
	public Set<Actor> getalltheactorbymoviesid(String moviename) {
		Set<Actor> result=obj.getallactordetailsfromdao(moviename);
		return result ;
	}

	@Override
	public Set<Movie> getallmoviesbybudget() {
		Set<Movie> result=obj.getallmoviesdetailsbybudget();
		return result;
	}

	@Override
	public int getallmoviescount() {
		int result=obj.countallmoviesgreaterthan1();
		return result;
	}

	@Override
	public Set<Movie> getallthemoviesbyactorid(String actorname) {
		Set<Movie> result=obj.getallmoviesfromdao(actorname);
		return result;
	}


	@Override
	public Set<Movie> getallthemoviesbyactorid() {
		Set<Movie> result=obj.getallmoviesfromdao();
		return null;
	}
}
