package service;

import java.util.Set;

import entity.Actor;
import entity.Movie;

public interface MovieService {

	//get all the list of movies by actor id
	Set<Movie> getallthemoviesbyactorid(String actorname);
	
	
	Set<Movie> getallthemoviesbyactorid();
	
	
	//get all the list of actor by movies id
	Set<Actor> getalltheactorbymoviesid();
	
	Set<Actor> getalltheactorbymoviesid(String moviename);
	
	Set<Movie> getallmoviesbybudget();
	
	int getallmoviescount();
	
}
