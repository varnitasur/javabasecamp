package dao;

import java.util.Set;

import entity.Actor;
import entity.Movie;

public interface MovieDao {

	Set<Movie> getallmoviesfromdao();
	//get all list of movies done by a particular actor
	Set<Movie> getallmoviesfromdao(String actorname);
	// list all the actor of a particular movie
	Set<Actor> getallactorsdetailsfromdao();
	Set<Actor> getallactordetailsfromdao(String moviename);
	Set<Movie> getallmoviesdetailsbybudget();
	 int countallmoviesgreaterthan1(); 
	
}
