package dao.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import dao.MovieDao;
import dbUtility.DBUtility;
import entity.Actor;
import entity.Movie;

public class MovieDaoImpl implements MovieDao {

	static DBUtility obj= new DBUtility();
	@Override
	public Set<Actor> getallactorsdetailsfromdao() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Set<Movie> getallmoviesfromdao(String actorname) {
		//step 1:create connection
		Connection con=obj.getConnection();
		//step 2:crete query
		PreparedStatement st=null;
		ResultSet rs=null;
		String query=" Select actor_id from actors where actor_name = '"+actorname+"'";
		//System.out.println("excutd");
		int id=0;
		Set<Movie> movies=new HashSet<>();
		try {
			
			st=con.prepareStatement(query);
			//step 4:execute query
			rs=st.executeQuery();
			while(rs.next())
			{
				 id=rs.getInt(1);
				 System.out.println(id);
			}
			String query1= "select *  from movies inner join bridge on movies.movie_id=bridge.movie_id where actor_id= "+id+"";
			PreparedStatement st1=null;
			ResultSet rs1=null;
			st1=con.prepareStatement(query1);
			rs1=st1.executeQuery();
			while(rs1.next())
			{
				int id1=rs1.getInt(1);
				String name=rs1.getString(2);
				int budget=rs1.getInt(3);
				Movie movie=new Movie(id1, name, budget);
				movies.add(movie);
				
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		return movies;
	}
	@Override
	public Set<Actor> getallactordetailsfromdao(String moviename) {
		//step 1:Connection create
		Connection con=obj.getConnection();
		//step 2:crete query
		PreparedStatement st=null;
		ResultSet rs=null;
		String query=" Select movie_id from movies where movie_name = '"+moviename+"'";
		//System.out.println("excutd");
		int id=0;
		Set<Actor> actors=new HashSet<>();
		try {
			//System.out.println("try");
			st=con.prepareStatement(query);
			//System.out.println("sf");
			//step 4:execute query
			rs=st.executeQuery();
			//System.out.println("s");
			while(rs.next())
			{
				 id=rs.getInt(1);
				 System.out.println(id);
			}
			String query1= "select *  from actors inner join bridge on actors.actor_id=bridge.actor_id where movie_id= "+id+"";
			PreparedStatement st1=null;
			ResultSet rs1=null;
			st1=con.prepareStatement(query1);
			rs1=st1.executeQuery();
			while(rs1.next())
			{
				int id1=rs1.getInt(1);
				String name=rs1.getString(2);
				Actor actor=new Actor(id1, name);
				actors.add(actor);
				
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
		return actors;
	}



	@Override
	public Set<Movie> getallmoviesdetailsbybudget() {
		//step 1:create connection
		Connection con=obj.getConnection();
		//step 2:crete query
		String query="select * from movies where movie_budget>=5000;";
		Statement st=null;
		ResultSet rs=null;
		Set<Movie> result=new HashSet<>();
		try {
			st=con.createStatement();
			rs=st.executeQuery(query);
			
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				int budget=rs.getInt(3);
				Movie movie=new Movie(id, name, budget);
				result.add(movie);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}


	@Override
	public int countallmoviesgreaterthan1() {
		int result=0;
		//step 1:create connection
		Connection con=obj.getConnection();
		//step 2:create query
		String query="select count(*) from (select actor_id,count(actor_id) as total_movie from bridge group by actor_id having count(actor_id)=1) a;";
		Statement st=null;
		ResultSet rs=null;
		try {
			st=con.createStatement();
			rs=st.executeQuery(query);
			while(rs.next())
			{
				result=rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
	@Override
	public Set<Movie> getallmoviesfromdao() {
		// TODO Auto-generated method stub
		return null;
	}



	

}
