package client;

import java.util.Scanner;
import java.util.Set;

import dao.daoimpl.MovieDaoImpl;
import entity.Actor;
import entity.Movie;
import service.serviceimpl.MovieServiceImpl;

public class MovieApp {

	static MovieDaoImpl ms =new MovieDaoImpl();
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		int f;	int choice;
		do
			{
			System.out.println("Enter 1.List all the movies done by a particular actor\r\n "+
					"2.	List all the actors in a particular movie.\r\n" + 
					"3.	List all the movies having budget greater than 5000 \r\n" + 
					"4.	Count the actors who have done only one movie.\r\n");
			System.out.println("Enter your choice");
			choice=sc.nextInt();
			switch(choice)
			{
				
			case 1:	System.out.println("Enter the name of the actor");
				String actorname=sc.next();
				Set<Movie> result=ms.getallmoviesfromdao(actorname);
				for (Movie movie : result) {
					System.out.println("Movie id :"+movie.getMovieid());
					System.out.println("Movie name :"+movie.getMoviename());
					System.out.println("Movie budget :"+movie.getMoviebudget());
					
				}
				
				
				break;
				case 2:
					System.out.println("Enter the name of the movie");
				String moviename=sc.next();
				Set<Actor> result1=ms.getallactordetailsfromdao(moviename);
				for (Actor actor : result1) 
				{
					System.out.println("Actor id:"+actor.getActorid());
					System.out.println("Actor name: "+actor.getActorname());
					
				}
				break;
				
				case 3:
				System.out.println("list of movies > than 5000");
				Set<Movie> result11=ms.getallmoviesdetailsbybudget();
				for (Movie m : result11) {
					System.out.println();
					System.out.println("Movie id :"+m.getMovieid());
					System.out.println("Movie name :"+m.getMoviename());
					System.out.println("Movie budget :"+m.getMoviebudget());
		
				}
				break;
				case 4:int count=ms.countallmoviesgreaterthan1();
				System.out.println("The count of movies: "+count);
				break;
				
				case 5:
					System.exit(0);
					break;
					
				default:
					System.out.println("invalid choice");
			}
		System.out.println("press 1 to continue 0 TO EXIT");
		f=sc.nextInt();
		}while(f!=0);
				
	}

}
