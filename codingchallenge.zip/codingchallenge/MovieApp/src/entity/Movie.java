package entity;

import java.util.List;

public class Movie {

	private int movieid;
	private String moviename;
	private int moviebudget;
	//private List<Actor> actors;
	public Movie() {
		super();
	}
	public Movie(int movieid, String moviename, int moviebudget) {
		super();
		this.movieid = movieid;
		this.moviename = moviename;
		this.moviebudget = moviebudget;
	}
	public int getMovieid() {
		return movieid;
	}
	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}
	public String getMoviename() {
		return moviename;
	}
	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}
	public int getMoviebudget() {
		return moviebudget;
	}
	public void setMoviebudget(int moviebudget) {
		this.moviebudget = moviebudget;
	}
	
	
}
