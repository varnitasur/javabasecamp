package coding;

import java.util.Scanner;

public class fruits 
{
	
	public static String update(String name,int count) {
		int min=0;
		if(count>=min)
			return count+name;
		
	}

	public static String display(String name,int count)
	{
		 name=" ";
		System.out.println("1.mango \n 2.apple \n3.orange \n4.pear");
		return name;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("menu driven program \n 1.updatelist and purchase \n2.display list \n3.exit");
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the name of fruits");
		String name=sc.nextLine();
		System.out.println("enter the number of each fruits");
		int count=sc.nextInt();
		int ch=sc.nextInt();
		int arr[][]=new int [10][10];
		
		while(true)
		{	
			switch(ch)
			{
				case 1:
					System.out.println(update(name,count));
					break;
				case 2:
					System.out.println(display(name));
					break;
				case 3:
					System.out.println("exit");
					default:
						System.ochoiceut.println("wrong choice ");
	}

}
