package entity;

public class Problem {

	private int problemid;
	private String problemname;
	private String problemdescription;
	public Problem() {
		super();
	}
	public Problem(int problemid, String problemname, String problemdescription) {
		super();
		this.problemid = problemid;
		this.problemname = problemname;
		this.problemdescription = problemdescription;
	}
	public int getProblemid() {
		return problemid;
	}
	public void setProblemid(int problemid) {
		this.problemid = problemid;
	}
	public String getProblemname() {
		return problemname;
	}
	public void setProblemname(String problemname) {
		this.problemname = problemname;
	}
	public String getProblemdescription() {
		return problemdescription;
	}
	public void setProblemdescription(String problemdescription) {
		this.problemdescription = problemdescription;
	}
	
	
}
