package entity;

public class Solution {

	private int solutionid;
	private String solutionname;
	public Solution() {
		super();
	}
	public Solution(int solutionid, String solutionname) {
		super();
		this.solutionid = solutionid;
		this.solutionname = solutionname;
	}
	public int getSolutionid() {
		return solutionid;
	}
	public void setSolutionid(int solutionid) {
		this.solutionid = solutionid;
	}
	public String getSolutionname() {
		return solutionname;
	}
	public void setSolutionname(String solutionname) {
		this.solutionname = solutionname;
	}
	
}
