package dao.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import dao.CollegeDao;
import dbUtility.DBUtility;
import entity.Problem;
import entity.Solution;

public class CollegeDaoImpl implements CollegeDao {
static DBUtility obj=new DBUtility();
static Connection con=obj.getConnection();
	@Override
	public String isInsertedtoDB(List<Solution> solution) {
		Connection con=obj.getConnection();
		String result=" ";
		int count=0;
		String query="Insert into solution values (?,?);";
		try {
			for (Solution solution2 : solution) {
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, solution2.getSolutionid());
			ps.setString(2, solution2.getSolutionname());
			count++;
			}
			if(count==0)
			{
				result="Invalid input";
			}
			else
			{
				result="Inserted successfully";
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public String insertcategorytype(String problemname, String categoryname) {
		Connection con=obj.getConnection();
		String result=" ";
		int count=0,id=0;
		ResultSet rs=null;
		String query1="select category_id from category where category_name'"+categoryname+"'";
		try {
			PreparedStatement ps= con.prepareStatement(query1);
			rs = ps.executeQuery();
			while(rs.next()) {
				id = rs.getInt("category_id");
			}
			String query2="update problem set category_id='"+id+"' where problem_name='"+problemname+"'";
			ps.executeUpdate(query2);
			count++;
			if(count==0)
			{
				result="not inserted";
			}
			else
			{
				result="inserted";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public List<String> getallsolution() {
		Connection con=obj.getConnection();
		List<String> result=new ArrayList<String>();
		String query="SELECT solution_name FROM SOLUTION;";
		ResultSet rs=null;
		try {
			Statement s=con.createStatement();
			rs=s.executeQuery(query);
			while(rs.next()) {
				String solutionname=rs.getString("solutionname");
				result.add(solutionname);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public String assignsolutiontoDB(List<String> solutionnames, String problemname) {
		Connection con=obj.getConnection();
		String result=" ";
		int id=0;
		int count=0;
		int solid=0;
		String query="select problem_id from problem where problem_name='"+problemname+"'";
		ResultSet rs=null;
		try {
			Statement s=con.createStatement();
			rs=s.executeQuery(query);
			while(rs.next()) {
				id=rs.getInt("problem_id");
			}
			for (String solutionName : solutionnames) {
				String query1="Select solution_name from solution where solution_name='"+solutionnames+"'";
				rs=s.executeQuery(query1);
				while(rs.next())
				{
					String query2="insert into bridge(problem_id,solution_id)"+"values("+id+","+solid+")";
					s.execute(query2);
					count++;
				}
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(count == 0)
		{
			result="Not inserted";
		}
		else
		{
			result="inserted";
		}
		
		return result;
	}

	@Override
	public Set<Problem> getallproblemdetails() {
		Set<Problem> result=new HashSet<>();
		Connection con=obj.getConnection();
		int id=0;
		String query="Select problem.problem_id,problem.problem_name,problem.problem_description from problem inner join category on"+
		"problem.category_id=category.category_id";
		ResultSet rs=null;
		try {
			Statement s=con.createStatement();
			rs=s.executeQuery(query);
			while(rs.next()) {
				Problem p=new Problem(rs.getInt("problemid"), rs.getString("problemname"), rs.getString("problemdescription"));
				result.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public Set<Problem> getallproblemdetailsbyusingSolutionName(String solutionname) {
		Set<Problem> result = new HashSet<>();
		
		Statement s=null;
		ResultSet rs=null;
		int solutionid=0;
		
		
		return null;
	}

	@Override
	public Set<Problem> getallproblemsortedfromDB() {
		// TODO Auto-generated method stub
		return null;
	}

}
