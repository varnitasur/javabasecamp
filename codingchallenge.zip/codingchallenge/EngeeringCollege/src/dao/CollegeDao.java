package dao;

import java.util.List;
import java.util.Set;

import entity.Problem;
import entity.Solution;

public interface CollegeDao {

	//insert Solution To DB
	String isInsertedtoDB(List<Solution> solution);
	//insert category Type
	String insertcategorytype(String problemname,String categoryname);
	//get all solution
	List<String> getallsolution();
	//assign solution to DB
	String assignsolutiontoDB(List<String> solutionname,String problemname);
	//display all problem details
	Set<Problem> getallproblemdetails();
	//get all problem from by using solution
	Set<Problem> getallproblemdetailsbyusingSolutionName(String solutionname);
	//sort the problems based on solution
	Set<Problem> getallproblemsortedfromDB();
}
