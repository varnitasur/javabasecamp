package client;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import entity.Category;
import entity.Problem;
import entity.Solution;

public class CollegeApp {

	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Solution> solutions=createsolution();
		Set<Problem> problems=createproblem();
		Set<Category> categories=createcategory();

	}

	private static Set<Category> createcategory() {
		
		Set<Category> result=new HashSet<>();
		System.out.println("Enter the no of category");
		int categorycount=sc.nextInt();
		for (int i = 0; i < categorycount; i++) {
			System.out.println("Enter the category id");
			int id=sc.nextInt();
			System.out.println("Enter the category name");
			String name=sc.next();
			Category category=new Category(id, name);
			result.add(category);
		}

		return result;
	}

	private static Set<Problem> createproblem() {
		
		Set<Problem> result=new HashSet<>();
		System.out.println("Enter the no of problem");
		int problemcount=sc.nextInt();
		for (int i = 0; i < problemcount; i++) {
			System.out.println("Enter the problem id");
			int id=sc.nextInt();
			System.out.println("Enter the problem name");
			String name=sc.next();
			System.out.println("Enter the problem description");
			String problemdescription=sc.next();
			Problem problem=new Problem(id, name, problemdescription);
			result.add(problem);
		}
		return result;
	}

	private static List<Solution> createsolution() {
		List<Solution> result=new ArrayList<>();
		System.out.println("Enter the no of solution");
		int solutioncount=sc.nextInt();
		for (int i = 0; i < solutioncount; i++) {
			System.out.println("Enter the solution id");
			int id=sc.nextInt();
			System.out.println("Enter the solution name");
			String name=sc.next();
			Solution solution=new Solution(id, name);
			result.add(solution);
		}
		return result;
	}

}
