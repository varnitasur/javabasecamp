package ExtraQuestions;

import java.util.Scanner;

public class TrendyNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int temp=n;
		int count=0;
		while(temp>0)
		{
			temp/=10;
			count++;
		}
		if( == 3) {
			int f=0;
			int l=count-1;
			int mid=(f+l)/2;
			if(mid%3==0)
			{
				System.out.println(" trendy number"+n);
			}
			else
				System.out.println(" not a trendy number");
		}
	}
}

