package ExtraQuestions;

import java.util.Scanner;

public class Ex4 {
	static boolean Display(int arr[],int arr1[])
	{
		if(arr.length!=arr1.length)
		{
			return false;
		}
		for(int i=0;i<arr.length;i++)
		{	
			if (arr[i]==arr1[i])
			{
				return true;
			}
		}	
			return false;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" Enter the no of parameters");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int i,j;
		System.out.println(" the sample inputs of MSD");
		int arr[]=new int [n];
		for(i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println(" the sample inputs of KS");
		int arr1[]=new int[n];
		for(j=0;j<arr1.length;j++)
		{
			arr1[j]=sc.nextInt();
		}
		
		System.out.println(Display(arr,arr1));

	}

}
