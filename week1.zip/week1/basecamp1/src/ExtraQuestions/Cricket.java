package ExtraQuestions;

import java.util.Scanner;

public class Cricket {
	static String[] Names(String[] a) {
		String[] result = new String[a.length];
		for(int i=0;i<a.length;i++) {
			result[i] = a[i]; 
		}		
		
		return result;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the no of elements");
		Scanner sc=new Scanner(System.in);
		int n =sc.nextInt();
		
		String pName[]=new String[n];
		for(int i=0;i<pName.length;i++)
		{
			System.out.println("Enter the player names "+" "+i);
			pName[i]=sc.next();
		}
		String abc[] = new String[n];
		abc = Names(pName);
		for(int i=0;i<n;i++) {
			System.out.print("["+pName[i]+"]");
		}
	}
}
