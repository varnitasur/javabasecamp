package ExtraQuestions;

import java.util.Scanner;

public class StringReverse {
	
	//static String stringReverse(String name)
	//{
		//String text=
	//}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the String");
		Scanner sc=new Scanner(System.in);
		String name=sc.nextLine();
		int space[]=new int [100];
		int j=0;
		for(int i=0;i<name.length();i++)
		{
			j=0;
		if(name.charAt(i)==' ')
			{
				space[j]=i;
				j++;
			}
		}
		for(int i=0;i<space.length;i++) {
		System.out.print(" "+space[j]);
		
		
		}
	}

}
