package ExtraQuestions;

import java.util.Scanner;

public class Ex5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]=new int[11];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of players");
		int n=sc.nextInt();
		System.out.println(" Enter the scores");
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println(" The scores are:");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]+" ");
		}
	}

}
