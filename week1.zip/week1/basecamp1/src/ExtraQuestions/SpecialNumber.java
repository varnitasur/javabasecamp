package ExtraQuestions;

import java.util.Scanner;
	
public class SpecialNumber 
{
	public static boolean specialNumber(int n)
		{
			int sum=0;
			int product=1;int counter=0;
			while(n!=0)
			{
				int f=n/10;
				int l=n%10;
				 sum=f+l;
				 product=f*l;
			}
			if(n==(sum+product))
			{
			
				return true;		
			}	
			else
			return false;	
		
	}	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	System.out.println("enter the number");
		System.out.println(" enter the range");
		Scanner sc=new Scanner(System.in);
		int k=0;int product=1;
		int a[]=new int[20];
		for(int i=0;i<20;i++)
		{
			if(specialNumber(k)==true)
			{
			a[i]=k;
			k++;
			}
			else
				break;
		
		}
		for(int i=0;i<20;i++)
		{
			System.out.println(" "+a[i]);
		}
		
		//int r2=sc.nextInt();
		//if(n<10 || n>99)
		//	System.out.println("exit");
		//else
		//int abc[] = new  int[r2];
		
		
	//System.out.println("the special number :"+ specialNumber(n));
	
			
	}
}