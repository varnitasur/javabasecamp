package mindtree.com;

import java.util.Scanner;

class Match{
	
	String date;
	String teamOne;
	String teamTwo;
	String venue;
	
	public void setmatchDate(String date) {
		this.date=date;
	}
	public String getmatchDate() {
		return date;
	}
	public void setteamOne(String teamOne) {
		this.teamOne=teamOne;
	}
	public String getteamOne() {
		return teamOne;
	}
	public void setteamTwo(String teamTwo) {
		this.teamTwo=teamTwo;
	}
	public String getteamTwo() {
		return teamTwo;
	}
	public void setmatchvenue(String venue) {
		this.venue=venue;
	}
	public String getmatchvenue() {
		return venue;
	}
	public Match(String date, String teamOne, String teamTwo, String venue) {
		super();
		this.date = date;
		this.teamOne = teamOne;
		this.teamTwo = teamTwo;
		this.venue = venue;
	}
	Match(){
	
		
	
}
}
 class MatchBO {
	
	 public static void displayAllMatchDetails(Match[] m) {
		 
		  {
				for(int i=0;i<m.length;i++) {
			
				System.out.println(m[i].getmatchDate());
				System.out.println(m[i].getteamOne());
				System.out.println(m[i].getteamTwo());
				System.out.println(m[i].getmatchvenue());
			}
		  }
	 }
	 public static void displaySpecificMatchDetails(Match[] m,String date) {
		for(int i=0;i<m.length;i++) {
			
			if((m[i].getmatchDate().equals(date)))
					{
				
				System.out.println(m[i].);
				System.out.println(p[i].getplayerCountry());
			}
			 
	 }	
}
public class Main{
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Enter the number of players");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Player[] p=new Player[n];
		for(int i=0;i<p.length;i++) {
			System.out.println("Enter the player name , country ,and skill");
			p[i]=new Player(sc.next(),sc.next(),sc.next());
		}
		PlayerBO.displayAllPlayerDetails(p) ;
		System.out.println("Enter the country name");
		String pcountry=sc.next();
		PlayerBO.displaySpecificMatchDetails(p, pcountry);
	}

}

	}

}
