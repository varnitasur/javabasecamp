package mindtree.com;

import java.util.Scanner;

class Player{
	
	String pname;
	String pcountry;
	String pskill;
	
	public void setplayerName(String pname) {
		this.pname=pname;
	}
	public String getplayerName() {
		return pname;
	}
	public void setplayerCountry(String pcountry) {
		this.pcountry=pcountry;
	}
	public String getplayerCountry() {
		return pcountry;
	}
	public void setplayerSkill(String pskill) {
		this.pskill=pskill;
	}
	public String getplayerSkill() {
		return pskill;
	}
	public Player(String pname, String pcountry, String pskill) {
		super();
		this.pname = pname;
		this.pcountry = pcountry;
		this.pskill = pskill;
	}Player(){
		
	
}
}
 class PlayerBO {
	
	 public static void displayAllPlayerDetails(Player[] p) {
		 
		  {
				for(int i=0;i<p.length;i++) {
			
				System.out.println(p[i].getplayerName());
				System.out.println(p[i].getplayerCountry());
				System.out.println(p[i].getplayerSkill());
			}
		  }
	 }
	 public static void displaySpecificMatchDetails(Player[] p,String pcountry) {
		for(int i=0;i<p.length;i++) {
			
			if((p[i].getplayerCountry().equals(pcountry)))
					{
				
				System.out.println(p[i].getplayerName());
				System.out.println(p[i].getplayerCountry());
			}
			 
	 }	
}
public class Main{
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Enter the number of players");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Player[] p=new Player[n];
		for(int i=0;i<p.length;i++) {
			System.out.println("Enter the player name , country ,and skill");
			p[i]=new Player(sc.next(),sc.next(),sc.next());
		}
		PlayerBO.displayAllPlayerDetails(p) ;
		System.out.println("Enter the country name");
		String pcountry=sc.next();
		PlayerBO.displaySpecificMatchDetails(p, pcountry);
	}

}
