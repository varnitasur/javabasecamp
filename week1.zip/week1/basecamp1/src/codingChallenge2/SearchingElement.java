package codingChallenge2;

import java.util.Scanner;

public class SearchingElement {
	
	public static int BinarySearch(int oneD[],int x)
	{
		int low=0;
		int high=oneD.length-1;
		int mid=(low+high)/2;
		while(low<=high)
		{
			if(x==oneD[mid])
				return mid;
			else if(x<oneD[mid])
				high=mid-1;
			else
				low=mid-1;
				
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of matrix");
		int n=sc.nextInt();
		System.out.println("Enter the first matrix");
		int a[][]=new int[n][n];
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		sc.nextLine();
		System.out.println("Enter the second matrix");
		int b[][]=new int [n][n];
		for(int i=0;i<b.length;i++)
		{
			for(int j=0;j<b[i].length;j++)
			{
				b[i][j]=sc.nextInt();
			}
		}
		int c1[]=new int[a.length];
		for(int i=0;i<a.length;i++)
		{
			if(i==0)
			{	int count=0;
				for(int j=0;j<a.length;j++)
				{
					//if(i==0)
						c1[count]=a[0][j];
						count++;
				}
			}
		}
		int c2[]=new int[b.length];
		for(int i=0;i<b.length;i++)
		{
			for(int j=0;j<b.length;j++)
			{
				if(j==1)
					c2[i]=b[i][j];
			}
		}
		for(int i=0;i<c1.l ength;i++)
		{
			System.out.println(c1[i]+" ");
		}
		for(int i=0;i<c2.length;i++)
		{
			System.out.println(c2[i]+" ");
		}
		int c[]=new int[n];
		for(int i=0;i<c1.length;i++)
		{
			c[i]=0;
				//for( int k=0;k<n;k++)
				{
					c[i]+=c1[i]*c2[i];
				}
		}
	
		System.out.println(" the resultant matrix");
		for(int i=0;i<c.length;i++)
		{
			System.out.println(c[i]+" ");
		}
	
		System.out.println();
		for(int i=0;i<c.length;i++)
		{
			for(int j=0;j<c.length-i-1;j++)
			{
				if(c[j]>c[j+1])
				{
					int temp=c[j];
					c[j]=c[j+1];
					c[j+1]=temp;
					
				}
			}
		}
		System.out.println("Sorted elements are");
		for(int i=0;i<c.length;i++)
		{
			System.out.println(c[i]+" ");
		}	
		System.out.println("Enter the number to be searched");
		int x=sc.nextInt();
		int result=BinarySearch(c,x);
		if(result == -1)
			System.out.println(" result not found");
		else
			System.out.println(" element found at index : "+result);

		
	}

}
