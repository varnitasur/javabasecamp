package codingChallenge2;

import java.util.Scanner;
public class StringDemoReplace {

	public static String[] replace(String[] mat3)
	{
		int len=mat3.length;
		String temp="";
		String s[]=new String[len];
		int k=0;
		for(int j=0;j<len;j++)
		{
			for(int i=0;i<mat3[j].length();i++) {
			
				if(mat3[j].charAt(i)=='a'||mat3[j].charAt(i)=='e'||mat3[j].charAt(i)=='u'||mat3[j].charAt(i)=='i'||mat3[j].charAt(i)=='o')
				{
					temp=temp+(char) (mat3[j].charAt(i)+1);
				}
				else
				{
					temp=temp+(char) mat3[j].charAt(i);
				}
			}
			s[j] = temp;
			k++;
			temp = "";				
				
			}
			
				return s;
			
			
	}
	public static String rev(String s) 
	{
		
		String reverseString="";
		String temp="";
		char c=' ';
		for(int i=s.length()-1;i>=0;i--) {
			c=s.charAt(i);
			if(!(c>=48 && c<=57))
			{
				temp=temp+s.charAt(i);
			}
			else
			{
				reverseString=c+temp+reverseString;
				temp=" ";
			}
			reverseString=temp+reverseString;
		}
			return reverseString;
				
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int n = sc.nextInt();
		
		System.out.println("Enter the name of first array");
		String a[][] = new String[n][n];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				a[i][j] = sc.next();
			}
		}
		
		System.out.println("Enter the name of the Second Array");
		String b[][] = new String[n][n];

		for (int i = 0; i < b.length; i++) {
			for (int j = 0; j < b.length; j++) {
				b[i][j] = sc.next();
			}
		}
		String mat3[] = new String[a.length * b.length];
		int k = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				mat3[k] = (a[i][j] + " " + b[i][j]);
				k++;
			}
		}

		System.out.println("combined matrix:");
		for (int i = 0; i < mat3.length; i++) {

			System.out.println(mat3[i] + " ");

		}

		System.out.println();
		String[] newarr=replace(mat3);
		System.out.println("1d replace is");
		for( int i=0;i<newarr.length;i++) {
			System.out.println(newarr[i]);
		}
		 
		System.out.println();
		System.out.println("Enter the character to be reversed");
		String ch=sc.next();
		String result="";
		for(int i=0;i<mat3.length;i++) {
			for(int j=0;j<mat3[i].length();j++) {
				String str=mat3[i];
				char c=ch.charAt(0);
				if(c==str.charAt(j)) {
					result=rev(str);
				}
			}
		}
		System.out.println(result);

		  
		 /** String efg = vowelReplace(newString); for (int i = 0; i < efg.length() - 1;
		 * i++) { System.out.println(efg + " "); }
		 * System.out.println("Enter the character to be reversed"); char ch =
		 * sc.next().charAt(0);
		 * 
		 * String newString2 = reverse(newString, ch); for (int i = 0; i <
		 * newString2.length() - 1; i++) { System.out.println(newString2 + " ");
		 */
	}
}
