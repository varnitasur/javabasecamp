package codingChallenge2;

import java.util.Scanner;

public class StringReverse {
	public static String[] split(String input)
	{
		int c=0;
		for(int i=0;i<input.length();i++)
		{
			if(input.charAt(i)==' ')
				c++;
		}
		String[] arr=new String[c];
		String temp="";
		for(int i=0, j=0;i<input.length();i++) 
		{
			if(input.charAt(i)!=' ') {
				temp=temp+input.charAt(i);
				
			}
			else
			{
				arr[j]=temp;
				temp="";
				j++;
			}
		}
		return arr;
		}
	
	static void InsertionSort(String a[])
	{
		for(int j=1;j<a.length;j++)
		{
			String value=a[j];
			int hole=j-1;
			while((hole>-1)&&(a[hole].compareTo(value)>0))
			{
				a[hole+1]=a[hole];
				hole--;
			}
			a[hole+1]=value;
		}
	}		
	public static int Search(String arr[],String x)
	{
		int r=arr.length;
		int low=0; ;//int high=r-1;
		
		while(low<=r)
		{
			int mid=(low+(r-1))/2;
			int res=x.compareTo(arr[mid]);
			if(res==0)
				return mid;
			if(res > 0)
				low=mid+1;
			else
				r=mid+1;
			
		}
		return -1;
	}


public static String reverse(String str) {
		String temp="";
		for(int i=str.length()-1;i>=0;i--)
		{
			temp=temp+str.charAt(i);
		}
		return temp;
	}
	/*	public static String vowelReplace(String str)
		{
			String temp="";
			for(int j=0;j<str.length();j++) {
			if(str.charAt(j)=='a'||str.charAt(j)=='e'||str.charAt(j)=='i'||str.charAt(j)=='o'||str.charAt(j)=='u')
				temp=temp+"#";
			else
			{
				temp=temp+(char)(str.charAt(j)-1);
			}
		}	
			return temp;
		}*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String");
		String input=sc.nextLine();
		String splitted[]=split(input+" ");
		
		for(int i=0;i<splitted.length;i++) {
			System.out.print(splitted[i]+" ");
		}

		
		for(int i=0;i<splitted.length;i++) {
			if(i%2==0) {
				splitted[i]=reverse(splitted[i]);
			}	
		}
		for(int i=0;i<splitted.length;i++) {
			System.out.print(splitted[i]+" ");
		}
		System.out.println();
		/*for(int i=0;i<splitted.length;i++) {
			splitted[i]=vowelReplace(splitted[i]);
		}	
		for(int i=0;i<splitted.length;i++) {
			System.out.print(splitted[i]+" ");
		}*/
		System.out.println();
		System.out.println("Sorted elements are:");
		
		InsertionSort(splitted);
		for(int i=0;i<splitted.length;i++)
		System.out.print(splitted[i]+" ");
		System.out.println();
		System.out.println("Enter the String to find index:");
		String x=sc.next();
		
		int result=Search(splitted,x);
		if( result == -1)
			System.out.println("String not found");
		else
			System.out.println("String found at position : "+ result);

		char[] repeat=input.toCharArray();
		for(int i=0;i<repeat.length;i++)
		{
			for(int j=0;j<repeat.length;j++) {
				if(i!=j && repeat[i]==repeat[j])
				{
					repeat[i]='1';
					//String ans=repeat.toString();
				}
			}
		}
		for(int i=0;i<input.length();i++)
		System.out.println(repeat[i]);
			
		}

	}


