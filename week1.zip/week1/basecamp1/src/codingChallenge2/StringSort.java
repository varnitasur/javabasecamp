package codingChallenge2;

import java.util.Scanner;

public class StringSort {
	
	public static String[] Combine(String c[],String d[])
	{
		int length=c.length+d.length;
		String result[]=new String[length];
		System.arraycopy(c,0,result,0,c.length);
		System.arraycopy(d,0,result,c.length,d.length);
		return result;
		
	}
	public static String[] InsertionSort(String abc[])
	{
		for(int j=1;j<abc.length;j++)
		{
			String key=abc[j];
			int hole=j-1;
			while((hole>-1)&&(abc[hole].compareTo(key)>0))
			{
				abc[hole+1]=abc[hole];
				hole--;
			}
			abc[hole+1]=key;
		}
		return abc;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of array");
		int n=sc.nextInt();
		System.out.println("Enter the name of first array");
		String a[][]=new String[n][n];
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				a[i][j]=sc.nextLine();
			}
		}sc.nextLine();
		System.out.println("Enter the name of the Second Array");
		String b[][]=new String[n][n];
		
		for(int i=0;i<b.length;i++)
		{
			for(int j=0;j<b[i].length;j++)
			{
				b[i][j]=sc.nextLine();
			}
		}
		String c[]=new String[b.length];
		for(int i=0;i<b.length;i++)
		{
			for(int j=0;j<b.length;j++)
			{
				if(j==b.length-1)
				c[i]=b[i][j];	
			}
		}
		String d[]=new String[a.length];
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a.length;j++)
			{
				if(j==a.length-1)
				d[i]=a[i][j];	
			}
		}
		
	
	/*	String oneD[]=new String[n*n];
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a.length;j++)
			{
				oneD[(i*a.length)+j]=a[i][j];
			}
		}
		String oneD1[]=new String[n*n];
		for(int i=0;i<b.length;i++)
		{
			for(int j=0;j<b.length;j++)
			{
				oneD1[(i*b.length)+j]=b[i][j];
			}
		}	*/
		String abc[]=Combine(c,d);
		for(int i=0;i<abc.length;i++)
		{
			System.out.print(abc[i]+" ");
		}
		System.out.println();
		System.out.println(" the sorted array is");
		String s[]=InsertionSort(abc);
		for(int i=0;i<s.length;i++)
		{
			System.out.print(s[i]+" ");
		}
		
	}

}
