package codingChallenge2;

import java.util.Scanner;

public class oneDAdjacent {
	
	public static int[] SumOfAdjacent(int a[],int n)
	{
		int sum[]=new int[n];
		for(int i=0;i<n;i++)
		{
			sum[i]=0;
		}
		for(int i=0;i+1<n;i=i+2)
		{
			
			sum[i]=a[i]+a[i+1];
			
		}
	return sum;

	}
	public static int CheckValidation(int result[])
	{
		int count=0;
		for(int i=0;i<result.length;i++)
		{	
			if(result[i]>=10)
			{
				count++;
			}
		}	
		return count;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size"); 
		int n=sc.nextInt();
		System.out.println("Enter the elemts");
		int a[]=new int[n];
		int res=0;
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		
			int result[]=SumOfAdjacent(a,n);
			for(int i=0;i<n;i++)
			{
				if(result[i]!=0)
			System.out.println(result[i]+" ");
			}
			
		 res=CheckValidation(result);
		 System.out.println(res);

	}

}
