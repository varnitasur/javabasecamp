package minicodingchallenge;

import java.util.Scanner;

public class Pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		if(n<=9)
		{
			for(int i=1;i<=n;i++)
			{
				for(int k=1;k<=n-i;k++)
				{
					System.out.print(" ");
				}
				
				for(int j=1;j<=i;j++)
				{
					//if(j<=i)
					System.out.print(j);
				}	
				System.out.println();
			}
		}
		else if(n<=10)
		{
			int diff=10;
			int r=n-diff;
			for(int i=1;i<=n;i++)
			{
				for( int k=1;k<=n-r-i;k++)
				{
					System.out.println("  ");
				}
				for(int j=1;j<i;j++)
				{
					System.out.println(j);
				}
				System.out.println();
			}
		}
		
		else
		
			for(int i=1;i<=n;i++)
			{
				for(int k=1;k<=n-i;k++)
				{
					System.out.print(" ");
				}
				
				for(int j=1;j<=i;j++)
				{
					//if(j<=i)
					System.out.print(j);
				}	
				System.out.println();

			}
}
}
