package minicodingchallenge;

import java.util.Scanner;
public class Exercise1a2 {
	

	public static void main(String[] args) {
		// TODO Auto-generated method st
		Scanner sc=new Scanner(System.in);
		int n =sc.nextInt();
		String input[]=new String[n];
		String name=" ";
		int j=0,k=0,l=0;
		System.out.println("Enter the elements");
		for(int i=0;i<n;i++)
			input[i]=sc.next();
		for(int i=0;i<n;i++)
		{
			name=name+input[i];
			for(int j1=0;j1<name.length();j1++)
			{
				if(name.charAt(j1)>='a' && name.charAt(j1)<='z')
					l++;
				else if(name.charAt(j1)>='A' && name.charAt(j1)<='Z')
					k++;
				else
					j++;
			}
			if(l==name.length())
				System.out.print("lower case :"+input[i]);
			else if(k==name.length())
				System.out.println(" upper case :"+input[i]);
			else
				System.out.println("mixed : "+input[i]);
			l=0;k=0;j=0;
			name=" ";
		}
			

	}

}
