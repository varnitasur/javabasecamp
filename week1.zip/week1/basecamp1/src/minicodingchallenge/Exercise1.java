package minicodingchallenge;

import java.util.Scanner;

public class Exercise1 {
	public static int[][] sumArray(int a[][],int b[][])
	{
		int i,j;
		int c[][]=new int[a.length][b.length];
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<b.length;j++)
			{
				c[i][j]=a[i][j]+b[i][j];
			}
		}
		return c;
	}
	public static void daigonals(int a[][],int b[][])
	{
		int t[][]=new int[a.length][b.length];
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<b.length;j++)
			{
				t[i][j]=a[i][j]; 
			}
		}
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<b.length;j++)
			{
				if(i!=j)
				{
					a[i][j]=a[i][j];
				}
				else
				{
					a[i][j]=a[i][j];
				}
			}
		}
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<b.length;j++)
			{
				System.out.print(a[i][j]+" ");      
			}
		}
	}	
	public static int[]	sortLastColumn(int[][] b)
	{
		int c[]=new int[b.length];
		for(int i=0;i<b.length;i++)
		{
			for(int j=0;j<b.length;j++)
			{
				if(j==b.length-1)
				c[i]=b[i][j];	
			}
		}
		return c;
	}
	
	public static int[] bubblesort(int[] z)
	{
		for(int i=0;i<z.length-1;i++)
		{
			for(int j=0;j<z.length-i-1;j++)
			{
				if(z[i]>z[i+1])
				{
					int temp=z[i];
					z[i]=z[i+1];
					z[i+1]=temp;
				}
			}
	
		}
		
		return z;
	}

	public static int[] sortFirstColumn(int [][]a)
	{
		int c1[]=new int[a.length];
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a.length;j++)
			{
				if(j==0)
					c1[i]=a[i][j];
			}
		}
		return c1;
	}
	public static int[] insertionSort(int []z1)
	{
		for(int i=1;i<z1.length;i++)
		{
			int val=z1[i];
			int pos=i-1;
			while(pos>=0 && z1[pos]>val)
			{
				z1[pos+1]=z1[pos];
				pos=pos-1;
			}
			z1[pos+1]=val;
			
		}
	}
	public static int[] sort(int a[][],int b[][])
	{
		int count=0;
		int d[]=new int[(a.length*a.length)+(b.length*b.length)];
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<b.length;j++)
			{
				d[count]=a[i][j];
				count++;
			}
		}return d;
	}
	 public static boolean bSearch(int []d1,int key)
	 {
		 int low=0,high=d1.length-1,mid=0;
		  mid=(low+high)/2;
		 while(low<=high) {
		 if(key==d1[mid])
			 return true;
		 else if(key<d1[mid])
			 high=mid-1;
		 else
			 low=mid+1;
	 }
	 return false;
	 } 
	 
	 public static void main(String[] args) {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("enter the choices: 1.enter the sum of array \n 2.enter to shift the daigonal \n 3.sort the last column \n 4.sort first column \n 5.merge the two arrays and binary search");
		 System.out.println();
		 System.out.println("Enter the number of row");
		 int m=sc.nextInt();
		 System.out.println("Enter the number of col");
		 int n=sc.nextInt();
		 int a[][]=new int[m][n];
		 for(i=0;i<a.length;i++)
			{
				for(j=0;j<b.length;j++)
				{
		 
				 
	 }
		
		
		
		
		
		
		
		
		
		
		
	}
	
}

		