package minicodingchallenge;

import java.util.Scanner;

public class Exercise2 {
	
	public static int Search(int oneD[],int x)
	{
		int low=0;
		int high=oneD.length-1;
		int mid=(low+high)/2;
		while(low<=high)
		{
			if(x==oneD[mid])
				return mid;
			else if(x<oneD[mid])
				high=mid-1;
			else
				low=mid-1;
				
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		//int m=sc.nextInt();
		System.out.println(" Enter the size of array");
		int n=sc.nextInt();
		System.out.println(" enter the elements in the first matrix");
		int a[][]=new int [n][n];
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		System.out.println(" enter the elements in the second matrix");
		int b[][]=new int [n][n];
		for(int i=0;i<b.length;i++)
		{
			for(int j=0;j<b[i].length;j++)
			{
				b[i][j]=sc.nextInt();
			}
		}
		
		int c[][]=new int[n][n];
		for(int i=0;i<c.length;i++)
		{
			for(int j=0;j<c[i].length;j++)
			{
				c[i][j]=a[i][j]+b[i][j];
			}
		}
		System.out.println(" resultant of both the matrix");
		for(int i=0;i<c.length;i++)
		{
			for(int j=0;j<c[i].length;j++)
			{
				System.out.print(c[i][j]+"\t");
			}
			System.out.println();
		
		}
		
		int oneD[]=new int [n*n];
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++) 
			{
				oneD[(i*n)+j]=c[i][j];
			}
		}
		System.out.println(" the oneD array is");
		for(int i=0;i<oneD.length;i++)
		{
			System.out.print(oneD[i]+" ");
		}
		System.out.println();
		for(int i=0;i<oneD.length;i++)
		{
			for(int j=0;j<oneD.length-i-1;j++)
			{
				if(oneD[j]>oneD[j+1])
				{
					int temp=oneD[j];
					oneD[j]=oneD[j+1];
					oneD[j+1]=temp;
					
				}
			}
		}
		System.out.println("Sorted elements are");
		for(int i=0;i<oneD.length;i++)
		{
			System.out.println(oneD[i]+" ");
		}	
		System.out.println("Enter the number to be searched");
		int x=sc.nextInt();
		int result=Search(oneD,x);
		if(result == -1)
			System.out.println(" result not found");
		else
			System.out.println(" element found at index : "+result);
	}

}
