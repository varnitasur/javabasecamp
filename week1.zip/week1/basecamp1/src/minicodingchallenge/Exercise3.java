package minicodingchallenge;

import java.util.Scanner;
public class Exercise3 {
	
	public static String display(String dept)
	{
		String name=" ";
		String s1="CR";
		String s2="MR";
		{
		if(dept.equals(s1))
			return name+s1;
		else 
			return name+s2;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println(" enter the name of dept");
		String dept=sc.nextLine();
		System.out.println(" enter the floor");
		int n=sc.nextInt();
		String res=" ";
		if(n==0)
			res=res+"GF";
		else if(n==1)
			res=res+"1F";
		else
			res=res+"2F";
		
		System.out.println(" Enter room number");
		int r=sc.nextInt();
		System.out.print("MTK"+"-"+display(dept)+"-"+"LC1"+"-"+res+"-"+r);
		
		
		
		
		

	}

}
