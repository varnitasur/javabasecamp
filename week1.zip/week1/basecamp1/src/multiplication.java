import java.util.Scanner;
public class multiplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter a number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int res;
		for(int i=1;i<=12;i++)
		{
			res=n*i;
		System.out.println(n+"x"+i+"="+res);
		}
	}

}
