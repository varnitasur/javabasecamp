package basecamp1;

import java.util.Scanner;

public class Operation1 {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.out.println(" enter the two numbers");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		int res=0;
	loop :while(true)
		{
		System.out.println("Enter the choices : 1.area of triangle \n 2.addition \n 3.multiplication \n 4.substraction \n5.area of square");
		int n=sc.nextInt();
			switch(n)
			{
			case 1:
				res=(a*b)/2;
System.out.println(" area of triangle:"+res);
				break;
			case 2:
				res=a+b;
				System.out.println("addition :"+res);
				break;
			case 3:
				res=a*b;
				System.out.println("multiplication :"+res);
				break;
			case 4:
				res=a-b;
				System.out.println(" substraction :"+res);
				break;
			case 5:
				res=a*a;
				System.out.println(" square area :"+res);
				break;
			case 6:
				System.out.println("exit");
				break loop;
			default:
				System.out.println(" looking forward");
				
				
			}
		}
		
		
	}
}

	
