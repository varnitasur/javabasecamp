package basecamp1;

import java.util.Scanner;

public class factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int factorial = 1;
		int reverse = 0;
		for (int i = 1; i <= n; i++) {
			factorial *= i;
		}

		System.out.println("factorial of number " + n + " is fact " + factorial);
		while (factorial != 0) {
			int remainder = factorial % 10;
			reverse = reverse * 10 + remainder;
			factorial /= 10;
		}
		System.out.println("reverse number: " + reverse);

	}
}