package capability1;

import java.util.Scanner;

public class Series {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int n=sc.nextInt();int diff=2;int s=0;
		for(int i=1;i<=n-1;i++)
		{
			s=s+diff*i;
			System.out.print(s+" ");
		}

	}

}
