package capability1;

import java.util.Scanner;

public class evenFibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=0,b=1,c,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the range ");
		int n=sc.nextInt();
		for(int i=0;i<=n;i++)
			{
				c=a+b;
				if(c<=n)
				{
					System.out.print(c+" ");
					if(c%2==0)
						sum=sum+c;
						a=b;
						b=c;
				}
			}
		System.out.println(" the sum of the even fibonacci number is :"+sum);
}}


