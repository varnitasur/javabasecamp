package capability1;

import java.util.Scanner;

class Test{
	
	void greenticket(int a,int b,int c)
	{
		if(a==b && b==c)
		{
			System.out.println("OK 20");
		}
		else if(a==b || b==c || c==a)
		{
			System.out.println("OK 10");
		}
		else
			System.out.println("OK 0");
	}
}	
	
public class Ticket
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub                     
		System.out.println("enter the tickets");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		Test t=new Test();
		 t.greenticket(a,b,c); 
	}	 
}