package capability1;

import java.util.Scanner;

public class gcd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int temp;
		Scanner sc= new Scanner(System.in);
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		int i=num1;
		int j=num2;
		while(num2!=0)
		{
			temp=num2;
			num2=num1%num2;
			num1=temp;
		}
		int hcf=num1;
		int lcm=(i*j)/hcf;
		System.out.println(hcf);
		System.out.println(lcm);
	}	

	}


