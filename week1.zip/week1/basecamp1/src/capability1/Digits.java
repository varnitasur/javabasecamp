package capability1;

public class Digits {

}
