package capability1;

import java.util.Scanner;

public class Operations {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		 Scanner sc=new Scanner(System.in);
		 int n=sc.nextInt();
		 int sum=0,i = 0;
		 if(n==0||n==1)
			 System.out.println("not prime");
		 else
		 {
			 for(i=2;i<=n;i++)
				 if(n%i==0)
				 {
					 sum=sum+i;
				 }
		 System.out.println(i+" ");
		 System.out.println(sum);
		}
	
	}
}
