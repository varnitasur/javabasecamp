package capability1;
import java.util.Scanner;
public class Details
{
	
	public static int getInt(String message) {
		System.out.println();
		Scanner sc=new Scanner(System.in);
		return sc.nextInt();
		
	}
	public static String getString(String message) {
		System.out.println(message);
		Scanner sc=new Scanner(System.in);
		return sc.nextLine();
	}
	
	public static class Edetails{
	
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.out.println("enter the department id");
		int departmentId=Details.getInt("enter the id");
		String jobBands=Details.getString("enter the band");
		String empID=Details.getString("enter the empId");
			if(!( jobBands=="C1"|| jobBands=="C2"|| jobBands=="C3"||jobBands=="C4")&& (departmentId>=110 && departmentId<=125))
			{
				System.out.println("the employee id is :"+ empID);
			}
			else
				System.out.println("error");
	
	}
}
}

