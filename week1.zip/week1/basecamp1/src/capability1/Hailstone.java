package capability1;
import java.util.Scanner;
public class Hailstone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter a number");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();//int res;
		int count=0;
			while(num>1) {
			if(num%2==0)
			{
				int res1=num;
				num/=2;
				System.out.println(num+"is even so i take half of :"+res1);
			}
			
			else 
			{
				int res2=num;
				num=(num*3)+1;
				System.out.println(num+"is odd so i make 3n+1 :"+res2);
			}
			count++;
				System.out.println("number of steps"+" "+count);
		}		
	}

}
