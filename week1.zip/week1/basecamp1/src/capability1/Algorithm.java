package capability1;

import java.util.Scanner;

public class Algorithm {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int i;
		
		for(i=1;i<=10;i++)
		{
			if((a>b)||( a<=0 || b<=0 ))
			{
				System.out.println("invalid");
				System.exit(0);
			}
			a=a+b;
			b=b+10;
		}
		System.out.println(a);
		System.out.println(b);
	}

}
