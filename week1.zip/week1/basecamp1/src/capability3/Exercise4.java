package capability3;

import java.util.Scanner;

public class Exercise4 {

	static void InsertionSort(int a[],int n)
	{
		for(int j=1;j<a.length;j++)
		{
			int value=a[j];
			int hole=j-1;
			while((hole>-1)&&(a[hole]>value))
			{
				a[hole+1]=a[hole];
				hole--;
			}
			a[hole+1]=value;
		}
	}		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the size");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		//System.out.println("enter the elements");
		int arr[]=new int [n];
		int i;
		System.out.println("enter the unsorted array");
		for(i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Sorted elements are");
			InsertionSort(arr,n);
		for(i=0;i<n;i++)
			System.out.print(arr[i]+" ");

	}
	

}
