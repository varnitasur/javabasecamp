package capability3;

import java.util.Scanner;

public class Exercise3a {
	public static int Search(String arr[],int n,String x)
	{
		int r=arr.length;
		int low=0; ;//int high=r-1;
		
		while(low<=r)
		{
			int mid=(low+(r-1))/2;
			int res=x.compareTo(arr[mid]);
			if(res==0)
				return mid;
			if(res > 0)
				low=mid+1;
			else
				r=mid+1;
			
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the size of String Array");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println("Enter the String in the array");
		String arr[]=new String[n];
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.next();
		}
		System.out.println("Enter the String to find index");
		String x=sc.next();
		
		int result=Search(arr,n,x);
		if( result == -1)
			System.out.println("String not found");
		else
			System.out.println("String found at position : "+ result);
	}

}
