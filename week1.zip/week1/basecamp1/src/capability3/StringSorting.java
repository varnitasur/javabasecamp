package capability3;

import java.util.Scanner;

public class StringSorting {
	
	public static String[] split(String input)
	{
		int c=0;
		for(int i=0;i<input.length();i++)
		{
			if(input.charAt(i)==' ')
				c++;
		}
		String[] arr=new String[c];
		String temp="";
		for(int i=0, j=0;i<input.length();i++) 
		{
			if(input.charAt(i)!=' ') {
				temp=temp+input.charAt(i);
				
			}
			else
			{
				arr[j]=temp;
				temp="";
				j++;
			}
		}
		return arr;
		}
	
	
	static void InsertionSort(String a[])
	{
		for(int j=1;j<a.length;j++)
		{
			String value=a[j];
			int hole=j-1;
			while((hole>-1)&&(a[hole-1].compareTo(value)>0))
			{
				a[hole+1]=a[hole];
				hole--;
			}
			a[hole+1]=value;
		}
	}		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String input=sc.next();
		String[] splitted=split(input+" ");
		for(int i=0;i<splitted.length;i++) {
			System.out.print(splitted[i]+" ");
		}

				System.out.println("Sorted elements are");
		
		InsertionSort(splitted);
		for(int i=0;i<splitted.length;i++)
		System.out.print(splitted[i]+" ");
		
		

	}

}
