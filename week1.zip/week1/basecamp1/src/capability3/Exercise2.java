package capability3;

import java.util.Scanner;

public class Exercise2 {
	public static int linearS(int a[],int v) {
		
		int n=a.length;
		for(int i=0;i<n;i++)
		{
			if(a[i]==v)
			{
				return i;
			}
		}return -1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the size");
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println("enter the elments in d array");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("Enter the searched elemts");
		int v=sc.nextInt();
		int res=linearS(a,v);
		if(res==-1) {
			System.out.println(" false, element is not present ");
		}
			else
				System.out.println("true,element is present");
		}

	}


