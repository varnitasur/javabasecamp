package capability3;

import java.util.Scanner;

public class Exercise3 {

	public static int Search(int a[],int n,int x)
	{
		int low=0;int high=n-1;
		int mid=(low+high)/2;
		while(low<=high)
		{
			if(x==a[mid])
				return mid;
			else if(x<a[mid])
				high=mid-1;
			else
				low=mid+1;
				
		}
		return -1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" Enter the size of array");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println(" Enter the elements");
		int a[]=new int[n];
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println(" Enter the element to be searched ");
		int x=sc.nextInt();
		int result=Search(a,n,x);
		if( result == -1)
			System.out.println("Elements are not present");
		else
			System.out.println(" Element found at index :"+result);
	}

}
