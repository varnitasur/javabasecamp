package stringDemo;

import java.util.Scanner;

public class Code5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter how many meters");
		int n =sc.nextInt();
		System.out.println("Harry has to swim at "+ n + " and must rescue "+ n+ " sea maidens");

	}

}
