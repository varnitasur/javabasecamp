package stringDemo;

import java.util.Scanner;

public class Code4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Charater");
		char ch=sc.next().charAt(0);
		if(ch>=48 && ch<=57)
		{
			System.out.println(" Failure");
		}
		else
		{
			System.out.println("harry has to pick up the flag and that has "+ch+" in it");
		}
		
	}	
}
