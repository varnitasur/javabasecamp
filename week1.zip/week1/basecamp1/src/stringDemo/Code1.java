package stringDemo;

import java.util.Arrays;
import java.util.Scanner;

public class Code1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println(" enter the number of partnership");
		int n=sc.nextInt();
		String players[][]=new String [n][3];
		
		for(int i=0;i<n;i++)
		{
			int j=0;
			System.out.println("Enter the names and their partnership");
			while(j<3)
			{
				players[i][j]=sc.nextLine();
				j++;
			}
			if(players[0][0].isEmpty()==true)
				System.out.println("true");
		}
		System.out.print(Arrays.deepToString(players));
	}
	

}
