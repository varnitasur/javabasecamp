package com.mindtree;

import java.util.Scanner;

public class Replacing {
	
	public static int[] duplicate(int a[]) {
		for(int i=0;i<a.length;i++) {
			for(int j=i+1;j<a.length;j++) {
				if(a[i]==a[j])
					a[i]=0;
					
					
			}
		}
		return a;
	}
	
	public static void pairNumber(int a[],int key) {
		boolean flag=false;
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++) {
				int sum=a[i]+a[j];
				if(sum==key) {
					flag =true;
					System.out.println("("+a[i]+","+a[j]+")");
				}
			}
			
		}	
		if(flag=false) {
			System.out.println("Not FOUND");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the size");
		int n=sc.nextInt();
		System.out.println("Enter the array elemts");
		int a[]=new int[n];
		for(int i=0;i<a.length;i++) {
			a[i]=sc.nextInt();
			
		}
		a=duplicate(a);
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]+" ");
	}
		System.out.println("Enter the key elemwnt");
		int key=sc.nextInt();
		pairNumber(a,key);
		}

}
