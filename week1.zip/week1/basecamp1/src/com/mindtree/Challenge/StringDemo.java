package com.mindtree.Challenge;

import java.util.Scanner;

public class StringDemo {
	public static String[] split(String input)
	{
		int c=0;
		for(int i=0;i<input.length();i++)
		{
			if(input.charAt(i)==' ')
				c++;
		}
		String[] arr=new String[c];
		String temp="";
		for(int i=0, j=0;i<input.length();i++) 
		{
			if(input.charAt(i)!=' ') {
				temp=temp+input.charAt(i);
				
			}
			else
			{
				arr[j]=temp;
				temp="";
				j++;
			}
		}
		return arr;
		}
	public static String replace(String splitted[],int n)
	{
		for(int i=0;i<splitted.length;i++)
		if(n>=50) {
			return "senior";
		}
			return "junior";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name and age");
		String input=sc.nextLine();
		String splitted[]=split(input+" ,");
		//System.out.println("Enter the age");
		int n=0;
		n=Integer.parseInt(splitted[1]);
		String s5=replace(splitted,n);
		System.out.println(splitted[0]+","+s5);
	}
}
