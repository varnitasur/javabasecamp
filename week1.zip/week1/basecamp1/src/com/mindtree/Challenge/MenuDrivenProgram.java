package com.mindtree.Challenge;

import java.util.Scanner;
public class MenuDrivenProgram
{
	public static int [][] Multiply(int a[][],int b[][]){
		int len1=a.length;
		int len2=b.length;
		int[][] c=new int[len1][len2];
		for(int i=0;i<len1;i++)
		{
			for(int j=0;j<len2;j++)
			{
				c[i][j]=0;
				for(int k=0;k<a.length;k++)
				
					c[i][j]+=a[i][k]*b[k][j];
				
			}
		}
		
		return c;
	}
	public  static int[] merge(int c[][]) {
		int[] c1=new int[(c.length*c.length)];
		int count=0;
		for(int i=0;i<c.length;i++)
		{
			for(int j=0;j<c.length;j++)
			{
				c1[count]=c[i][j];
				count++;
			}
		}
		return c1;
	}
public static int[] insertionSort(int[] m) {
	for(int i=1;i<m.length;i++) {
		int key=m[i];
		int hole=i-1;
		while(hole>=0 && m[hole]>key) {
			m[hole+1]=m[hole];
			hole=hole-1;
		}
		m[hole+1]=key;
	}
	return m;
}
public static int[] bsort(int []arr)
{
	for(int i=0;i<arr.length-1;i++)
	{
		for(int j=0;j<arr.length-i-1;j++)
		{
			if(arr[j]>arr[j+1])
			{
				int temp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
				
			}
		}
	}
	return arr;
}
	public static int Search(int m[],int x)
	{
		int low=0;int high=m.length-1;
		int mid=(low+high)/2;
		while(low<=high)
		{
			if(x==m[mid])
				return mid;
			else if(x<m[mid])
				high=mid-1;
			else
				low=mid-1;
				
		}
		return -1;
	}
	public static void main(String [] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the no of  elements");
		int n=sc.nextInt();
		System.out.println("Enter the matrix 1");
		int a[][]=new int[n][n];
		int b[][]=new int[n][n];
		int c[][]=new int[n][n];
		int m[]=new int[n*n];
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				a[i][j]=sc.nextInt();
			}
		}
		System.out.println("Enter the 2nd matrix");
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				b[i][j]=sc.nextInt();
			}
		}
		do
		{
			System.out.println("Enter the option: 1.insert \n 2.multiply \n3.insertion \n4.binerysearch");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:
				c=Multiply(a,b);
				for(int i=0;i<a.length;i++) {
					for(int j=0;j<b.length;j++) {
						System.out.println(c[i][j]+" ");
					}
					System.out.println();
				}
				break;
				
			case 2:
				c=Multiply(a,b);
				m=merge(c);
				for(int i=0;i<m.length;i++)
					System.out.println(m[i]+" ");
				break;
			case 3:
				c=Multiply(a,b);
				m=merge(c);
				insertionSort(m);
				for(int i=0;i<m.length;i++)
				System.out.println(m[i]+" ");
				break;
			case 4:
				c=Multiply(a,b);
				m=merge(c);
				bsort(m);
				System.out.println("Enter the number to be serached");
				int x=sc.nextInt();
				int y=Search(m,x);
				System.out.print("Element found at pos "+y);
				break;
			default:
				System.out.println("invalid input");
				System.exit(0);
			
			}
		}while(true);	
		

	}
	
}	

	
	