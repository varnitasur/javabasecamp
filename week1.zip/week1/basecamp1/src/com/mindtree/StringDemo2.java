package com.mindtree;

import java.util.Scanner;

public class StringDemo2 {
	
	public static String[] split(String str1)
	{
		int count=0;
		for(int i=0;i<str1.length();i++)
		{
			if(str1.charAt(i)==' ')
				count++;
		}
		String[] arr=new String[count];
		String temp="";
		for(int i=0, j=0;i<str1.length();i++) 
		{
			if(str1.charAt(i)!=' ') {
				temp=temp+str1.charAt(i);
				
			}
			else
			{
				arr[j]=temp;
				temp="";
				j++;
			}
		}
		return arr;
		}
	public static String reverse(String str1,char ch) {
		
		String temp=" ";
		char d=str1.charAt(0);
		for(int i=0;i<str1.length();i++)
		{	
		
				if(d==ch) {
					for(int j=str1.length()-1;j>=0;j++)
				temp=temp+str1.charAt(j);
					return temp;
		}
	}
		return str1;
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String str1=sc.next();
		sc.nextLine();
		System.out.println("Enter the character");
		char ch=sc.next().charAt(0);
		String split[]=split(str1+" ");
		String s=" ";
		System.out.println(reverse(str1,ch)); 
			
		//System.out.println(s1);
		
	}
}	

