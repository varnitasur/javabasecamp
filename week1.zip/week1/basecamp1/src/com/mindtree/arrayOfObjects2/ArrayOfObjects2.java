package com.mindtree.arrayOfObjects2;

import java.util.Scanner;

public class ArrayOfObjects2 {
	
public static void linearS(VendingMachine v[],String dn) {
	
	int a=v.length;
	
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("1.constructor  injection \n 2.setter injection");
		int ch=sc.nextInt();
		if(ch==1)
		{	
			System.out.println("Enter the no of tuck shop");
			int n=sc.nextInt();
		
			TuckShop[] t=new TuckShop[n];
			for(int i=0;i<n;i++)
			{
				System.out.println("Enter the vending machine name");
				String machineName=sc.next();
				System.out.println(" Enter the machine id");
				int machineid=sc.nextInt();
				System.out.println("Enter the power type");
				char c=sc.next().charAt(0);
				
				System.out.println("Enter the no of vending machine");
				int num=sc.nextInt();
				VendingMachine v[]=new VendingMachine[num];
				
				for(int j=0;j<num;j++) {
					System.out.println("Enter the drink name");
					String drinkName=sc.next();
					System.out.println("Enter the quantity of drink");
					float quantityOfDrink=sc.nextFloat();
					System.out.println("Enter the no of cups");
					int noOfCups=sc.nextInt();
					System.out.println("Enter the cost of one cup");
					double costOfOneCup=sc.nextDouble();
					System.out.println("Enter the type of cofee 1.light \n 2.medium \n3.strong");
					   String conc=sc.next();                                               
					v[j]=new VendingMachine(drinkName,quantityOfDrink,noOfCups,costOfOneCup,conc);
					double cost=v[i].findbill(noOfCups, costOfOneCup);
					System.out.println(cost);
				}
				t[i]=new TuckShop(machineName,machineid,c,v);
				
			}
			for(int i=0;i<t.length;i++)
				System.out.println(t[i]);
		}

		if(ch==2)
		{
			System.out.println("Enter the no of tuck shop");
			int n=sc.nextInt();
		
			TuckShop[] t=new TuckShop[n];
			for(int i=0;i<n;i++)
			{
				System.out.println("Enter the vending machine name");
				String machineName=sc.next();
				System.out.println(" Enter the machine id");
				int machineid=sc.nextInt();
				System.out.println("Enter the power type");
				char c=sc.next().charAt(0);
				
				System.out.println("Enter the no of vending machine");
				int num=sc.nextInt();
				VendingMachine v[]=new VendingMachine[num];
				
				for(int j=0;j<num;j++) {
					System.out.println("Enter the drink name");
					String drinkName=sc.next();
					System.out.println("Enter the quantity of drink");
					float quantityOfDrink=sc.nextFloat();
					System.out.println("Enter the no of cups");
					int noOfCups=sc.nextInt();
					System.out.println("Enter the cost of one cup");
					double costOfOneCup=sc.nextDouble();
					System.out.println("Enter the type of cofee 1.light \n 2.medium \n3.strong");
					   String conc=sc.next();    
					   v[j]=new VendingMachine();
					v[j].setparameters(drinkName,quantityOfDrink,noOfCups,costOfOneCup,conc);
					//double cost=v[i].findbill(noOfCups, costOfOneCup);
					//System.out.println(cost);
				}
				t[i]=new TuckShop();
				t[i].setparameters1(machineName, machineid, c, v);
				//t[i]=new TuckShop(machineName,machineid,c,v);
	
			}
			for(int i=0;i<t.length;i++) {
				System.out.println(t[i]);
				
		}

		}
		
	}

}
