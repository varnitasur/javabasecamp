package com.mindtree.arrayOfObjects2;

import java.util.Arrays;

public class TuckShop {

	private String machineName;
	private int machineId ;
	char powerTypeRequired[]= {'a','e'};
	char powerType;
	public char[] getPowerTypeRequired() {
		return powerTypeRequired;
	}
	public void setPowerTypeRequired(char[] powerTypeRequired) {
		this.powerTypeRequired = powerTypeRequired;
	}
	VendingMachine v[];
	public TuckShop() {
		
	}
	@Override
	public String toString() {
		return "TuckShop [machineName=" + machineName + ", machineId=" + machineId + ", powerType=" + powerType + ", v="
				+ Arrays.toString(v) + "]";
	}
	public TuckShop(String machineName, int machineId, char powerType, VendingMachine[] v) {
		super();
		this.machineName = machineName;
		this.machineId = machineId;
		this.powerType = powerType;
		this.v = v;
	}
	
	public String getMachineName() {
		return machineName;
	}
	public void setparameters1(String machineName, int machineId, char powerType, VendingMachine[] v){
		this.machineName = machineName;
		//this.machineName = machineName;
		this.machineId = machineId;
		this.powerType = powerType;
		this.v = v;
	}
	public int getMachineId() {
		return machineId;
	}
	public void setMachineId(int machineId) {
		this.machineId = machineId;
	}
	public char getPowerType() {
		return powerType;
	}
	public void setPowerType(char powerType) {
		this.powerType = powerType;
	}
	public VendingMachine[] getV() {
		return v;
	}
	public void setV(VendingMachine[] v) {
		this.v = v;
	}


}
