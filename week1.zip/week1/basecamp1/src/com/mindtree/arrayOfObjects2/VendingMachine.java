package com.mindtree.arrayOfObjects2;

import java.util.Arrays;

public class VendingMachine {

	private String drinkName;
	private float quantityOfDrink;
	public VendingMachine() {
		
	}
	public VendingMachine(String drinkName, float quantityOfDrink, int noOfCups, double costOfOneCup,
			String conc) {
		super();
		this.drinkName = drinkName;
		this.quantityOfDrink = quantityOfDrink;
		this.noOfCups = noOfCups;
		this.costOfOneCup = costOfOneCup;
		//this.concentration = concentration;
		this.conc=conc;
	}
	public String getConc() {
		return conc;
	}
	public void setparameters(String drinkName, float quantityOfDrink, int noOfCups, double costOfOneCup,
			String conc)  {
		this.drinkName = drinkName;
		this.quantityOfDrink = quantityOfDrink;
		this.noOfCups = noOfCups;
		this.costOfOneCup = costOfOneCup;
		//this.concentration = concentration;
		this.conc=conc;	}
	@Override
	public String toString() {
		return "VendingMachine [drinkName=" + drinkName + ", quantityOfDrink=" + quantityOfDrink + ", noOfCups="
				+ noOfCups + ", costOfOneCup=" + costOfOneCup + ", concentration=" + (conc)
				+ "]";
	}
	private int noOfCups;
	private double costOfOneCup;
	private String[] concentration= {"light","medium","strong"};
	private String conc;
	
	public String getDrinkName() {
		return drinkName;
	}
	public void setDrinkName(String drinkName) {
		this.drinkName = drinkName;
	}
	public float getQuantityOfDrink() {
		return quantityOfDrink;
	}
	public void setQuantityOfDrink(float quantityOfDrink) {
		this.quantityOfDrink = quantityOfDrink;
	}
	public int getNoOfCups() {
		return noOfCups;
	}
	public void setNoOfCups(int noOfCups) {
		this.noOfCups = noOfCups;
	}
	public double getCostOfOneCup() {
		return costOfOneCup;
	}
	public void setCostOfOneCup(double costOfOneCup) {
		this.costOfOneCup = costOfOneCup;
	}
	public String[] getConcentration() {
		return concentration;
	}
	public void setConcentration(String[] concentration) {
		this.concentration = concentration;
	}
	public double findbill(int noOfCups, double costOfOneCup) {
		double dis=(this.noOfCups*this.costOfOneCup)/10;
		double formula=((this.noOfCups*this.costOfOneCup)*(dis*0.1));
		return formula;
	}
	

}
