package com.mindtree.arrayOfobjects;

public class Department {

	private int deptId;
	private String deptName;
	Employee[] emp;
	public Department() {
		
	}
	public Department(int deptId, String deptName, Employee[] e) {
		
		this.emp = e;
	}
	public Department(int deptid2, String deptname2) {
		// TODO Auto-generated constructor stub
		this.deptId = deptid2;
		this.deptName = deptname2;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public Employee[] getE() {
		return emp;
	}
	public void setE(Employee[] e) {
		this.emp = e;
	}
}
