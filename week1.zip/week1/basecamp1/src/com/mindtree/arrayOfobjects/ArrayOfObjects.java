package com.mindtree.arrayOfobjects;

import java.util.Scanner;

public class ArrayOfObjects {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of department");
		Department d[]=new Department [sc.nextInt()];
		for(int i=0;i<d.length;i++)
		{
			d[i]=new Department();
			System.out.println("Enter the department id");
			int deptid=sc.nextInt();
			System.out.println("Enter the department name");
			String deptname=sc.next();
			System.out.println("Enter the no of employee");
			d[i] = new Department(deptid,deptname);
			d[i].emp = new Employee[sc.nextInt()];
			
			for(int j=0;j<d[i].emp.length;j++) {
				System.out.println("Enter the emp id");
				int id=sc.nextInt();
				System.out.println("Enter the emp name");
				String name=sc.next();
				d[i].emp[j]= new Employee(id,name);	
			}
		}
		for (int i = 0; i < d.length; i++) {
			for (int j = 0; j < d[i].emp.length; j++) {
				System.out.println(d[i].getDeptId()+" "+d[i].getDeptName()+" "+d[i].emp[j].getId()+" "+d[i].emp[j].getEmpName());
			}
		}
	}
}
