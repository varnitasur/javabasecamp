package com.mindtree;

import java.util.Scanner;
public class CommonWords {
	
	public static String[] split(String str1)
	{
		int c=0;
		for(int i=0;i<str1.length();i++)
		{
			if(str1.charAt(i)==' ')
				c++;
		}
		String[] arr=new String[c];
		String temp="";
		for(int i=0, j=0;i<str1.length();i++) 
		{
			if(str1.charAt(i)!=' ') {
				temp=temp+str1.charAt(i);
				
			}
			else
			{
				arr[j]=temp;
				temp="";
				j++;
			}
		}
		return arr;
		}
	
	public static String[] splitted(String str2)
	{
		int count=0;
		for(int i=0;i<str2.length();i++)
		{
			if(str2.charAt(i)==' ')
				count++;
		}
		String[] arr=new String[count];
		String temp="";
		for(int i=0, j=0;i<str2.length();i++) 
		{
			if(str2.charAt(i)!=' ') {
				temp=temp+str2.charAt(i);
				
			}
			else
			{
				arr[j]=temp;
				temp="";
				j++;
			}
		}
		return arr;
		}
	public static String[] commonWords(String split1[],String split2[]) {
		int count=0;
		String s[]=new String[split1.length*split2.length];
		for(int i=0;i<split1.length;i++)
		{
			for(int j=0;j<split2.length;j++) {
				
				if(split1[i].equals(split2[j]))
				{
					s[count]=split1[i];
					count++;
				}
			}
		}
		
		int count1=0;
		for(int i=0;i<s.length;i++) {
			if(s[i]!=null)
				count1++;
		}
		String s1[]=new String[count1];
		for(int i=0;i<s1.length;i++) {
			s1[i]=s[i];
		}
		return s1;
	}
	public static String[] sortCommonWord(String s1[]) {
		
		for(int j=1;j<s1.length;j++)
		{
			String key=s1[j];
			int hole=j-1;
			while((hole>-1)&&(s1[hole].compareTo(key)>0))
			{
				s1[hole+1]=s1[hole];
				hole--;
			}
			s1[hole+1]=key;
		}
		return s1;
		
	}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first string");
		String str1=sc.nextLine();
		System.out.println("Enter the 2nd string");
		String str2=sc.nextLine();
		String split1[]=split(str1+" ");
		String split2[]=splitted(str2+" ");
		//System.out.println(split(str1));
		//System.out.println(splitted(str2));
	/*	for(int i=0;i<split1.length;i++) 
		{
			System.out.print(split1[i]+" ");
		}
		for(int i=0;i<split2.length;i++) 
		{
			System.out.print(split2[i]+" ");
		}*/
		String s1[]=commonWords(split1,split2);
		for(int i=0;i<s1.length;i++) {
		System.out.println(s1[i]+" ");
		}
		System.out.println();
		String s2[]=sortCommonWord(s1);
		for(int i=0;i<s2.length;i++)
		{
			System.out.println(s2[i]+" ");
			
		}
		
	}

}
