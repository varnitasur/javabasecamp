package capability4;

import java.util.Scanner;

class Employee{
	 String id;
	 String name;
Employee(){
	
}
public void setName(String name)
{
	this.name=name;
}
public String getName()
{
	return name;
}
public void setid(String id)
{
	this.id=id;
}
public String getid()
{
	return id;
}

 class Department{
	 
 	 String DepartmentName;
 	 String deptId;
	 Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	for(int i=0;i<n;i++)
	{
		
	}
	Employee[] employee=new Employee[n];
	 public void setDeptId(String deptId)
	 {
	 	this.deptId=deptId;
	 }
	 public String getDeptId()
	 {
	 	return deptId;
	 }
 }

 public void setDeptId(String deptId)
 {
 	this.deptId=deptId;
 }
 public String getDeptId()
 {
 	return deptId;
 }
public class DepartmentApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
