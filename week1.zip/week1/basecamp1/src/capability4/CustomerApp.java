package capability4;

import java.util.Scanner;

public class Customer{
	
	int custid;
	String custName;
	String custAdd;
	String accType;
	public Customer(int custid, String custName, String custAdd, String accType, double custBal) {
		super();
		this.custid = custid;
		this.custName = custName;
		this.custAdd = custAdd;
		this.accType = accType;
		this.custBal = custBal;
	}
	
	public Customer(int custid, String custName) {
		super();
		this.custid = custid;
		this.custName = custName;
	}

	public Customer(int custid, String custName, String custAdd) {
		super();
		this.custid = custid;
		this.custName = custName;
		this.custAdd = custAdd;
	}

	double custBal;
	
	public void setcustId(int custid) {
		this.custid=custid;
	}
	public int getcustId() {
		return custid;
	}
	public void setcustName(String custName) {
		this.custName=custName;
	}
	public String getcustName() {
		return custName;
	}
	public void setcustAdd(String custAdd) {
		this.custAdd=custAdd;
	}
	public String getcustAdd() {
		return custAdd;
	}
	public void setaccType(String accType)
	{
		this.accType=accType;
	}
	public String getaccType() {
		return accType;
	}
	public void setcustBal(double custBal)
	{
		this.custBal=custBal;
	}public double getcustBal() {
		return custBal;
	}

	public Customer() {
		
	}
	
	
}

public class CustomerApp  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		if(n==3) {
			System.out.println("Enter customer id ,customer name ,customer address");
			Customer c1=new Customer(sc.nextInt(),sc.next(),sc.next());
			System.out.println(c1.getcustId());
			System.out.println(c1.getcustName());
			System.out.println(c1.getcustAdd());
			//System.out.println(c2.getcustAdd());
			System.out.println(c1.getcustBal());
			System.out.println(c1.getaccType());
		}
		else if(n==5) {
			System.out.println("Enter customer id ,customer name ,customer address,customer acc balance,customer acc type");
			Customer c2=new Customer(sc.nextInt(),sc.next(),sc.next(),sc.next(),sc.nextDouble());
			System.out.println(c2.getcustId());
			System.out.println(c2.getcustName());
			System.out.println(c2.getcustAdd());
			System.out.println(c2.getcustBal());
			System.out.println(c2.getaccType());
			
		}
		else
		{
			System.out.println("Enter the customer id ,cust name");
			Customer c3=new Customer(sc.nextInt(),sc.next());
			System.out.println(c3.getcustId());
			System.out.println(c3.getcustName());
			System.out.println(c3.getcustAdd());
			System.out.println(c3.getcustBal());
			System.out.println(c3.getaccType());
		}
		

	}

}
