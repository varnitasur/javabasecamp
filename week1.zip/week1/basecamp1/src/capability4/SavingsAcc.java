package capability4;
class Acc{
	double bal;
	int ir;
	int accno;
	
	public void setaccBal(double bal) {
		this.bal=bal;
	}
	public double getaccBal() {
		return bal;
	}
	public void setInterestRate(int ir) {
		this.ir=ir;
	}
	public double getInterestRate() {
		return ir;
	}
	
}
public class SavingsAcc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
