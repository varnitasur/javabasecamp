package capability4;

import java.util.Scanner;

class Book{
	String bTitle;
	String aName;
	float bcost;
	int  yOfpublication;
	
	public void setbTitle(String bTitle) {
		this.bTitle=bTitle;
		
	}
	public String getbTitle() {
		return bTitle;
	}
	public void setaName(String aName) {
		this.aName=aName;
	}
	public String getaName() {
		return aName;
	}
	public void setbcost(float bcost)
	{
		this.bcost=bcost;
	}
	public float getbcost() {
		return bcost;
	}
	public void setyOfpublication(int yOfpublication) {
		this.yOfpublication=yOfpublication;
	}
	public int getyOfpublication() {
		return yOfpublication;
	}
}

public class BookStore {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		//System.out.println("");
		Book b1=new Book();
		Book b2=new Book();
		Book b3=new Book();
		System.out.println("Enter the book title");
		b1.setbTitle(sc.next());
		System.out.println("Enter the author name");
		b1.setaName(sc.next());
		sc.nextLine();
		System.out.println("Enter the book cost");
		b1.setbcost(sc.nextFloat());
		System.out.println("Enter the set year of publication");
		b1.setyOfpublication(sc.nextInt());
		System.out.println(b1.getbTitle()+" "+b1.getaName()+" "+b1.getbcost()+" "+b1.getyOfpublication());
		
		System.out.println("Enter the book2 title");
		b2.setbTitle(sc.next());
		System.out.println("Enter the author2 name");
		b2.setaName(sc.next());
		sc.nextLine();
		System.out.println("Enter the book2 cost");
		b2.setbcost(sc.nextFloat());
		System.out.println("Enter the set year of publication of 2nd book");
		b2.setyOfpublication(sc.nextInt());
		System.out.println(b2.getbTitle()+" "+b2.getaName()+" "+b2.getbcost()+" "+b2.getyOfpublication());
		
		System.out.println("Enter the book3 title");
		b3.setbTitle(sc.next());
		System.out.println("Enter the author3 name");
		b3.setaName(sc.next());
		sc.nextLine();
		System.out.println("Enter the book3 cost");
		b3.setbcost(sc.nextFloat());
		System.out.println("Enter the set year of publication");
		b3.setyOfpublication(sc.nextInt());
		System.out.println(b3.getbTitle()+" "+b3.getaName()+" "+b3.getbcost()+" "+b3.getyOfpublication());

	}

}
