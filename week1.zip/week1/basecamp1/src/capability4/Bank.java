package capability4;

public class Bank {

	String bankcode;
	String name;
	String location;
	Customer[] c;
	public String getBankcode() {
		return bankcode;
	}
	public void setBankcode(String bankcode) {
		this.bankcode = bankcode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Customer[] getC() {
		return c;
	}
	public void setC(Customer[] c) {
		this.c = c;
	}
	public Bank(String bankcode, String name, String location, Customer[] c) {
		super();
		this.bankcode = bankcode;
		this.name = name;
		this.location = location;
		this.c = c;
	}
	public void bankloc(String bloc) {
		if(this.location.equals(bloc)) {
			System.out.println(this.name);
		}
	}
	public Bank() {
		
	}
	
	
}
