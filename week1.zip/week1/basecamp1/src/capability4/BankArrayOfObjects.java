package capability4;

import java.util.Scanner;

public class BankArrayOfObjects {
	public static  Bank[] bsort(b[i].bankcode) {
		
		int low=0;int high=b[i].length;
		int mid=(low+high)/2;
		if(b)
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no of banks");
		//int n=sc.nextInt();
		Bank[] b=new Bank[sc.nextInt()];
		for(int i=0;i<b.length;i++)
		{
			b[i]=new Bank();
			System.out.println("Enter bank code");
			String bankcode=sc.next();
			b[i].setBankcode(bankcode);		
			System.out.println("Enter bank name");
			String bankname=sc.next();
			b[i].setName(bankname);
			System.out.println("Enter location");
			String bloc=sc.next();
			b[i].setLocation(bloc);
			System.out.println("Enter the no of cutomers");
			//int num=sc.nextInt();
			b[i].c=new Customer[sc.nextInt()];
			for(int j=0;i<b[i].c.length;i++)
			{
				b[i].c[j]=new Customer();
				System.out.println("enter customer id");
				int cid=sc.nextInt();
				b[i].c[j].setId(cid);
				System.out.println("Enter customer name  ");
				String cname=sc.next();
				b[i].c[j].setName(cname);
				System.out.println("Enter the mobile number");
				String mobnum=sc.next();
				if(mobnum.length()==10) {
				b[i].c[j].setMnum(mobnum);
				System.out.println("Enter the balence");
				double cbal=sc.nextDouble();
				b[i].c[j].setBal(cbal);
				}
				else
				{
					System.out.println("enter  10 digit mobile numnber");
					return;
					}
				
			}
			
			}
		System.out.println("");
		}
	
		
	
			
		
		
		

	}

}
