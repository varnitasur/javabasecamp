package capability4;

import java.util.Scanner;

class  Details{
	int id;
	String name;
	String dept;
	String designation;
	public Details(int id2, String n, String des, String dept2) {
		// TODO Auto-generated constructor stub
		id= id2;
		name=n;
		dept=dept2;
		designation = des;
	}
	Details(){
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		if(name=="")
			return null;
		else
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		if(dept.equals("tth")||dept.equals("rcm")||dept.equals("Digital")||dept.equals("Devops"))
		return dept;
		else
			return "invalid";
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getDesignation() {
		if(designation.equals("developer")||designation.equals("tester")||designation.equals("leader")||designation.equals("manager"))
		return designation;
		else
			return "invalid";
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
}
public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Details[] d=new Details[2];
		//Details d[]= new Details(int id,String name,String dept,String designation);
		for(int i=0;i<2;i++)
		{
			System.out.println("Enter the id");
			int id=sc.nextInt();
			sc.nextLine();
			System.out.println("Enter the name");
			String n=sc.nextLine();
			System.out.println(" Enter the dept");
			String dept=sc.nextLine();
			System.out.println("Enter the designation");
			String des=sc.nextLine();
			d[i] =new Details();
			
			d[i].setName(n);
			d[i].setDept(dept);
			d[i].setDesignation(des);
			d[i].setId(id);
			
		}
			for(int i=0;i<2;i++)
				System.out.println(d[i].getName()+" "+d[i].getDept()+" "+d[i].getDesignation()+" "+d[i].getId());
			
		}
		
		

	}


