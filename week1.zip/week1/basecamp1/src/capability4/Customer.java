package capability4;

public class Customer {

	 int id;
	 String name;
	 String mnum;
	 double bal;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getMnum() {
		return mnum;
	}
	public void setMnum(String mnum) {
		this.mnum = mnum;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	public void dispbal() {
		if(this.bal>20000) {
			System.out.println("customer name :"+ this.name);
	}
	}
	public Customer() {
		
	}
	public Customer(int id, String name, String mnum, double bal) {
		super();
		this.id = id;
		this.name = name;
		this.mnum = mnum;
		this.bal = bal;
	}
	 

}
