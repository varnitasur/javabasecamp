package capability4;

class VehicleApp{

	String name;
	String color;
	double cost;
	
	VehicleApp(String name,String color,double cost) {
		this.name=name;
		this.color=color;
		this.cost=cost;
	}
	VehicleApp(){
		
	}
}
public class Vehicle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		VehicleApp obj=new VehicleApp();
		obj.name="sedan";
		obj.color="black";
		obj.cost=70000.70;

		
	System.out.println(obj.name);
	System.out.println(obj.color);
	System.out.println(obj.cost);
	
	VehicleApp obj2=new VehicleApp("swift","red",500000.50);

	System.out.println(obj2.name);
	System.out.println(obj2.color);
	System.out.println(obj2.cost);
	}
}
