package capability2;

import java.util.Scanner;

public class Challenge {
	
	public static int SumOfElements(int a[],int n)
	{
		int sum=0;
		for(int i=0;i<n;i++)
		{
			sum=sum+a[i];
		}
		return sum;
	
	}
	
public static void Pattern(int r)
{
	for(int i=1;i<=r;i++)
	{
		for(int j=1;j<=i;j++)
		{
			System.out.print("*");
		}
		System.out.println();
	}

	
}
public static void seatingArrangement(int s)
{
	if(s%12==0 || s%12==1 || s%12==6 || s%12==7 )
		System.out.println(" window side");
	else if(s%12==2 || s%12==5 || s%12==8 || s%12==11 )
		System.out.println("middle side");
	else if(s%12==3 || s%12==4 || s%12==10 || s%12==9 )
		System.out.println("asile side");
	else
		System.out.println("wrong choice");
}

public static int Palindrome(int m)
{
	
	int reverse=0;
	while(m!=0)
	{
		int remainder=m%10;
		 reverse=reverse*10+remainder;
		m=m/10;
	}
	if(m==reverse)
	return reverse;
	else
		return 0;
}
   public static void main(String[] args) {
		// TODO Auto-generated method stub
		int f=0,ch;
		 Scanner sc=new Scanner(System.in);
			
	
		    do{
			System.out.println(" 1.sum of array elemts \n 2.pattern 3.seating arrangement \n4.palindrome");
			
			System.out.println("Enter your choice");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1:
				System.out.println(" Enter the size");
				int n=sc.nextInt();
				int a[]=new int[n];
				int i;
				System.out.println("Enter the elements");
			
				for(i=0;i<n;i++)
				{
					a[i]=sc.nextInt();
				}
				System.out.print(SumOfElements(a,n));
				break;
			case 2:
				System.out.println("Enter the number of row");
				int r=sc.nextInt();
				Pattern(r);
				break;
			case 3:
				System.out.println("enter the seat number");
				int s=sc.nextInt();
				seatingArrangement(s);
				break;
			case 4:
				System.out.println("Enter the number for plaindrome");
				int m=sc.nextInt();
				System.out.println(Palindrome(m));
				break;
			case 5:
				System.out.println("exit");
				break;
			default:
				System.out.println(" wrong choice");
			}
		
			System.out.print("press 1 to continue and 0 to exit");
			f=sc.nextInt();
		}while(f!=0);
   }
}
		    
	
	

