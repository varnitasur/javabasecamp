package capability2;

import java.util.Scanner;

public class Exercise10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String id=sc.nextLine();
		int len=id.length();
		if(len<10)
			
			System.out.println("exit");
		else
		 
			if(id.charAt(0)!=1||id.charAt(0)!=2)
				System.out.println("exit");
			else
				if((!Character.isUpperCase(id.charAt(2)))&&(!Character.isUpperCase(id.charAt(3))));
					System.out.println("exit");
					else 
						for(int i=0;i<=9;i++)
						{	
							if(id.charAt(4)!=i && id.charAt(5)!=i)
								System.out.println("exit");
							else
								if(id.charAt(6)='C' && id.charAt(7)=)
	}

}
