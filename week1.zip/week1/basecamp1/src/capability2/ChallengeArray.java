package capability2;

import java.util.Scanner;
public class ChallengeArray {
	public static void originalArray(int arr[],int n)
	{ 
		int i;
		for(i=0;i<n;i++)
		{
			System.out.println( arr[i]+" ");
		}
	}
	public static void reverseArray(int arr[],int n)
	{
		for(int i=n-1;i>=0;i--)
		{
			System.out.print(arr[i]+" ");
		}
	}	
	public static void evenArray(int arr[],int n)
	{
		for(int i=0;i<n;i++)
		{
			if(arr[i]%2==0)
				System.out.print(arr[i]+" ");
		}
	}
	public static void evenPos(int arr[],int n)
	{
		for(int i=0;i<n;i++)
		{
			if(arr[i]%2==0)
				System.out.print(i+" ");
		}
		
	}
	public static void sumOddIndex(int arr[],int n,int sum)
	{ 
		
		for(int i=0;i<n;i++)
		{
			if(i%2==1)
				sum=sum+arr[i];
		}  	
	System.out.println("the sum of odd index: "+ sum);
	}
	public static void printRange(int arr[],int n,int r1,int r2)
	{
		for(int i=r1;i<=r2;i++)
			System.out.println(arr[i]+" ");
	}
	public static void sameNumber(int arr[],int n)
	{
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(arr[i]==arr[j])
					System.out.println(" index of :"+i+"index of :"+j);
					
				}
		}	
	}
	public static void rePlace(int arr[],int n,int m)
	{
		for(int i=0;i<n;i++)
		{	
			if(arr[i]==m)
			{
				arr[i]=0;
			}
		System.out.println(arr[i]+" ");
		}	
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the size of the array");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int i,j;int sum=0;
		System.out.println("Enter the elemnts of the Array");
		int arr[]=new int[n];
		for(i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the range");
		int r1=sc.nextInt();
		int r2=sc.nextInt();
		System.out.print("Enter the user defined number");
		int m=sc.nextInt();
		System.out.println(" the original array");
		     originalArray(arr,n);
		     System.out.println();
		System.out.println("Reverse array  ");
			reverseArray(arr,n);
			System.out.println();
		System.out.println("print the even elements");
				evenArray(arr,n);
				System.out.println();
		System.out.println("position of the even numbers");
			evenPos(arr,n);
			System.out.println();
		System.out.println("add all the odd positions of the array");
		sumOddIndex(arr,n,sum);
		System.out.println();
		System.out.println("print the numbers using range");
		printRange(arr,n,r1,r2);
		System.out.println();
		System.out.println("position of same numbers");
		sameNumber(arr,n);
		System.out.println();
		System.out.println("replace number");
		rePlace(arr,n,m);
		
	}
	

}
