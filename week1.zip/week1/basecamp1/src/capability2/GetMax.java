package capability2;

import java.util.Scanner;

class Max
{
	void getMax(int a,int b,int c)
	{
		if(a>b && a>c)
			System.out.println(a);
		if(b>c && b>a)
			System.out.println(b);
		if(c>a && c>b)
			System.out.println(c);
	}
}

public class GetMax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" enter the 3 numbers");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		Max m=new Max();
		m.getMax(a, b, c);

	}

}
