package capability2;

import java.util.Scanner;

public class Excersize2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		double arr1[]=new double[20];
		double arr2[]=new double[30];
		int sum[]=new int [40];
		int i,k;
		System.out.println("enter the size of array1");
		int n=sc.nextInt();
		System.out.println("enter the array elements");
		for(i=0;i<n;i++)
			{
				arr1[i]=sc.nextDouble();
			}
		System.out.println("enter the size of array2");
		int r=sc.nextInt();
		System.out.println("enter the array elements");
		for(i=0;i<r;i++)
			{
				arr2[i]=sc.nextDouble();
			}
		if(n>r)
			k=n;
		else
			k=r;
		for(i=0;i<k;i++)
		{
			sum[i]=(int)(arr1[i]+arr2[i]);
		}
		System.out.println("sum of the array elemts");
		for(i=0;i<k;i++)
		{
			System.out.print(+sum[i]+" ");
		}
	}
				
		}
			
	
		