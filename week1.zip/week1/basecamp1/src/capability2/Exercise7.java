package capability2;

import java.util.Scanner;

public class Exercise7 {

	public static String generatePassword(String name, int age) {
		String password = " ";
		for (int i = name.indexOf(" "); i > -1; i = name.indexOf(" ", i + 1))
			password = password + name.charAt(i + 1);
		return name.charAt(0) + password + age;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String name = sc.nextLine();
		int age = sc.nextInt();
		System.out.println(generatePassword(name, age));
	}

}
