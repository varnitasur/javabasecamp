package capability2;

import java.util.Scanner;

public class Exercise8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String name1=sc.nextLine();
		String name2=sc.nextLine();
		String sur1=" ",sur2=" ",newname1=" ",newname2=" ";
		int index1=name1.indexOf("-");
		for(int i=index1;i<name1.length()-1;i++)
		{
			sur1=sur1+name1.charAt(i+1);
		}
		//System.out.println(sur1);
		int index2=name2.indexOf("-");
		for(int i=index2;i<name2.length()-1;i++)
		{
			sur2=sur2+name2.charAt(i+1);
		}
		//System.out.println(sur2);
		for(int i=0;i<index1;i++)
		{
			newname1=newname1+name1.charAt(i);
		}
		System.out.print(newname1+sur2);
		for(int i=0;i<index2;i++)
		{
			newname2=newname2+name2.charAt(i);
		}
		System.out.print(newname2+sur1);
		
		
		
	}
}
