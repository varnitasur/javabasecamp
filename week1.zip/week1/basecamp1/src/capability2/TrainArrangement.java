package capability2;

import java.util.Scanner;

public class TrainArrangement {

	public static void seatingArrangement(int s) {
		if (s % 12 == 0 || s % 12 == 1 || s % 12 == 6 || s % 12 == 7) {
			System.out.println(" window side");
			if (s % 12 == 0)
				System.out.println(s - 11);
			else if (s % 12 == 1)
				System.out.println(s + 11);
			else if (s % 12 == 6)
				System.out.println(s + 1);
			else
				System.out.println(s - 1);
		}

		else if (s % 12 == 2 || s % 12 == 5 || s % 12 == 8 || s % 12 == 11) {
			System.out.println("middle side");
			if (s % 12 == 2)
				System.out.println(s + 9);
			else if (s % 12 == 5)
				System.out.println(s + 3);
			else if (s % 12 == 8)
				System.out.println(s - 3);
			else
				System.out.println(s + 9);
		}

		else if (s % 12 == 3 || s % 12 == 4 || s % 12 == 10 || s % 12 == 9) {
			System.out.println("asile side");
			if (s % 12 == 3)
				System.out.println(s + 7);
			else if (s % 12 == 4)
				System.out.println(s + 5);
			else if (s % 12 == 10)
				System.out.println(s - 7);
			else
				System.out.println(s - 5);
		} else
			System.out.println("wrong choice");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the seat number");
		int s = sc.nextInt();
		seatingArrangement(s);

	}

}
