package capability2;

import java.util.Scanner;

public class Exercise13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of the elements")
		int n=sc.nextInt();
		System.out.println(" Enter the firt array");
		int a[]=new int [n];
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println("enter the Second array");
		int b[]=new int[n];
		for(int i=0;i<n;i++)
		{
			b[i]=sc.nextInt();
		}
		for(int i=0;i<a.length;i++)
		{
			for( int j=0;j<b.length;j++)
			{
				if(a[i]==b[j])
					System.out.println("invalid");
				//else
					System.out.println(a[i]+" ");
					
			}
		}
		System.out.println(a[i]+" ");

	}

}
