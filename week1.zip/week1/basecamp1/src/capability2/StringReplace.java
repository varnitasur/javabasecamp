package capability2;

import java.util.Scanner;

public class StringReplace {
	
	public static String rev(String s) 
	{
		
		String reverseString="";
		String temp="";
		char c=' ';
		for(int i=s.length()-1;i>=0;i--) {
			c=s.charAt(i);
			if(!(c>=48 && c<=57))
			{
				temp=temp+s.charAt(i);
			}
		
		}
			reverseString=temp+reverseString;
		
			return reverseString;
				
	}

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String str=sc.next();
		System.out.println();
		System.out.println("Enter the character to be reversed");
		String ch=sc.next();
		String result="";
		for(int i=0;i<str.length()-1;i++) {
			//for(int j=0;j<mat3[i].length();j++) {
				//String str=mat3[i];
				char c=ch.charAt(0);
				if(c==str.charAt(i)) {
					result=rev(str);
				}
			}
	
		System.out.println(result);
}

		
		

	}

