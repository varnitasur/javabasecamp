package capability2;

import java.util.Scanner;

class Number
{
	
	void reverseNumber(int n)
	{
		int reverse=0;
		while(n!=0)
		{
		int remainder=n%10;
		reverse=reverse*10+remainder;
		n/=10;
		}
		System.out.println(reverse);
		
	}
	
}

public class ReverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Number obj=new Number();
		obj.reverseNumber(n);

	}

}
