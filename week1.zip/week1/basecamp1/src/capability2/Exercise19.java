package capability2;

import java.util.Scanner;

public class Exercise19 {
	public static int Leader(int a[],int n)
	{
		int j=0;
		for(int i=0;i<a.length;i++)
		{
			for( j=i;j<a.length;j++)
			{
				if(a[i]<=a[j])
					break;
			}
			if(j==a.length)
				return a[i];
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a[]=new int [n];
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			
		}
		
		
		

	}

}
