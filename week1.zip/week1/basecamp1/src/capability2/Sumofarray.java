package capability2;

import java.util.Scanner;

public class Sumofarray 
{

	public static void main(String[] args) 
	{
		System.out.println(" enter the number of elements");
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		int s=0;
		System.out.println("enter elements");

        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
		for(int i=0;i<arr.length;i++)
		{
			s=s+arr[i];
		}
			System.out.println(s);

	}

}
