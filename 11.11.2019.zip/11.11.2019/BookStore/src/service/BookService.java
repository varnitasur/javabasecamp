package service;

public interface BookService {
	

}
