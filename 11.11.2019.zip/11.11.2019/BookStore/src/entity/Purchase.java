package entity;

import java.sql.Date;
import java.util.Set;

public class Purchase {
	
	private Set<Book> books;
	private String customername;
	private String customernumber;
	private Date purchasedate;
	private int amount;
	private int purchaseid;
	
	public Purchase() {
		super();
	
	}

	public Purchase(Set<Book> books, String customername, String customernumber, Date purchasedate, int amount,
			int purchaseid) {
		super();
		this.books = books;
		this.customername = customername;
		this.customernumber = customernumber;
		this.purchasedate = purchasedate;
		this.amount = amount;
		this.purchaseid = purchaseid;
	}

	public Set<Book> getBooks() {
		return books;
	}

	public void setBooks(Set<Book> books) {
		this.books = books;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getCustomernumber() {
		return customernumber;
	}

	public void setCustomernumber(String customernumber) {
		this.customernumber = customernumber;
	}

	public Date getPurchasedate() {
		return purchasedate;
	}

	public void setPurchasedate(Date purchasedate) {
		this.purchasedate = purchasedate;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getPurchaseid() {
		return purchaseid;
	}

	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}
	
	
}
