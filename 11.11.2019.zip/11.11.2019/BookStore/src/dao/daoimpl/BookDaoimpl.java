package dao.daoimpl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import dao.BookDao;
import dbUtility.DBUtility;

public class BookDaoimpl implements BookDao {

	static DBUtility obj=new DBUtility();
	Connection con=obj.getConnection();
	@Override
	public void insertpurchasedate(String customername, String customernumber, Date purchasedate, int amount,
			int bookid) {
		String query="Insert into purchase (customer_name,customer_mobno,purchase_date,amount,book_id) values(?,?,?,?,?);";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, customername);
			ps.setString(2, customernumber);
			ps.setDate(3, purchasedate);
			ps.setInt(4, amount);
			ps.setInt(5, bookid);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public int getamountfrombook(int bookid) {
		int price=0;
		String query="select price from book where book_id='"+bookid+"' ";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ResultSet rs=null;
			rs.next(); 
				 price=rs.getInt(1);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return price;
	}

	@Override
	public void showBookfromDB() {
	
		
	}

	@Override
	public List<Integer> addBookids() {
	
		return null;
	}

}
