package dao;

import java.sql.Date;
import java.util.List;

public interface BookDao {

	void insertpurchasedate(String customername,String customernumber,Date purchasedate,int amount,int bookid);
	int getamountfrombook(int bookid);
	void showBookfromDB();
	List<Integer> addBookids();
	
	
}
