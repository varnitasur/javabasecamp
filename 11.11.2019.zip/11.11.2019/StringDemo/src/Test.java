import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String string="";
		int i;
		try {
			FileReader fr=new FileReader("C:\\Users\\M1055907\\Documents\\myfile.txt");
			try {
				FileWriter fw= new FileWriter("C:\\Users\\M1055907\\Documents\\myfile1.txt");
				while((i=fr.read())!=-1)
				{
					string+=(char) i;
					
				}
				fw.write(string);
				fw.close();
				
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
		
			
			try {
				while((i=fr.read())!=-1) {
					System.out.print((char) i);
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
