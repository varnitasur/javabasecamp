package student1client;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;


public class StudentApp1 {

	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		
		Set<Student> students=createstudents();
		
			System.out.println(students);

	}

	private static Set<Student> createstudents() {
		System.out.println("Enter student count");
		int studentcount=sc.nextInt();
		Set<Student> result=new HashSet<>();
		for (int i = 0; i < studentcount ; i++) {
			
		System.out.println("Enter the student id");
		int id=sc.nextInt();
		System.out.println("Enter the student name");
		String name=sc.next();
		Student student=new Student(id, name);
		result.add(student);
	}
		return result;
}

}
