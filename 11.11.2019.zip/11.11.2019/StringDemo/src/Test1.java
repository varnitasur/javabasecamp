import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			FileReader fr=new FileReader("C:\\Users\\M1055907\\Documents\\myfile.txt");
			BufferedReader br=new BufferedReader(fr);
			String line;
			try {
				while((line=br.readLine())!=null) {
					System.out.println(line);
				}
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		FileReader fr;
		try {
			fr = new FileReader("C:\\Users\\M1055907\\Documents\\myfile.txt");
			BufferedReader br=new BufferedReader(fr);
			
			try {
				FileWriter fw= new FileWriter("C:\\Users\\M1055907\\Documents\\file2.txt");
				BufferedWriter bw=new BufferedWriter(fw);
				String line;
				while((line=br.readLine())!=null) 
				{
					bw.write(line+"\n");
					System.out.println(line);
				}
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
