package service.serviceimpl;

import java.util.List;
import java.util.Set;

import dao.daoimpl.GotDaoImpl;
import entity.Member;
import service.GotService;

public class GotServiceimpl implements GotService {

	static GotDaoImpl obj=new GotDaoImpl();
	@Override
	public boolean inserttoDBfromclienttoservice(Set<Member> members) {
		boolean result=obj.inserttoDBfromservicetodao(members);
		return result;
	}

	@Override
	public int countofmemberswhobelongtohouseStark(int houseid) {
		int  result=obj.countofmemberswhobelongtohouseStark(houseid);
		return result;
	}

	@Override
	public List<Member> selectwhobelongtotargyen() {
		List<Member> result=obj.selectwhobelongtotargyen();
		return result;
	}

	@Override
	public boolean checkstatus(int memberid) {
		boolean result=obj.checkstatus(memberid);
		return result;
	}

}
