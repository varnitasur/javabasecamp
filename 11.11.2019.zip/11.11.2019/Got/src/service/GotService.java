package service;

import java.util.List;
import java.util.Set;

import entity.Member;

public interface GotService {

	boolean inserttoDBfromclienttoservice(Set<Member> members);
	int countofmemberswhobelongtohouseStark(int houseid);
	List<Member> selectwhobelongtotargyen();
	boolean checkstatus(int memberid);
	
}
