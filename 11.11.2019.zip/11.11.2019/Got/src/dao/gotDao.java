package dao;

import java.util.List;
import java.util.Set;

import entity.House;
import entity.Member;

public interface gotDao {

	boolean inserttoDBfromservicetodao(Set<Member> members);
	int countofmemberswhobelongtohouseStark(int houseid);
	//Set<House> getallinformationofhousedetaild();
	List<Member> selectwhobelongtotargyen();
	boolean checkstatus(int memberid);
}
