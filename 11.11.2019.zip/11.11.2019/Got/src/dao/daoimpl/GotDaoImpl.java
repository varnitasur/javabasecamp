package dao.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import dao.gotDao;
import dbUtility.DBUtility;
import entity.House;
import entity.Member;

public class GotDaoImpl implements gotDao {

	static DBUtility obj=new DBUtility();
	Connection con=obj.getConnection();
	@Override
	public List<Member> selectwhobelongtotargyen() {
		List<Member> result=new ArrayList<>();
		String query="select house_id from house";
		int id=0;
		try {
			Statement s=con.createStatement();
			ResultSet rs=s.executeQuery(query);
			while(rs.next())
			{
				 id=rs.getInt(1);
			}
			String query1="Select * from member inner join house on house.member_id=member.member_id  where house_id='"+id+"'";
			PreparedStatement ps=con.prepareStatement(query1);
			ResultSet rs1=ps.executeQuery();
			while(rs1.next()) {
				int id1=rs1.getInt(1);
				String name=rs.getString(2);
				boolean value=rs.getBoolean(3);
				Member m=new Member(id1, name, value);
				result.add(m);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
				
	@Override
	public int countofmemberswhobelongtohouseStark(int houseid) {
		int result=0;
		//step 2:create query
		String query="select member_id,count(member_id) from house group by member_id where house_id=6";
		Statement st=null;
		ResultSet rs=null;
		try {
			st=con.createStatement();
			rs=st.executeQuery(query);
			while(rs.next())
			{
				result=rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public boolean checkstatus(int memberid) {
		boolean id=false;
		String query="select isAlive from member";
		try {
			Statement s=con.createStatement();
			ResultSet rs=s.executeQuery(query);
			while(rs.next())
			{
				id=rs.getBoolean(1);
			}
			if(id==false)
			{
				String query1="delete from member where isalive=false";
				PreparedStatement st=con.prepareStatement(query1);
				st.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public boolean inserttoDBfromservicetodao(Set<Member> members) {
		boolean val= false;
		int count=0;
		//step 2:create query
		String query="insert into member (member_id,member_name,isAlive) values (?,?,?);";
		//step 3:choose statement
		 PreparedStatement preparedst=null;
		 
		 try {
			preparedst=con.prepareStatement(query);
		
			for (Member member : members) {
				preparedst.setInt(1, member.getMemberid());
				preparedst.setString(2, member.getMembername());
				preparedst.setBoolean(3, member.isAlive());
				count++;
				preparedst.executeUpdate();
			}
			
			if(count !=0)
			{
				val=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return val;
	}


}
