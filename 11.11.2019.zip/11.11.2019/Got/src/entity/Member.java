package entity;

public class Member {

	private int memberid;
	private String membername;
	  boolean  isAlive;
	 
	public Member() {
		super();
		
	}

	public Member(int memberid, String membername, boolean isAlive) {
		super();
		this.memberid = memberid;
		this.membername = membername;
		this.isAlive = isAlive;
	}

	public int getMemberid() {
		return memberid;
	}

	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}

	public String getMembername() {
		return membername;
	}

	public void setMembername(String membername) {
		this.membername = membername;
	}

	public boolean isAlive() {
		return isAlive;
	}

	public void setAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}
	
}
