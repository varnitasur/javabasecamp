package client;

import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import entity.Member;
import service.serviceimpl.GotServiceimpl;

public class GotApp {

	static Scanner sc=new Scanner(System.in);
	static GotServiceimpl obj=new GotServiceimpl();
	public static void main(String[] args) {
		
		Set<Member> members=createmembers();
		
		while(true) {
			System.out.println("Enter your choice:");
			System.out.println("1:add the member details \n 2.retrieve all the details from house id 2 \n 3.count the number of members present in starkhouse \n 4.check memberid  ");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				boolean val=obj.inserttoDBfromclienttoservice(members);
				if(val)
				{
					System.out.println("Inserted succesfully");
				}
				else
					System.out.println("not inserted");
				break;
				
			case 2:
				List<Member> result=obj.selectwhobelongtotargyen();
				for (Member member : result) {
					System.out.println("Member id :"+member.getMemberid());
					System.out.println("Member name: "+member.getMembername());
					System.out.println("Member isAlive: "+member.isAlive());
				}
				break;
			case 3:
				System.out.println("Enter the house id for Targaryen");
				int houseid=sc.nextInt();
				 int result1=obj.countofmemberswhobelongtohouseStark(houseid);
				 
			case 4:
				System.out.println("Enter the member id");
				int memberid=sc.nextInt();
				boolean val2=obj.checkstatus(memberid);
				if(val2)
				{
					System.out.println("deleted succesfully");
				}
				else
					System.out.println("not deleted");
			}
		}	
	
			
}
	private static Set<Member> createmembers() {
		Set<Member> result=new HashSet<>();
		System.out.println("Enter the member count");
		int membercount=sc.nextInt();
		for (int i = 0; i < membercount; i++) 
		{
			System.out.println("Enter the member id");
			int id=sc.nextInt();
			System.out.println("Enter the member name");
			String name=sc.next();
			System.out.println("Enter the checkstatus");
			boolean isAlive = sc.nextBoolean();
			Member member=new Member(id, name, isAlive);
			result.add(member);
		}

		return result;
	}

}
