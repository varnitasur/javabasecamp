package entity;

import java.util.Set;

public class Brand {

	private int brandid;
	private String brandname;
	private int rating;
	private Set<Product> products;

	public Brand(int brandid, String brandname, int rating, Set<Product> products) {
		super();
		this.brandid = brandid;
		this.brandname = brandname;
		this.rating = rating;
		this.products = products;
	}

	public Brand() {
		super();
	}

	public int getBrandid() {
		return brandid;
	}

	public void setBrandid(int brandid) {
		this.brandid = brandid;
	}

	public String getBrandname() {
		return brandname;
	}

	public void setBrandname(String brandname) {
		this.brandname = brandname;
	}

	

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public Set<Product> getProducts() {
		return products;
	}

	public void setProducts(Set<Product> products) {
		this.products = products;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + brandid;
		result = prime * result + ((brandname == null) ? 0 : brandname.hashCode());
		result = prime * result + ((products == null) ? 0 : products.hashCode());
		result = prime * result + rating;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Brand other = (Brand) obj;
		if (brandid != other.brandid)
			return false;
		if (brandname == null) {
			if (other.brandname != null)
				return false;
		} else if (!brandname.equals(other.brandname))
			return false;
		if (products == null) {
			if (other.products != null)
				return false;
		} else if (!products.equals(other.products))
			return false;
		if (rating != other.rating)
			return false;
		return true;
	}

			

}
