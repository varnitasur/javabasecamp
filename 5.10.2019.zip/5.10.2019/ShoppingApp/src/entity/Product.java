package entity;

public class Product {

	private int productid;
	private String productName;
	private int productprice;

	public Product(int productid, String productName, int productprice) {
		super();
		this.productid = productid;
		this.productName = productName;
		this.productprice = productprice;
	}

	public Product() {

	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductprice() {
		return productprice;
	}

	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}

}
