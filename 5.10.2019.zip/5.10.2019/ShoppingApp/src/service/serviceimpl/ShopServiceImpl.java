package service.serviceimpl;

import java.util.HashSet;
import java.util.Set;

import entity.Brand;
import entity.Product;
import entity.Shop;
import service.ShopService;

public class ShopServiceImpl implements ShopService {

	@Override
	public Set<Product> getAllproductsbyprice(Set<Shop> shops,int productprice,int brandrating) {
		Set<Product> result=new HashSet<>();
		for (Shop shop : shops){
			Set<Brand> brands=shop.getBrands();
			for (Brand brand1 : brands) {
				Set<Product> products=brand1.getProducts();
				for (Product pro :products ) {
					if((pro.getProductprice()==productprice) && (brand1.getRating()==brandrating))
					{
						result=brand1.getProducts();
				}
				
			}
			
		}
		
		}
		
		return result;
	}
}

	
	/*public Set<Product> getAllProductsbyrating(Set<Shop> shops, int brandrating) {
		
		Set<Product> result1=new HashSet<>();
		for (Shop shop : shops){
			Set<Brand> brands=shop.getBrands();
			for (Brand brand1 : brands) 
			{
				if(brand1.getRating()==brandrating)
					result1=brand1.getProducts();
				
				
			}
			
		}
		
		return result1;
	}

	
	
	
}*/
