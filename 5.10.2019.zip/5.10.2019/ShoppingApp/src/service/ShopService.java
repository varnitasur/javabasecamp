package service;

import java.util.Set;

import entity.Product;
import entity.Shop;

public interface ShopService {

	//get all products whose price is less than hundred
	
	Set<Product> getAllproductsbyprice(Set<Shop> shops,int  productprice,int brandrating);
	//get all product details whose rating is more than 8
	//Set<Product> getAllProductsbyrating(Set<Shop> shops,int brandrating);
}
