package client;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import entity.Brand;
import entity.Product;
import entity.Shop;
import service.ShopService;
import service.serviceimpl.ShopServiceImpl;

public class ShoppingApplication {

	static Scanner sc=new Scanner(System.in);
	static ShopService sp= new ShopServiceImpl();
	public static void main(String[] args) {
		
		System.out.println("Enter the no of Shops");
		int count=sc.nextInt();
		//create shop collection
		Set<Shop> shops=createShopCollections(count);
		
		System.out.println("Enter of product details whose price is more than 100 and rating more than 8");
		int searchprice=sc.nextInt();
		int searchbrandrating=sc.nextInt();
		Set<Product> products=sp.getAllproductsbyprice(shops,searchprice,searchbrandrating);
		
		for (Product product : products) {
			System.out.println("Details of the product");
			System.out.println("==============");
			System.out.println("product id: "+product.getProductid());
			System.out.println("product Name: "+product.getProductName());
			System.out.println("product price: "+product.getProductprice());
		}
		
		
	}
	private static Set<Shop> createShopCollections(int count) {
		Set<Shop> result=new HashSet<>();
		for (int i = 0; i < count; i++) {
			System.out.println("Enter the details of "+(i+1)+"th shop");
			System.out.println("======================================");
			System.out.println("Enter the shop id");
			int shopid=sc.nextInt();
			System.out.println("Enter the shop Name");
			String shopname=sc.next();
			
			System.out.println("Enter the brand count");
			int brandcount=sc.nextInt();
			Set<Brand> brands=createBrandCollection(brandcount);
			
			Shop shop= new Shop(shopid,shopname,brands);
			result.add(shop);
		}
		return result;
	}
	private static Set<Brand> createBrandCollection(int brandcount) {
		Set<Brand> result=new HashSet<>();
		for (int i = 0; i < brandcount; i++) {
			System.out.println("Enter the details of "+(i+1)+"th brand");
			System.out.println("======================================");
			System.out.println("Enter the brand id");
			int brandid=sc.nextInt();
			System.out.println("Enter the brand name");
			String brandname=sc.next();
			System.out.println("Enter the rating");
			int brandrating=sc.nextInt();
			
			System.out.println("Enter the product count");
			int productcount=sc.nextInt();
			Set<Product> products=createProductCollection(productcount);
			
			Brand brand=new Brand(brandid,brandname,brandrating,products);
			result.add(brand);
			
		}
		return result;
	}
	private static Set<Product> createProductCollection(int productcount) {
		Set<Product> result=new HashSet<>();
		for (int i = 0; i < productcount; i++) {
			System.out.println("Enter the details of "+(i+1)+"th product");
			System.out.println("======================================");
			System.out.println("Enter the product id");
			int productid=sc.nextInt();
			System.out.println("Enter the product name");
			String productname=sc.next();
			System.out.println("Enter the product price");
			int productprice=sc.nextInt();
			
			Product product=new Product(productid,productname,productprice);
			result.add(product);
			
		}
		return result;
	}

}
