package com.mindtree.student.controller;

import java.util.Set;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.student.entity.Student;
import com.mindtree.student.exception.StudentServiceException;
import com.mindtree.student.service.serviceimpl.StudentServiceImpl;

@RestController
public class DemoController {
	
	StudentServiceImpl serviceobj= new StudentServiceImpl();
	
	@GetMapping("/getalldetails")
	public Set<Student> getAllStudentDetails(){
		Set<Student> result = null;
		try {
			result = serviceobj.getallStudentdetails();
		} catch (StudentServiceException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return result;
		
	}
	@PostMapping("/insertdetails")
	public String insertStudentDetails(@RequestBody Student student) {
		String m=serviceobj.insertStudentDetails(student);
		return m;
		
	}

}
