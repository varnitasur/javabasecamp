package com.mindtree.student.service.serviceimpl;

import java.util.Set;

import com.mindtree.student.dao.daoimpl.StudentDaoImpl;
import com.mindtree.student.entity.Student;
import com.mindtree.student.exception.StudentDaoException;
import com.mindtree.student.exception.StudentServiceException;
import com.mindtree.student.service.StudentService;

public class StudentServiceImpl implements StudentService {

	StudentDaoImpl daoobj= new StudentDaoImpl();
	
	public Set<Student> getallStudentdetails() throws StudentServiceException {
		Set<Student> result;
		try {
			result = daoobj.getallstudentdetail();
		} catch (StudentDaoException e) {
			// TODO Auto-generated catch block
			throw new StudentServiceException();
		}
		return result;
	}

	public String insertStudentDetails(Student student) {
		String m= daoobj.insertStudentDetails(student);
		return m;
	}

}
