package com.mindtree.student.dao.daoimpl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import com.mindtree.student.dao.StudentDao;
import com.mindtree.student.entity.Student;
import com.mindtree.student.exception.StudentDaoException;
import com.mindtree.student.utility.DBUtility;


public class StudentDaoImpl implements StudentDao {

	static DBUtility obj= new DBUtility();
	
	
	public Set<Student> getallstudentdetail() throws StudentDaoException  {
		Set<Student> result=new HashSet<Student>();
		Connection con=obj.getConnection();
		try {
			CallableStatement clstmt=con.prepareCall("{call getallStudents()}");
			ResultSet rs=clstmt.executeQuery();
			while(rs.next()) {
				int id=rs.getInt(1);
				String name=rs.getString(2);
				String work=rs.getString(3);
				Student student= new Student(id, name, work);
				result.add(student);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		throw new StudentDaoException();
		}
		return result;
	}


	public String insertStudentDetails(Student student) {
		Connection con;
		try {
			con = obj.getConnection();
			CallableStatement clstmt=null;
			try {
				clstmt= con.prepareCall("{call insertStudent1('"+student.getStudentid()+"','"+student.getStudentname()+"','"+student.getStudentwork()+"')}");
				
				clstmt.executeUpdate();
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (StudentDaoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return "inserted";
	}

}
