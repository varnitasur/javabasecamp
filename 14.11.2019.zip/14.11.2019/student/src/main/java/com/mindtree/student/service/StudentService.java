package com.mindtree.student.service;

import java.util.Set;

import com.mindtree.student.entity.Student;
import com.mindtree.student.exception.StudentServiceException;

public interface StudentService {
	
	public Set<Student> getallStudentdetails() throws StudentServiceException;
	public String  insertStudentDetails(Student student);

}
