package com.mindtree.student.entity;

public class Student {
	
	private int studentid;
	private String studentname;
	private String studentwork;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int studentid, String studentname, String studentwork) {
		super();
		this.studentid = studentid;
		this.studentname = studentname;
		this.studentwork = studentwork;
	}
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public String getStudentwork() {
		return studentwork;
	}
	public void setStudentwork(String studentwork) {
		this.studentwork = studentwork;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + studentid;
		result = prime * result + ((studentname == null) ? 0 : studentname.hashCode());
		result = prime * result + ((studentwork == null) ? 0 : studentwork.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (studentid != other.studentid)
			return false;
		if (studentname == null) {
			if (other.studentname != null)
				return false;
		} else if (!studentname.equals(other.studentname))
			return false;
		if (studentwork == null) {
			if (other.studentwork != null)
				return false;
		} else if (!studentwork.equals(other.studentwork))
			return false;
		return true;
	}
	
	

}
