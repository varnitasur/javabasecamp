package com.mindtree.student.dao;

import java.util.Set;

import com.mindtree.student.entity.Student;
import com.mindtree.student.exception.StudentDaoException;

public interface StudentDao {
	
	
	
	public Set<Student> getallstudentdetail() throws StudentDaoException;
	public String insertStudentDetails(Student student);
	

}
