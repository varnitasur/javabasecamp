package com.mindtree.student.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mindtree.student.exception.StudentDaoException;

public class DBUtility {
	private static final String URL="jdbc:mysql://localhost:3306/database";
	private static final String USER_NAME="root";
	private static final String PASSWORD="Welcome123";
	private static Connection con;
	public Connection getConnection() throws StudentDaoException {
		Connection con = null;

		try {
			con = DriverManager.getConnection(URL,USER_NAME , PASSWORD);
		} catch (SQLException e) {
			throw new StudentDaoException("Connection failed");
		}

		return con;
	}
	public static void closeConnection() throws StudentDaoException {

		try {
			con.close();
			System.out.println("Connection is closed");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		//	System.out.println("Unable to close database connection");
		//	System.out.println(e);
			// e.printStackTrace();
			throw new StudentDaoException("Connection failed");
		}

	}

}
