package com.mindtree.MovieTicket.dao.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mindtree.MovieTicket.dao.MovieDao;
import com.mindtree.MovieTicket.entity.Movie;
import com.mindtree.MovieTicket.exception.ConnectionFailedException;
import com.mindtree.MovieTicket.exception.DaoException;
import com.mindtree.MovieTicket.utility.DBUtility;

public class MovieDaoImpl implements MovieDao {

	static DBUtility obj=new DBUtility();
	Connection con=obj.getConnection();
	public List<Movie> getMovie() {
		List<Movie> result= new ArrayList<Movie>();
		String query="select * from movie";
		Statement s=null;
		try(Connection con=obj.getConnection()) {
			s=con.createStatement();
			ResultSet rs=s.executeQuery(query);
			while(rs.next()) {
				int id=rs.getInt(1);
				String name=rs.getString(2);
				int price=rs.getInt(3);
				int tid=rs.getInt(4);
				Movie m= new Movie(id, name, price, tid);
				result.add(m);
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
			
		}
		return result;
	}

	public String addMovie(int movieid, int theatreid) throws DaoException{
		String query="update movie set theatre_id=? where movie_id=?";
		PreparedStatement ps=null;
		try {
			ps=con.prepareStatement(query);
			ps.setInt(1, theatreid);
			ps.setInt(2, movieid);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		throw new DaoException(e.getMessage());
		}
		return "updated succesfully";
	}

	public String isupdate(int bookingprice) throws DaoException{
		

		String query="update movie set booking_price=? where movie_id is null";
		try(Connection con=obj.getConnection()) {
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, bookingprice);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new DaoException(e.getMessage());
		}
		
		
		 
		return "updated";
	}

}
