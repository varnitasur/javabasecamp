package com.mindtree.MovieTicket.dao;

import java.sql.SQLException;
import java.util.List;

import com.mindtree.MovieTicket.entity.Movie;
import com.mindtree.MovieTicket.exception.ApplicationException;
import com.mindtree.MovieTicket.exception.DaoException;

public interface MovieDao {
	
	public List<Movie> getMovie() throws SQLException,ApplicationException,DaoException;
	public String addMovie(int movieid,int theatreid) throws DaoException;
	public String isupdate(int bookingprice) throws DaoException;
	

}
