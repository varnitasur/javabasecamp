package com.mindtree.MovieTicket.entity;

public class Theatre {
	
	private int theatreid;
	private String theatrename;
	public Theatre() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Theatre(int theatreid, String theatrename) {
		super();
		this.theatreid = theatreid;
		this.theatrename = theatrename;
	}
	public int getTheatreid() {
		return theatreid;
	}
	public void setTheatreid(int theatreid) {
		this.theatreid = theatreid;
	}
	public String getTheatrename() {
		return theatrename;
	}
	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}
	

}
