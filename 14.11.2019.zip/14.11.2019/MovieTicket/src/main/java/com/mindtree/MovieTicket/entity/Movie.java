package com.mindtree.MovieTicket.entity;

public class Movie {
	
	private int movieid;
	private String moviename;
	private int bookingprice;
	private int theatreid;
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Movie(int movieid, String moviename, int bookingprice, int theatreid) {
		super();
		this.movieid = movieid;
		this.moviename = moviename;
		this.bookingprice = bookingprice;
		this.theatreid = theatreid;
	}
	public int getMovieid() {
		return movieid;
	}
	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}
	public String getMoviename() {
		return moviename;
	}
	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}
	public int getBookingprice() {
		return bookingprice;
	}
	public void setBookingprice(int bookingprice) {
		this.bookingprice = bookingprice;
	}
	public int getTheatreid() {
		return theatreid;
	}
	public void setTheatreid(int theatreid) {
		this.theatreid = theatreid;
	}
	

}
