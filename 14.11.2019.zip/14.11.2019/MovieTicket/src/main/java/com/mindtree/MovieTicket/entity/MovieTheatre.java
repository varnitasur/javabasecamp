package com.mindtree.MovieTicket.entity;

public class MovieTheatre {
	
	private int theatreid;
	private String theatrename;
	private int movieid;
	private String moviename;
	private int bookingprice;
	public MovieTheatre() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MovieTheatre(int theatreid, String theatrename, int movieid, String moviename, int bookingprice) {
		super();
		this.theatreid = theatreid;
		this.theatrename = theatrename;
		this.movieid = movieid;
		this.moviename = moviename;
		this.bookingprice = bookingprice;
	}
	public int getTheatreid() {
		return theatreid;
	}
	public void setTheatreid(int theatreid) {
		this.theatreid = theatreid;
	}
	public String getTheatrename() {
		return theatrename;
	}
	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}
	public int getMovieid() {
		return movieid;
	}
	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}
	public String getMoviename() {
		return moviename;
	}
	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}
	public int getBookingprice() {
		return bookingprice;
	}
	public void setBookingprice(int bookingprice) {
		this.bookingprice = bookingprice;
	}
	

}
