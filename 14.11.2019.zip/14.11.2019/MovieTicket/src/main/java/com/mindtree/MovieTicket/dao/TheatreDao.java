package com.mindtree.MovieTicket.dao;

import java.sql.SQLException;
import java.util.List;

import com.mindtree.MovieTicket.entity.Theatre;
import com.mindtree.MovieTicket.exception.DaoException;

public interface TheatreDao {

	public List<Theatre> getTheatre() throws SQLException,DaoException;
}
