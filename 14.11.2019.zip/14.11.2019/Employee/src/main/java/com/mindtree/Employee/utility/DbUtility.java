package com.mindtree.Employee.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtility {

	private static final String URL="jdbc:mysql://localhost:3306/varnita";
	private static final String USER_NAME="root";
	private static final String PASSWORD="Welcome123";
	private static Connection con;
	public Connection getConnection() {
		Connection con = null;

		try {
			con = DriverManager.getConnection(URL,USER_NAME , PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return con;
	}
	public static void closeConnection() {

		try {
			con.close();
			System.out.println("Connection is closed");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Unable to close database connection");
			System.out.println(e);
			// e.printStackTrace();
		}

	}
}
