package com.mindtree.Employee.dao.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mindtree.Employee.dao.DepartmentDao;
import com.mindtree.Employee.enitity.Department;
import com.mindtree.Employee.enitity.Employee;
import com.mindtree.Employee.utility.DbUtility;


public class DepartmentDaoImpl implements DepartmentDao {

	
	static DbUtility obj=new DbUtility();
	
	@Override
	public boolean isInserted(Department d) {
		boolean val=false;
		String query="insert into department values(?,?)";
		try (Connection con=obj.getConnection()){
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, d.getDeptid());
			ps.setString(2, d.getDeptname());
			ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return val ;
	}
	
	public List<Department> getAllEmployeeDetails() {
		List<Department> list=new ArrayList<Department>();
		String query=" SELECT department.department_id,department.department_name,employees.employee_id, employees.employee_name,employees.salary "
				+ "FROM department INNER JOIN employees ON department.department_id = employees.department_id;";
		PreparedStatement ps;
		try(Connection con=obj.getConnection()) {
			ps = con.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				Department d=new Department();
					List<Employee> result=new ArrayList<>();
					Employee e=new Employee();
				d.setDeptid(rs.getInt(1));
				d.setDeptname(rs.getString(2));
				e.setEmployeeid(rs.getInt(3));
				e.setEmployeename(rs.getString(4));
				e.setSalary(rs.getInt(5));
				result.add(e);
				d.setEmployees(result);
				list.add(d);
			}
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public boolean isInsertedemployees(List<Employee> employees, int deptid) {
		String query2="insert into employees values(?,?,?,?)";
		try (Connection con=obj.getConnection()){
		PreparedStatement pd=con.prepareStatement(query2);
		for (Employee e: employees) {
			pd.setInt(1, e.getEmployeeid());
			pd.setString(2, e.getEmployeename());
			pd.setInt(3, e.getSalary());
			pd.setInt(4, deptid);
			pd.executeUpdate();
			
		}
		}
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return false;
	}

}
