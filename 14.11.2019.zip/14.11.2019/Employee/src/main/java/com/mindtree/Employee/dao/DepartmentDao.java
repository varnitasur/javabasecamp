package com.mindtree.Employee.dao;

import java.util.List;

import com.mindtree.Employee.enitity.Department;
import com.mindtree.Employee.enitity.Employee;

public interface DepartmentDao {
	
	
	List<Department> getAllEmployeeDetails();
	boolean isInserted(Department d);
	boolean isInsertedemployees(List<Employee> employees,int deptid);

}
