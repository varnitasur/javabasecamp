package com.mindtree.Employee.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.Employee.dao.DepartmentDao;
import com.mindtree.Employee.dao.daoimpl.DepartmentDaoImpl;
import com.mindtree.Employee.enitity.Department;
import com.mindtree.Employee.enitity.Employee;

@RestController
public class Controller {

	static DepartmentDao dd= new DepartmentDaoImpl();
	
	@GetMapping("/getmsg")
	public List<Department> getmessage()
	{
		List<Department> result=dd.getAllEmployeeDetails();
		return result;
	}
	@PostMapping("/insert")
	public boolean isInserttoDB(@RequestBody Department d)
	{
		boolean isCheck=false;
		if(dd.isInserted(d))
		{
			isCheck=true;
		}
		return isCheck;
	}
}
