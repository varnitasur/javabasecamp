package com.mindtree.sample.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.mindtree.sample.Product.Product;
import com.mindtree.sample.utility.DBUtility;


public class ProductDaoImpl {
	
	static DBUtility obj=new DBUtility();
	public void isInserttoDB(List<Product> products) {
		Connection con=obj.getConnection();
		boolean val=false;
		int count=0;
		String query="insert into product (product_id,product_name) values (?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			for (Product product : products) {
				
				ps.setInt(1, product.getProductid());
				ps.setString(2, product.getProductname());
				count++;
				ps.executeUpdate();
				
			}	
			if(count!= 0)
			{
				val=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public List<Product> getproducts() {
		Connection con=obj.getConnection();
		String query="select * from product";
		Statement st=null;
		ResultSet rs=null;
		List<Product> result=new ArrayList<Product>();
		try {
			st=con.createStatement();
			rs=st.executeQuery(query);
			
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				Product p=new Product(id, name);
				result.add(p);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
	public void isupdate(int id,String n) {
		Connection con=obj.getConnection();
		String query="update product set product_name=? where product_id=?";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, n);
			ps.setInt(2, id);
				ps.executeUpdate();
				
				
			}
			
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void isdelete(int id) {
		Connection con=obj.getConnection();
		String query="delete from product where product_id=?";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, id);
				ps.executeUpdate();
				
				
			}
			
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
