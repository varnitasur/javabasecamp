package com.mindtree.sample.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.sample.Product.Product;
import com.mindtree.sample.dao.ProductDaoImpl;


@RestController
public class Controller {
	
	static ProductDaoImpl pd=new ProductDaoImpl();
	// static List<Product> products=new ArrayList();
	
	/* 	@GetMapping("/getmsg")
	 	public List<Product> getProducts(){
	 		
		pd.isInserttoDB(products);
	 	}
	 	*/
	 	
////		if(list)
////		{
//			for (Product product : products) {
//				System.out.println("Product id:"+product.getProductid());
//				System.out.println("Product name: "+product.getProductname());
//			}
////		}
//		else {
//			System.out.println("not added");
//		}
	

	
	@PostMapping("/insert")
	public String postmsg(@RequestBody List<Product> products) {
		
//		for (Product product : products) {
//			System.out.println("Product id:"+product.getProductid());
//			System.out.println("Product name:"+product.getProductname());
//		}
		//System.out.println(products);
	pd.isInserttoDB(products);
	
		return "Added succesfully";
		
	}
		
	@GetMapping("/getmsg")
	public List<Product> getmessage()
	{
		List<Product> result=pd.getproducts();
		return result;
	}
		
	@PutMapping("/putmsg/{id}/{n}")
	public String update(@PathVariable int id,@PathVariable String n)
	{
		pd.isupdate(id,n);
		return "Updated";
	}
	@DeleteMapping("/deletemsg/{id}")
	public String delete(@PathVariable int id)
	{
		pd.isdelete(id);
		return "Deleted Successfully";
	}
	

	
	/*@GetMapping("/getSpring/{s}/{r}/{a}")
	public String getMessage(@PathVariable String s,@PathVariable String r,@PathVariable int a) {
		
		return "hello"+" "+ s + " "+r+" "+a ;
	}*/

}
