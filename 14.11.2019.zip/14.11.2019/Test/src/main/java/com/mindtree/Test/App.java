package com.mindtree.Test;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void   main( String[] args )
    {
    	int a=returnValueFromMethod();
    	System.out.println(a);
    	
    }

	private static int returnValueFromMethod() {
		// TODO Auto-generated method stub
		
		 int result = 5;
		 try {
			 result=5/5;
			 return 5;
		 }
		 catch(ArithmeticException e) {
			 return 7;
		 }
		 finally {
			 return 6;
		 }
         
	}
	
}
