package com.mindtree.universitymanagementapplication.service.serviceimpl;

import java.util.ArrayList;
import java.util.Set;

import com.mindtree.universitymanagementapplication.dao.daoimpl.UniverityDaoImpl;
import com.mindtree.universitymanagementapplication.entity.College;
import com.mindtree.universitymanagementapplication.entity.University;
import com.mindtree.universitymanagementapplication.service.UniversityService;

public class UniversityServiceImpl implements UniversityService {

	static UniverityDaoImpl obj=new UniverityDaoImpl();
	@Override
	public boolean isInsertedtodao(Set<University> universities) {
		boolean result=obj.isInserttoDB(universities);
		return result;
	}
	@Override
	public boolean isInsertedtodao(ArrayList<College> college, String universityname) {
		boolean result=obj.isInsert(college, universityname);
		return result;
	}

}
