package com.mindtree.universitymanagementapplication.service;

import java.util.ArrayList;
import java.util.Set;

import com.mindtree.universitymanagementapplication.entity.College;
import com.mindtree.universitymanagementapplication.entity.University;

public interface UniversityService {

	boolean isInsertedtodao(Set<University> universities);
	boolean isInsertedtodao(ArrayList<College> college,String universityname);
}
