package com.mindtree.universitymanagementapplication.entity;

import java.util.Set;

public class College {

	private int collegeid;
	private String collegename;
	private int collegerating;	
	public College() {
		super();
		
	}
	public College(int collegeid, String collegename, int collegerating) {
		super();
		this.collegeid = collegeid;
		this.collegename = collegename;
		this.collegerating = collegerating;
	}
	public int getCollegeid() {
		return collegeid;
	}
	public void setCollegeid(int collegeid) {
		this.collegeid = collegeid;
	}
	public String getCollegename() {
		return collegename;
	}
	public void setCollegename(String collegename) {
		this.collegename = collegename;
	}
	public int getCollegerating() {
		return collegerating;
	}
	public void setCollegerating(int collegerating) {
		this.collegerating = collegerating;
	}


	
	
}
