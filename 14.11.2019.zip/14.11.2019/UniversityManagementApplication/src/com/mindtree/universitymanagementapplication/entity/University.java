package com.mindtree.universitymanagementapplication.entity;

import java.util.List;
import java.util.Set;

public class University {

	private int universityid;
	private String universityname;
	List<College> college;
	public University() {
		super();
		
	}
	public University(int universityid, String universityname, List<College> college) {
		super();
		this.universityid = universityid;
		this.universityname = universityname;
		this.college = college;
	}
	public int getUniversityid() {
		return universityid;
	}
	public void setUniversityid(int universityid) {
		this.universityid = universityid;
	}
	public String getUniversityname() {
		return universityname;
	}
	public void setUniversityname(String universityname) {
		this.universityname = universityname;
	}
	public List<College> getCollege() {
		return college;
	}
	public void setCollege(List<College> college) {
		this.college = college;
	}
	
}
