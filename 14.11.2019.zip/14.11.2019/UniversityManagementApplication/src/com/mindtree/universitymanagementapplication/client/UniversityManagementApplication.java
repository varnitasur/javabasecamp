package com.mindtree.universitymanagementapplication.client;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import com.mindtree.universitymanagementapplication.entity.College;
import com.mindtree.universitymanagementapplication.entity.University;
import com.mindtree.universitymanagementapplication.service.serviceimpl.UniversityServiceImpl;

public class UniversityManagementApplication {

	static Scanner sc=new Scanner(System.in);
	static UniversityServiceImpl us=new UniversityServiceImpl();
	public static void main(String[] args) {
		
		Set<University> universities=createuniversity();
		ArrayList colleges=createcolleges();
		
		int choice,f;
		do
		{
			System.out.println("Enter the option: 1:insert university id and name and print registration succesfull");
			choice=sc.nextInt();
			switch(choice)
			{
			
			case 1:
				boolean isInserted=us.isInsertedtodao(universities);
				if(isInserted)
				{
					System.out.println("Registration succesful");
					for (University university : universities) {
					System.out.println("=============================================");
					System.out.println("University id:"+university.getUniversityid());
					System.out.println("University id:"+university.getUniversityname());
					}
				}
				else {
					System.out.println("not inserted");
			}
				break;
				default :
					System.out.println("Invalid message");
			
			}System.out.println("press 1 to continue 0 TO EXIT");
			f=sc.nextInt();
			}while(f!=0);

	}

	private static ArrayList createcolleges() {
		// TODO Auto-generated method stub
		ArrayList result=new ArrayList<>();
		System.out.println("Enter the college count");
		int collegecount=sc.nextInt();
		for (int i = 0; i < collegecount; i++) {
			System.out.println("Enter the "+(i+1)+"th details of college");
			System.out.println("Enter the college id");
			int collegeid=sc.nextInt();
			System.out.println("Enter the college name");
			String collegename=sc.next();
			System.out.println("Enter the college rating");
			int collegerating=sc.nextInt();
			College c=new College(collegeid, collegename, collegerating);
			result.add(c);
		}
		return result;
	}

	private static Set<University> createuniversity() {
		Set<University> result=new HashSet<>();
		System.out.println("Enter the university count");
		int universitycount=sc.nextInt();
		for (int i = 0; i < universitycount; i++) {
			System.out.println("Enter the "+(i+1)+"th details of university");
			System.out.println("Enter the university id");
			int universityid=sc.nextInt();
			System.out.println("Enter the university name");
			String universityname=sc.next();
			University u=new University(universityid, universityname)b;
			result.add(u);
		}
		return result;
	}

}
