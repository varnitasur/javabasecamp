package com.mindtree.universitymanagementapplication.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.mindtree.universitymanagementapplication.entity.College;
import com.mindtree.universitymanagementapplication.entity.University;

public interface UniversityDao {

	//insert university name and university id
	boolean isInserttoDB(Set<University> universities);
	boolean isInsert(ArrayList<College> college,String universityname);
	Set<University> getuniversitiesFromDao() ;
	public List<College> returnCollege(int universityid);
	public ArrayList<College> getCollegefromDao();
	public void sendUniversitytoDB(University u);
	public List<College> getCollegeFromDaoBasedOnRating(int rating);
}
