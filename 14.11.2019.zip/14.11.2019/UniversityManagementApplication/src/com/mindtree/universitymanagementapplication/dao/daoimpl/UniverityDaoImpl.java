package com.mindtree.universitymanagementapplication.dao.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.mindtree.universitymanagementapplication.dao.UniversityDao;
import com.mindtree.universitymanagementapplication.dbutility.DBUtility;
import com.mindtree.universitymanagementapplication.entity.College;
import com.mindtree.universitymanagementapplication.entity.University;
import com.mysql.jdbc.Statement;

public class UniverityDaoImpl implements UniversityDao {

	static DBUtility obj=new DBUtility();
	@Override
	public boolean isInserttoDB(Set<University> universities) {
		Connection con=obj.getConnection();
		boolean val=false;
		int count=0;
		String query="Insert into university (university_id,university_name) values (?,?);";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			for (University university : universities) {
				ps.setInt(1, university.getUniversityid());
				ps.setString(2, university.getUniversityname());
				count++;
				ps.executeUpdate();
				}			
			if(count!= 0)
			{
				val=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return val;
	}
	
	@Override
	public boolean isInsert(ArrayList<College> college, String universityname) {
		// TODO Auto-generated method stub
		Connection con=obj.getConnection();
		boolean val=false;
		int count=0;
		String query1="select universityid from university where universityname='"+universityname+"'";
		PreparedStatement p;
		int id=0;
		try {
			p = con.prepareStatement(query1);
			ResultSet rs=p.executeQuery();
			rs.next();
			id=rs.getInt(1);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String query="Insert into College (college_id,college_name,rating,university_id) values (?,?,?,?);";
		
		try {
			PreparedStatement ps=con.prepareStatement(query);
			for (College coll : college) {
				
					ps.setInt(1, coll.getCollegeid());
					ps.setString(2, coll.getCollegename());
					ps.setInt(3, coll.getCollegerating());
					ps.setInt(4, id);
					count++;
					ps.executeUpdate();
			
				
			} 
			if(count!= 0)
			{
				val=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return val;
	}

	@Override
	public Set<University> getuniversitiesFromDao() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<College> returnCollege(int universityid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<College> getCollegefromDao() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void sendUniversitytoDB(University u) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<College> getCollegeFromDaoBasedOnRating(int rating) {
		// TODO Auto-generated method stub
		return null;
	}
		

	

}
