
public class BankDetails {

	String completeAdd;
	float distance;
	public String getCompleteAdd() {
		return completeAdd;
	}
	public void setCompleteAdd(String completeAdd) {
		this.completeAdd = completeAdd;
	}
	public float getDistance() {
		return distance;
	}
	public void setDistance(float distance) {
		this.distance = distance;
	}
	public BankDetails(String completeAdd, float distance) {
		super();
		this.completeAdd = completeAdd;
		this.distance = distance;
	}
	public BankDetails() {
	
	}
	
}
