package capability4;

import java.util.Scanner;

public class LaptopApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Laptop[] laptops=createLaptops();
		//create laptops array
		Laptop[] result=getrequiredProducts(laptops);
		//
		for (int i = 0; i < result.length; i++) {
			System.out.println((i+1)+"th details of the laptop");
			System.out.println("id :"+result[i].getId());
			System.out.println("name: "+result[i].getName());
			System.out.println("memory: "+result[i].getMemory());
		}
		//nsertionSort(laptops,)
		
	}

	

	private static Laptop[] getrequiredProducts(Laptop[] laptops) {
		int size=getsize(laptops);
		Laptop[] result=new Laptop[size];
		int temp=0;
		for (int i = 0; i < laptops.length; i++) {
			if(laptops[i].getMemory()>130) {
				result[temp]=laptops[i];
			temp++;
		}
	}		
		return result;
	}



	


	private static int getsize(Laptop[] laptops) {
		int count=0;
		for (int i = 0; i < laptops.length; i++) {
			if(laptops[i].getMemory()>130)
			count++;
		}
		return count;
	}



	private static Laptop[] createLaptops() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of laptops");
		int size=sc.nextInt();
		
		Laptop[] result=new Laptop[size];
		for (int i = 0; i < result.length; i++) {
			result[i]=new Laptop();
			System.out.println("Enter the id of laptop");
			int id=sc.nextInt();
			System.out.println("Enter the name of laptop");
			String name=sc.next();
			System.out.println("Enter the memory of the laptop");
			int memory=sc.nextInt();
			Laptop l=new Laptop(id,name,memory);
			result[i]=l;
			
		}
		return result;
		
	}

}
