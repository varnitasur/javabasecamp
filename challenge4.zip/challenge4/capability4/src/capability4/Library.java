package capability4;

public class Library {

	int id;
	String name;
	String[] Books;
	public Library(int id, String name, String[] books) {
		super();
		this.id = id;
		this.name = name;
		Books = books;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String[] getBooks() {
		return Books;
	}
	public void setBooks(String[] books) {
		Books = books;
	}
	public Library() {
		
	}
	
}
