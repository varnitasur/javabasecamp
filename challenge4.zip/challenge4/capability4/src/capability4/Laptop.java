package capability4;

public class Laptop {
	private int id;
	private String Name;
	private int memory;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getMemory() {
		return memory;
	}
	public void setMemory(int memory) {
		this.memory = memory;
	}
	public Laptop(int id, String name, int memory) {
		super();
		this.id = id;
		Name = name;
		this.memory = memory;
	}
	public Laptop() {
		
	}
	

}
