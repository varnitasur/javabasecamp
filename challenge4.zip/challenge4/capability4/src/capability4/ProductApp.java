package capability4;

import java.util.Scanner;

public class ProductApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product[] products=createProducts();
		
		Product[] result=getRequiredProduct(products);
		
		for (int i = 0; i < result.length; i++) {
			System.out.println((i+1)+"th details");
			System.out.println("id: "+result[i].getId());
			System.out.println("Name: "+result[i].getName());
			System.out.println("price: "+result[i].getPrice());
			System.out.println();
		}
		

	}

	private static Product[] getRequiredProduct(Product[] products) {
		int size=getSize(products);
		Product[] result=new Product[size];
		int temp=0;
		for (int i = 0; i <products.length; i++) {
			if(products[i].getPrice()>100) {
				result[temp]=products[i];
				temp++;
			}
			
		}
		return result;
	}

	private static int getSize(Product[] products) {
	int count=0;
	for (int i = 0; i <products.length; i++) {
		if(products[i].getPrice()>100) {
			count++;
		}
	}
	return count;
	}

	private static Product[] createProducts() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number of products");
		int size=sc.nextInt();
		
		Product[] result=new Product[size];
		for(int i=0;i<result.length;i++) {
			result[i]=new Product();
			System.out.println("Enter the id of products");
			int id=sc.nextInt();
			System.out.println("Enter the name of products");
			String name=sc.next();
			System.out.println("Enter the price of the product");
			double price=sc.nextDouble();
			//Product p=new Product(id,name,price);
			Product p=new Product();
			p.setId(id);
			p.setName(name);
			p.setPrice(price);
			result[i]=p;
		}
		return result;
	}

}
