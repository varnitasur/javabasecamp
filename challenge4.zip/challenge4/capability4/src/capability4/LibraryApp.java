package capability4;

import java.util.Scanner;

public class LibraryApp {
	
	public static Library[] insertionSort(Library[] result)
	{
			for(int j=1;j<result.length;j++)
			{
				value=result[j].getName();
				int hole=j-1;
				while((hole>-1)&&(result[hole].getName().compareTo(value)>0))
				{
					result[hole+1]=result[hole];
					hole--;
				}
				 result[hole+1]=value;
			}
		}		
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Library[] lib=createlibrary();
		//
		
		
			while(true)
			{
				System.out.println("1.Enter the details in the array\n 2.sort library array using library names\n 3.sort the library name and books");
				int option;
				System.out.println("Enter your option");
				Scanner sc=new Scanner(System.in);
				option=sc.nextInt();
				switch(option)
				{
				case 1:
				{
					Library[] result=gettherequiredproducts();
					for (int i = 0; i < result.length; i++) {
						System.out.println(result[i].getId()+" "+result[i].getName()+" "+result[i].getBooks());
						
					}
					
				}
					
					
				}
			}

	}

private static Library[] gettherequiredproducts() {
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		Library[] result=new Library[size];
		for (int i = 0; i < result.length; i++) 
		{	
			result[i].getId();
			result[i].getName();
			result[i].getBooks();
		}	
	return result;
		
}

	private static Library[] createlibrary() {
	
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of library");
		int size=sc.nextInt();
		Library[] result=new Library[size];
		for (int i = 0; i < result.length; i++) {
			result[i]=new Library();
			System.out.println("Enter the library id");
			int id=sc.nextInt();
			System.out.println("Enter the library name");
			String name=sc.next();
			System.out.print("Enter the no of books");
			String[] books=new String[sc.nextInt()];
			for (int j = 0; j < books.length; j++) {
				books[j]=sc.next();
			}
			Library l=new Library();
			l.setId(id);
			l.setName(name);
			l.setBooks(books);	
			result[i]=l;
		}
		return result;
	}
	
}	
