package com.mindtree.playerauctionapplication.service.serviceimpl;

import java.util.Set;

import com.mindtree.playerauctionapplication.dao.daoimpl.PlayerDaoImpl;
import com.mindtree.playerauctionapplication.entity.Player;
import com.mindtree.playerauctionapplication.service.PlayerService;

public class PlayerServiceImpl implements PlayerService {

	static PlayerDaoImpl obj=new PlayerDaoImpl();
	@Override
	public boolean isInsertedfromservicetodao(Set<Player> players) {
		boolean result=obj.isInserted(players);
		return result;
	}

}
