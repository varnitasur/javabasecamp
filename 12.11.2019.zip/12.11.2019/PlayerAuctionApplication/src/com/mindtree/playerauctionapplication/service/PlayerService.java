package com.mindtree.playerauctionapplication.service;

import java.util.Set;

import com.mindtree.playerauctionapplication.entity.Player;

public interface PlayerService {
	
	 boolean isInsertedfromservicetodao(Set<Player> players);
}
