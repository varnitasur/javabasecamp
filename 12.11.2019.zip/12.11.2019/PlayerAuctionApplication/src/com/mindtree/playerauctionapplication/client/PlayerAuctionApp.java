package com.mindtree.playerauctionapplication.client;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import com.mindtree.playerauctionapplication.entity.Player;
import com.mindtree.playerauctionapplication.service.serviceimpl.PlayerServiceImpl;

public class PlayerAuctionApp {

	static Scanner sc=new Scanner(System.in);
	static PlayerServiceImpl ps=new PlayerServiceImpl();
	public static void main(String[] args) {
		
		
		Set<Player> players=createplayers();
		boolean isInserted=ps.isInsertedfromservicetodao(players);
		//boolean val=sd.isInsertedfromclient(students);
		if(isInserted)
		{
			System.out.println("Inserted succesfully");
		}
		else
			System.out.println("not inserted");
	}
	

	private static Set<Player> createplayers() {
		Set<Player> result=new HashSet<>();
		System.out.println("Enter the player count");
		int playercount=sc.nextInt();
		System.out.println("Details of the 1st player");
		System.out.println("Enter the playerno");
		int playerno=sc.nextInt();
		System.out.println("Enter the playername");
		String playername=sc.next();
		System.out.println("Enter the category");
		String category=sc.next();
		System.out.println("Enter the highestscore");
		int highestscore=sc.nextInt();
		System.out.println("Enter the bestfigure");
		double bestfigure=sc.nextDouble();
		Player p=new Player(playerno, playername, category, highestscore, bestfigure);
		result.add(p);
		for (int i = 1; i < playercount; i++) {
			System.out.println("Details of the"+(i+1)+"th player");
			System.out.println("Enter the playername");
			String playername1=sc.next();
			System.out.println("Enter the category");
			String category1=sc.next();
			System.out.println("Enter the highestscore");
			int highestscore1=sc.nextInt();
			System.out.println("Enter the bestfigure");
			double bestfigure1=sc.nextDouble();
			Player p1=new Player();
			p1.setPlayername(playername1);
			p1.setCategory(category1);
			p1.setHighestscore(highestscore1);
			p1.setBestfigure(bestfigure1);
			result.add(p1);
			
		}
		return result;
	}

}
