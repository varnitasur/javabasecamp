package com.mindtree.playerauctionapplication.dao.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Set;

import com.mindtree.playerauctionapplication.dao.PlayerDao;
import com.mindtree.playerauctionapplication.dbutility.DBUtility;
import com.mindtree.playerauctionapplication.entity.Player;
import com.mindtree.playerauctionapplication.exception.daoexception.PlayerAuctionDaoException;

public class PlayerDaoImpl implements PlayerDao {

	static DBUtility obj=new DBUtility();
	@Override
	public boolean isInserted(Set<Player> players) {
		
		Connection con=obj.getConnection();
		boolean val=false;
		int count=0;
		String query="Insert into player (player_name,category,highestscore,bestfigure) values (?,?,?,?);";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			for (Player player : players){
			ps.setString(1, player.getPlayername());
			ps.setString(2, player.getCategory());
			ps.setInt(3, player.getHighestscore());
			ps.setDouble(4, player.getBestfigure());
			count++;
			ps.executeUpdate();
			}
			if(count!= 0)
			{
				val=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return val;
	}
	public boolean checkcategory(String category) throws PlayerAuctionDaoException{
		return false;
		
	}
	
}
