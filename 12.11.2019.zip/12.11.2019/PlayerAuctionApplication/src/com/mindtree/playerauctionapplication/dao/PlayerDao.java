package com.mindtree.playerauctionapplication.dao;

import java.util.Set;

import com.mindtree.playerauctionapplication.entity.Player;
import com.mindtree.playerauctionapplication.exception.daoexception.PlayerAuctionDaoException;

public interface PlayerDao {

	//insert to database from client
	boolean isInserted(Set<Player> players);
	boolean checkcategory(String category) throws PlayerAuctionDaoException;
}
