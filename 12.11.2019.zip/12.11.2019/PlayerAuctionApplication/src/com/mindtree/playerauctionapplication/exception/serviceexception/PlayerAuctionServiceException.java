package com.mindtree.playerauctionapplication.exception.serviceexception;

import com.mindtree.playerauctionapplication.exception.ApplicationException;

public class PlayerAuctionServiceException extends ApplicationException{

	public PlayerAuctionServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PlayerAuctionServiceException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public PlayerAuctionServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public PlayerAuctionServiceException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public PlayerAuctionServiceException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
