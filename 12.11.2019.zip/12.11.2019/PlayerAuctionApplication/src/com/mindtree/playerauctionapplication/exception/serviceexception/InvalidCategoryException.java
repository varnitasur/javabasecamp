package com.mindtree.playerauctionapplication.exception.serviceexception;

public class InvalidCategoryException extends PlayerAuctionServiceException {

	public InvalidCategoryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidCategoryException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public InvalidCategoryException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public InvalidCategoryException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public InvalidCategoryException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
