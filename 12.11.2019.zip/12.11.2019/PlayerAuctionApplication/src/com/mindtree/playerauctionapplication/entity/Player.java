package com.mindtree.playerauctionapplication.entity;

public class Player {
	
	private int playerno;
	private String playername;
	private String category;
	private int highestscore;
	private double bestfigure;
	
	public Player() {
		super();
		
	}
	
	public Player(int playerno, String playername, String category, int highestscore, double bestfigure) {
		super();
		this.playerno = playerno;
		this.playername = playername;
		this.category = category;
		this.highestscore = highestscore;
		this.bestfigure = bestfigure;
	}
	
	public int getPlayerno() {
		return playerno;
	}
	public void setPlayerno(int playerno) {
		this.playerno = playerno;
	}
	public String getPlayername() {
		return playername;
	}
	public void setPlayername(String playername) {
		this.playername = playername;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getHighestscore() {
		return highestscore;
	}
	public void setHighestscore(int highestscore) {
		this.highestscore = highestscore;
	}
	public double getBestfigure() {
		return bestfigure;
	}
	public void setBestfigure(double bestfigure) {
		this.bestfigure = bestfigure;
	}
	
	
	

}
