package client;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import entity.Train;
import service.serviceimpl.BookingServiceImpl;

public class BookingSystemApp {

	static BookingServiceImpl obj=new BookingServiceImpl();
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Enter the source input");
		String source=sc.next();
		System.out.println("Enter the destination input");
		String destination=sc.next();
		Set<Train> result=obj.getalldetailsfromdao(source, destination);
		for (Train train : result) {
			System.out.println("Train id:"+train.getTrainid());
			System.out.println("Train name: "+train.getTrainname());
			System.out.println("Source :"+train.getSource());
			System.out.println("Destination :"+train.getDestination());
			System.out.println("Distance :"+train.getDistance());
			System.out.println("Fare :"+train.getFare());
			
		}
		System.out.println();
		System.out.println("Enter the user id");
		int userid=sc.nextInt();
		System.out.println("Enter the train id");
		int trainid=sc.nextInt();
		int fareresult=obj.faredetailsgetfromdao(trainid, userid);
		Set<Train> result1=obj.getalldetailsfromdao(source, destination);
		for (Train train : result1) {
			
			if(fareresult==train.getFare()) 
			{   
				System.out.println("Booking Succuessfull");
				System.out.println("Train faredetails:"+fareresult);
			
			}
			else
				System.out.println("Booking invalid");
			

		}
	}

}
