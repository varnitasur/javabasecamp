package dao.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import dao.BookingDao;
import dbUtility.DBUtility;
import entity.Train;

public class BookingDaoImpl implements BookingDao {

	static DBUtility obj=new DBUtility();
	Connection con=obj.getConnection();
	@Override
	public Set<Train> getalldetailsbasedonsourceanddestionation(String source, String destination) {
		Set<Train> result=new HashSet<>();
		String query="select * from train where source='"+source+"'"+" and destination='"+destination+"'";
		ResultSet rs=null;
		try {
			PreparedStatement ps=con.prepareStatement(query);
			rs=ps.executeQuery();
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				String sourcename=rs.getString(3);
				String dest=rs.getString(4);
				int distance=rs.getInt(5);
				int fare=rs.getInt(6);
				Train t=new Train(id, name, sourcename, dest, distance,fare);
				result.add(t);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public int faredetails(int trainid, int userid) {
		int result=0;
		String query="select train.fare  from train inner join userinput on train.train_id=userinput.train_id  where train.train_id='"+trainid+"'"+" and userinput.user_id='"+userid+"';";
		ResultSet rs=null;
		try {
			Statement s=con.createStatement();
			rs=s.executeQuery(query);
			rs.next();

			result=rs.getInt("fare");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public Set<Train> sortallthebookingdetails() {
		Set<Train> result=new HashSet<>();
		int fare=0;
		List<Integer> fareresult=new ArrayList<>();
		String query="Select fare from train";
		try {
			Statement s=con.createStatement();
			ResultSet rs=s.executeQuery(query);
			while(rs.next())
			{
				fare=rs.getInt("fare");
				fareresult.add(fare);
			}
			Collections.sort(fareresult);
			
			System.out.println();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		
		return null;
	}

	
}
