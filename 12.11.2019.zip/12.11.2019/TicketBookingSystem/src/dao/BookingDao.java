package dao;

import java.util.Set;

import daoexception.BookingDaoException;
import entity.Train;

public interface BookingDao {
	
	//get all train details based on source and destination
	Set<Train> getalldetailsbasedonsourceanddestionation(String source,String destination) throws BookingDaoException;
	
	int faredetails(int trainid,int userid);
	Set<Train> sortallthebookingdetails();

}
