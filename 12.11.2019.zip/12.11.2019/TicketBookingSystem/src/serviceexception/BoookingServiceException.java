package serviceexception;

import Appexecption.AppException;

public class BoookingServiceException extends AppException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BoookingServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BoookingServiceException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public BoookingServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public BoookingServiceException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public BoookingServiceException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
