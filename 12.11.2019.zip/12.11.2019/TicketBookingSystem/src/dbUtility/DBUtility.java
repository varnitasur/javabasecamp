package dbUtility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtility {
	
	private static final String URL="jdbc:mysql://localhost:3306/bookingsystem";
	private static final String USER_NAME="root";
	private static final String PASSWORD="Welcome123";
	
	public Connection getConnection() {
		Connection result = null;

		try {
			result = DriverManager.getConnection(URL,USER_NAME , PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;
	}

}
