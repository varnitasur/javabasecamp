package service;

import java.util.Set;

import entity.Train;

public interface BookingService {
	
	Set<Train> getalldetailsfromdao(String source,String destination);
	
	int faredetailsgetfromdao(int trainid,int userid);

}
