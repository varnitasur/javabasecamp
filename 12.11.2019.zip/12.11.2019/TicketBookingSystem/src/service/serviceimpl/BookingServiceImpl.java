package service.serviceimpl;

import java.util.Set;

import dao.daoimpl.BookingDaoImpl;
import entity.Train;
import service.BookingService;

public class BookingServiceImpl implements BookingService {

	static BookingDaoImpl obj =new BookingDaoImpl();
	@Override
	public Set<Train> getalldetailsfromdao(String source, String destination) {
		Set<Train> result=obj.getalldetailsbasedonsourceanddestionation(source, destination);
		return result;
	}

	@Override
	public int faredetailsgetfromdao(int trainid, int userid) {
		int result=obj.faredetails(trainid, userid);
		return result;
	}

}
