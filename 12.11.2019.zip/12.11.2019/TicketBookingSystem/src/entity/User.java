package entity;

import java.util.List;

public class User {

	private int userid;
	private String username;
	private List<Integer> trainid;
	
	
	public User() {
		super();
	
	}


	public User(int userid, String username, List<Integer> trainid) {
		super();
		this.userid = userid;
		this.username = username;
		this.trainid = trainid;
	}


	public int getUserid() {
		return userid;
	}


	public void setUserid(int userid) {
		this.userid = userid;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public List<Integer> getTrainid() {
		return trainid;
	}


	public void setTrainid(List<Integer> trainid) {
		this.trainid = trainid;
	}
	
	
}
