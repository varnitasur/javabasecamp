package entity;

public class Train implements Comparable<Train> {

	private int trainid;
	private String trainname;
	private String source;
	private String destination;
	private int distance;
	private int fare;
	public Train() {
		super();
		
	}
	public Train(int trainid, String trainname, String source, String destination, int distance, int fare) {
		super();
		this.trainid = trainid;
		this.trainname = trainname;
		this.source = source;
		this.destination = destination;
		this.distance = distance;
		this.fare = fare;
	}
	public int getTrainid() {
		return trainid;
	}
	public void setTrainid(int trainid) {
		this.trainid = trainid;
	}
	public String getTrainname() {
		return trainname;
	}
	public void setTrainname(String trainname) {
		this.trainname = trainname;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	@Override
	public int compareTo(Train t) {
		
		return this.fare-t.fare; 
	}
	
	
}
