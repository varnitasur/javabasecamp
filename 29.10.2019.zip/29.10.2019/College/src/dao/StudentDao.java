package dao;

import java.util.Set;

import entity.Student;

public interface StudentDao {

	//get all the details of student
	Set<Student>  getallthedetailsofstudent();
	
}
