package dao.daoimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Set;

import com.mysql.jdbc.Statement;

import dao.StudentDao;
import entity.Student;

public class StudentDaoImpl implements StudentDao {

	@Override
	public Set<Student> getallthedetailsofstudent() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
