package com.entity;

import java.util.*;

public class Capability {

	int capabilityid;
	String capabilityname;
	List<String> ko;
	public int getCapabilityid() {
		return capabilityid;
	}
	public void setCapabilityid(int capabilityid) {
		this.capabilityid = capabilityid;
	}
	public String getCapabilityname() {
		return capabilityname;
	}
	public void setCapabilityname(String capabilityname) {
		this.capabilityname = capabilityname;
	}
	
	public List<String> getKo() {
		return ko;
	}
	public void setKo(List<String> ko) {
		this.ko = ko;
	}
	
	public Capability(int capabilityid, String capabilityname, List<String> ko) {
		super();
		this.capabilityid = capabilityid;
		this.capabilityname = capabilityname;
		this.ko = ko;
	}
	public Capability() {
		
	}
	
}
