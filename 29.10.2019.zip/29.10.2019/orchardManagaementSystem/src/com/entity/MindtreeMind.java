package com.entity;

public class MindtreeMind {

	int mid;
	String mindname;
	String role;
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getMindname() {
		return mindname;
	}
	public void setMindname(String mindname) {
		this.mindname = mindname;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public MindtreeMind(int mid, String mindname, String role) {
		super();
		this.mid = mid;
		this.mindname = mindname;
		this.role = role;
	}
	public MindtreeMind() {
		
	}
	public void disp(String role) {
		if(role.equals("MindtreeMind"))
		{
			System.out.println("who is ue lead?");
		}
		else if(role.equals("Lead"))
		{
			System.out.println("how many minds are there?");
		}
			
	}
	
}
