package com.entity;

import java.util.*;

public class Track {
	
	int trackid;
	String trackname;
	HashSet<Capability> h;
	HashMap<MindtreeMind,List<MindtreeMind>> h1;
	public int getTrackid() {
		return trackid;
	}
	public void setTrackid(int trackid) {
		this.trackid = trackid;
	}
	public String getTrackname() {
		return trackname;
	}
	public void setTrackname(String trackname) {
		this.trackname = trackname;
	}
	public HashSet<Capability> getH() {
		return h;
	}
	public void setH(HashSet<Capability> h) {
		this.h = h;
	}
	public HashMap<MindtreeMind, List<MindtreeMind>> getH1() {
		return h1;
	}
	public void setH1(HashMap<MindtreeMind, List<MindtreeMind>> h1) {
		this.h1 = h1;
	}
	public Track(int trackid, String trackname, HashSet<Capability> h, HashMap<MindtreeMind, List<MindtreeMind>> h1) {
		super();
		this.trackid = trackid;
		this.trackname = trackname;
		this.h = h;
		this.h1 = h1;
	}
	public Track() {
		
	}
	
	
	

}
