package com.client;

import java.util.Scanner;

public class AppMindtreeMinds {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the role ");
		String role=sc.next();
		disp(role);
		
	}

}
