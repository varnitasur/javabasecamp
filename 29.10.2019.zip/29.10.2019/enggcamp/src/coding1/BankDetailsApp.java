package coding1;

import java.util.Scanner;


public class BankDetailsApp {
	public static  Bank[] bsort(Bank b1[]) {
		Bank t;
		for( int m=0;m<b1.length;m++)
		{
			for(int j=0;j<b1.length-m-1;j++)
			{
				if(b1[j].bankid>b1[j+1].bankid)
				{
					t=b1[j];
					b1[j]=b1[j+1];
					b1[j+1]=t;
				}
			}
		}
		return b1;
	}

	public static int binarySearch(Bank b1[],int newbankid,int low,int high) {
		while(low<high) 
		{
			int mid=(low+high)/2;
			
			if(newbankid==b1[mid].bankid)
				{
				return mid;
				}
			else if(newbankid>=b1[mid].bankid) {
				
				low=mid+1;
			binarySearch(b1,newbankid,low,high);
			}
			else 
			{
				high=mid-1;
			binarySearch(b1,newbankid,low,high);
			}
		}
			return 0;
			
	}
	public static Bank[] insertion(Bank[] b1) {
		Bank bname;
		int hole;
		for(int i=1;i<b1.length;i++) {
			bname=b1[i];
			hole=i;
			while(hole>0 && b1[hole-1].BankName.compareTo(bname.BankName)>0) {
				b1[hole]=b1[hole-1];
				hole=hole-1;
			}
			b1[hole]=bname;
		}
		return b1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of bank");
		Bank[] b1=new Bank[sc.nextInt()];
		for(int i=0;i<b1.length;i++)
		{
			b1[i]=new Bank();
			System.out.println("Enter the bank id");
			int bankid=sc.nextInt();
			b1[i].setBankid(bankid);
			System.out.println("Enter the bank Name");
			String bankname=sc.next();
			b1[i].setBankName(bankname);
			System.out.println("Enter the ifsc code");
			String bankifsc=sc.next();
			b1[i].setBankIfsc(bankifsc);
			System.out.println("Enter the number of customer bank details");
			int num=sc.nextInt();
			BankDetails b[]=new BankDetails[num];
			for(int j=0;j<b.length;j++)
			{
				
				System.out.println("Enter complete Address");
				String completeAdd=sc.next();
				//b1[i].b[j].setCompleteAdd(completeAdd);
				System.out.println("Enter the distnce from metro");
				float distance=sc.nextFloat();
				//b1[i].b[j].setDistMetro(distance);
				BankDetails bank=new BankDetails(completeAdd,distance);
				b[j]=bank;
				
			}
		}
		//bubblesort
		Bank[] b2 = bsort(b1);
		System.out.println("Enter the new bank id");
		int newbankid=sc.nextInt();
		int res=binarySearch(b2,newbankid,0,b2.length);
		//printing the binary search

		System.out.println("all customers id: "+newbankid);
		for(int i=0;i<b2.length;i++)
		{
			//for(int j=0;j<b2[i].b.length;j++)
			b2[i].getData();
		}
			
	}

}
