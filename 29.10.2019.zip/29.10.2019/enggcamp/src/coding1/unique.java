package coding1;

import java.util.Scanner;

public class unique {
	public static int[] unique(int a[]) {
		int len=a.length;
		int k=0;
		int res[]=new int[len];
		for(int i=0;i<len;i++) {
			int j;
			for(j=0;j<len;j++) {
				if(i!=j && a[i]==a[j]) {
					for(int m=0;m<len;m++)
					{
						if(res[m]==a[i])
							continue;
					}
					res[k]=a[i];
					k++;
				}
				else
					continue;
			}
		}
		int output[]=new int[k];
		for(int i=0;i<k;i++)
		{
			output[i]=res[i];
			
		}
		return output;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		int n3=sc.nextInt();
		int len=n1+n2+n3;
		int arr1[]=new int[n1];
		int arr2[]=new int[n2];
		int arr3[]=new int[n3];
		int arr4[]=new int[len];
		int position=0;
		
		System.out.println("Enter the elemnts of the first array");
		for(int i=0;i<n1;i++)
		{
			arr1[i]=sc.nextInt();
		}
		System.out.println();
		System.out.println("Enter the elemts of second array");
		for(int i=0;i<n2;i++)
		{
			arr2[i]=sc.nextInt();
		}
		System.out.println("Enter the elemts of second array");
		for(int i=0;i<n3;i++)
		{
			arr3[i]=sc.nextInt();
		}
		for(int i=0;i<n1;i++)
		{
			arr4[position]=arr1[i];
			position++;
		}
		for(int i=0;i<n2;i++)
		{
			arr4[position]=arr2[i];
			position++;
		}
		for(int i=0;i<n3;i++)
		{
			arr4[position]=arr3[i];
			position++;
		}
		for(int i=0;i<len;i++)
		{
			System.out.println(" "+arr4[i]);
		}
		System.out.println("commen elemts are: ");
		int result[]=unique(arr4);
		for(int i=0;i<result.length;i++)
		
			System.out.println(" "+result[i]);
		
		
		
	}

}
