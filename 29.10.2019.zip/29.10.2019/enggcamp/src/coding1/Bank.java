package coding1;

import java.util.Arrays;

public class Bank {

	
	 int bankid;
	 String BankName;
	String bankIfsc;
	BankDetails b[];
	public int getBankid() {
		return bankid;
	}
	public void setBankid(int bankid) {
		this.bankid = bankid;
	}
	public String getBankName() {
		return BankName;
	}
	public void setBankName(String bankName) {
		BankName = bankName;
	}
	public String getBankIfsc() {
		return bankIfsc;
	}
	public void setBankIfsc(String bankIfsc) {
		this.bankIfsc = bankIfsc;
	}
	public BankDetails[] getB() {
		return b;
	}
	public void setB(BankDetails[] b) {
		this.b = b;
	}
	public Bank(int bankid, String bankName, String bankIfsc, BankDetails[] b) {
		super();
		this.bankid = bankid;
		BankName = bankName;
		this.bankIfsc = bankIfsc;
		this.b = b;
	}
	public void getData() {
		System.out.println(bankid+" "+BankName+" "+bankIfsc+" "+b);
	}
	public Bank() {
		// TODO Auto-generated constructor stub
	}
	public int compareTo(Bank bname) {
		return 0;
	}
	@Override
	public String toString() {
		return "Bank [bankid=" + bankid + ", BankName=" + BankName + ", bankIfsc=" + bankIfsc + ", b="
				+ Arrays.toString(b) + "]";
	}
}
