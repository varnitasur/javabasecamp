package coding1;

import java.util.ArrayList;
import java.util.Scanner;

public class ProductApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of products");
		int n=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the product id");
			int id=sc.nextInt();
			System.out.println("Entre the product name");
			String name=sc.next();
			System.out.println("Enter the product price");
			float price=sc.nextFloat();
			Product obj=new Product();
			obj.setId(id);
			obj.setName(name);
			obj.setPrice(price);
			
			ArrayList <Product> alProduct= new ArrayList();
			
			alProduct.add(obj);
		for(Product ob:alProduct)
		{
			System.out.println("products :");
			System.out.println("id is: "+ob.getId());
			System.out.println("name is "+ob.getName());
			System.out.println("price is : "+ob.getPrice());
		}
	}
	}
		

}
