package coding1;

import java.util.Scanner;

class Customer{
	Scanner sc=new Scanner(System.in);
	int id;
	String name;
	long mob;
	double bal;
	void setData( int id, String name, long mob, double bal) {
	
		//this.sc = sc;
		this.id = id;
		this.name = name;
		this.mob = mob;
		this.bal = bal;
	}
	void getData() {
		System.out.println(id+" "+name+" "+mob+" "+bal);
	}
	
}
class Bank{
	
}
public class BankCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
