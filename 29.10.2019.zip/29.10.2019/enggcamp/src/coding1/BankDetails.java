package coding1;

public class BankDetails {

	String completeAdd;
	float distMetro;
	
	public BankDetails(String completeAdd, float distMetro) {
		super();
		this.completeAdd = completeAdd;
		this.distMetro = distMetro;
	}

	public String getCompleteAdd() {
		return completeAdd;
	}

	public void setCompleteAdd(String completeAdd) {
		this.completeAdd = completeAdd;
	}

	public float getDistMetro() {
		return distMetro;
	}

	public void setDistMetro(float distMetro) {
		this.distMetro = distMetro;
	}

	public BankDetails() {
		// TODO Auto-generated constructor stub
	}

	
	@Override
	public String toString() {
		return "BankDetails [completeAdd=" + completeAdd + ", distMetro=" + distMetro + "]";
	}
	

}
