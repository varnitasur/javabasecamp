package collectionsprog;

import java.util.Stack;

public class StackImplementation {
	
	//pushing the element on top of Stack
	static void stack_push(Stack<Integer> stack) {
		
		for (int i = 1; i <= 5; i++) {
			 
			stack.push(i);
		}
	}
	//poping the element.
	static void stack_pop(Stack<Integer> stack) {
		
	System.out.println("pop :");	
		for(int i =1;i<=5;i++)
		{
			Integer y=(Integer)stack.pop();
			System.out.println(y);
		}
	}
	//peeking the element
	static void stack_peek(Stack<Integer> stack) {
		
		Integer element=(Integer)stack.peek();
		System.out.println("Element at the top :"+element);
	}

	//searching element
	static void stack_search(Stack<Integer> stack,int element) {
		
		Integer pos=(Integer)stack.search(element);
		if(pos == -1) 
			System.out.println("Element not found");
			else
				System.out.println("Element position :"+pos);
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<Integer> stack=new Stack<Integer>();
		stack_push(stack);
		stack_pop(stack);
		stack_push(stack);
		stack_peek(stack);
		stack_search(stack,2);
		
	}

}
