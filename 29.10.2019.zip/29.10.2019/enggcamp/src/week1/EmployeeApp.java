package week1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map.Entry;
import java.util.Scanner;

public class EmployeeApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		HashMap<String,Employee> map=new HashMap<String,Employee>();
		System.out.println("Enter the no of employee");
		int size=sc.nextInt();
		for(int i=0;i<size;i++)
		{
			System.out.println("Enter the employee id");
			String id=sc.next();
			
			if(map.containsKey(id)) {
				System.out.println("Sorry! the employee id alerady exist ");
			}
			else
			{
				System.out.println("Enter the employee name");
				String name=sc.next();
				Employee e =new Employee(id,name);
				map.put(id,e);
			}
		}
		for(Entry<String, Employee> m:map.entrySet() ) {
			System.out.println(m);
		}
		System.out.println(map.size());
		sc.close();

	}

}
