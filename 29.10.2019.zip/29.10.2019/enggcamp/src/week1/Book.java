package week1;

public class Book {
	
	private String BookName;
	private String Author;
	//private double price;
	private int price;
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookName(String bookName) {
		BookName = bookName;
	}
	public String getAuthor() {
		return Author;
	}
	public void setAuthor(String author) {
		Author = author;
	}
	
	public Book(String bookName, String author, int price) {
		super();
		BookName = bookName;
		Author = author;
		this.price = price;
	}
	public Book() {
	
	}
	/*public int compareTo(Book b) {
		return this.getPrice().compareTo(b.getPrice());
	}*/

}
