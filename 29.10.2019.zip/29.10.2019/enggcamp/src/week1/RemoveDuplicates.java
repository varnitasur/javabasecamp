package week1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Scanner;

public class RemoveDuplicates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list= new ArrayList();
		Scanner sc=new Scanner(System.in);
		System.out.println("Entre the size");
		int n=sc.nextInt();
		System.out.println("Enter the numbers");
		int a[]=new int [n];
		for(int i=0;i<n;i++)
		{
			list.add(a[i]=sc.nextInt());
		}
			System.out.println(list);
			//Collections.sort(list);
		
		LinkedHashSet<Integer> h=new LinkedHashSet<Integer>(list);
		System.out.println(h);

	}

}
