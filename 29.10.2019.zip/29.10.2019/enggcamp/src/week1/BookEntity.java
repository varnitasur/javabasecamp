package week1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;


public class BookEntity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of Books");
		int n=sc.nextInt();
		ArrayList <Book> alBook= new ArrayList();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the Book name");
			String bookName=sc.next();
			System.out.println("Entre the author name");
			String author=sc.next();
			System.out.println("Enter the product price");
			int price=sc.nextInt();
			Book obj=new Book();
			obj.setBookName(bookName);
			obj.setAuthor(author);
			obj.setPrice(price);
					
			alBook.add(obj);}
			//for(int i=0;i<n;i++) {
			//Collections.sort(alBook.get(i).getPrice());}
		
		for(Book ob:alBook)
		{
			System.out.println("books :");
			System.out.println("id is: "+ob.getBookName());
			System.out.println("name is "+ob.getAuthor());
			System.out.println("price is : "+ob.getPrice());
		}
		PriceCompare pricecompare=new PriceCompare();
		Collections.sort(alBook,pricecompare);
		System.out.println("======After sorting======");
		for(Book b:alBook )
		{
			System.out.println("books :");
			System.out.println("id is: "+b.getBookName());
			System.out.println("name is "+b.getAuthor());
			System.out.println("price is : "+b.getPrice());
		}
		
		Collections.sort(alBook,(ob1,ob2)->{
			return ob1.getBookName().compareTo(ob2.getBookName());
		});
		for(Book b1:alBook)
		{
			System.out.println(b1.getBookName()+" "+b1.getAuthor()+" "+b1.getPrice());
		}
		
			
		
	
	}

}

class PriceCompare implements Comparator<Book>{
	
	public int compare(Book b1,Book b2)
	{
		if(b1.getPrice()<b2.getPrice())
			return 1;
		else if(b1.getPrice()>b2.getPrice())
			return -1;
		else
			return 0;
	}
}
