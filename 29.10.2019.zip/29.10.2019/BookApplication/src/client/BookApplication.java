package client;

import java.util.Scanner;
import java.util.Set;
import java.util.HashSet;
import entity.Author;
import entity.Library;
import service.BookService;
import service.serviceimpl.BookServiceImpl;
import entity.Book;

public class BookApplication {

	static Scanner sc=new Scanner(System.in);
	static BookService bs=new BookServiceImpl();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//create library
		System.out.println("Enter the no of library count");
		int count=sc.nextInt();
		Set<Library> library=createlibrary(count);
		
		//ask user for the id and the list of books
		System.out.println("Enter the book id");
		int authorid=sc.nextInt();
		Set<Book> book=bs.getbookbyAuhtor(library, authorid);
		
		
		for (Book book2 : book) {
			System.out.println("Detail of Books");
			System.out.println("====================");
			System.out.println("Book ID :" + book2.getBookid());
			System.out.println("Book name :" + book2.getBookname());

			Set<Author> author = book2.getAuthor();
			for ( Author author1 : author) {
				System.out.println("Detail of Author");
				System.out.println("====================");
				System.out.println("Author ID :" + author1.getAuthorid());
				System.out.println("Author name: "+author1.getAuthorname());

			}
			//ask user for book name and book list
			
			System.out.println("Enter the author name");
			String authorname=sc.next();
			Set<Book> booklist=bs.getbookbyAuhtor(library,authorname);
			
			for (Book book3 : book) {
				System.out.println("Detail of Books");
				System.out.println("====================");
				System.out.println("Book ID :" + book3.getBookid());
				System.out.println("Book name :" + book3.getBookname());
				Set<Author> authorlist=book3.getAuthor();
				for (Author author2 : authorlist) {
					
					System.out.println("Detail of Author");
					System.out.println("====================");
					System.out.println("Author ID :" + author2.getAuthorid());
					System.out.println("Author name: "+author2.getAuthorname());

				}
			}
			
		}
		

	}

	private static Set<Library> createlibrary(int count) {
		Set<Library> result= new HashSet<>();
		for (int i = 0; i < count; i++) {
			System.out.println("Enter details for " + (i + 1) + " th Library");
			System.out.println("===========================================");
			System.out.println("Enter Library ID:");
			int id = sc.nextInt();
			System.out.println("Enter Library Name:");
			String name = sc.next();
			System.out.println("Enter Book count for this Library:");
			int bookCount = sc.nextInt();
			// create book
			Set<Book> books = createBook(bookCount);

			Library library= new Library(id, name, books);
			result.add(library);
		}

		return result;
	}

	private static Set<Book> createBook(int bookCount) {
		
		
		Set<Book> result= new HashSet<>();
		for (int i = 0; i < bookCount; i++) {
			System.out.println("Enter details for " + (i + 1) + " th Books");
			System.out.println("===========================================");
			System.out.println("Enter Book ID:");
			int id = sc.nextInt();
			System.out.println("Enter Book Name:");
			String name = sc.next();
			System.out.println("Enter Author count for this Book:");
			int authorCount = sc.nextInt();
			// create author
			Set<Author> authors = createAuthor(authorCount);

			Book book= new Book(id, name, authors);
			result.add(book);
		}

		return result;
	}

	private static Set<Author> createAuthor(int authorCount) {
		
		Set<Author> result= new HashSet<>();
		for (int i = 0; i < authorCount; i++) {
			System.out.println("Enter details for " + (i + 1) + " th Books");
			System.out.println("===========================================");
			System.out.println("Enter Author ID:");
			int id = sc.nextInt();
			System.out.println("Enter Author Name:");
			String name = sc.next();
			
			Author author=new Author(id,name);
			result.add(author);
	}
		return result;
	}



	
}
