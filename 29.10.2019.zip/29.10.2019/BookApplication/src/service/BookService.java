package service;

import java.util.Set;

import entity.Book;
import entity.Library;

public interface BookService {

	//get all Books By Author id
	Set<Book> getbookbyAuhtor(Set<Library> library,int id);
	
	//get all Books By AuthorName
	Set<Book> getbookbyAuhtor(Set<Library> library,String name);
}
