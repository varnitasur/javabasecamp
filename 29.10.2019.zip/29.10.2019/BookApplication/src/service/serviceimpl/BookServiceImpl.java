package service.serviceimpl;

import java.util.HashSet;
import java.util.Set;

import entity.Author;
import entity.Book;
import entity.Library;
import service.BookService;

public class BookServiceImpl implements BookService {

	@Override
	public Set<Book> getbookbyAuhtor(Set<Library> library, int id) {
		Set<Book> result = new HashSet<>();
		for (Library l : library) {
			
			Set<Book>books=l.getBooks();
			for (Book book : books) {
				
				Set<Author> authors=book.getAuthor();
				for (Author author : authors) {

					if (author.getAuthorid() == id) {
						result = l.getBooks();
					}
				}

			}

		}
		return result;
	}

	@Override
	public Set<Book> getbookbyAuhtor(Set<Library> library, String name) {
	
		Set<Book> result = new HashSet<>();
		for (Library l : library) {
			
			Set<Book>books=l.getBooks();
			for (Book book : books) {
				
				Set<Author> authors=book.getAuthor();
				for (Author author : authors) {

					if (author.getAuthorname().equals(name)) {
						result = l.getBooks();
					}
				}

			}

		}
		return result;
	}
	

}
