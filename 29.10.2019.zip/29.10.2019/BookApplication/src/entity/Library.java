package entity;

import java.util.Set;

public class Library {

	int libraryid;
	String libraryname;
	Set<Book> books;
	public Library(int libraryid, String libraryname, Set<Book> books) {
		super();
		this.libraryid = libraryid;
		this.libraryname = libraryname;
		this.books = books;
	}
	public int getLibraryid() {
		return libraryid;
	}
	public void setLibraryid(int libraryid) {
		this.libraryid = libraryid;
	}
	public String getLibraryname() {
		return libraryname;
	}
	public void setLibraryname(String libraryname) {
		this.libraryname = libraryname;
	}
	public Set<Book> getBooks() {
		return books;
	}
	public void setBooks(Set<Book> books) {
		this.books = books;
	}
	public Library() {
		super();
	}
	
	
}
