package entity;

import java.util.Set;

public class Book {
	
	int bookid;
	String bookname;
	Set<Author> authors;
	public Book(int bookid, String bookname, Set<Author> authors) {
		super();
		this.bookid = bookid;
		this.bookname = bookname;
		this.authors = authors;
	}
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public Set<Author> getAuthor() {
		return authors;
	}
	public void setAuthor(Set<Author> authors) {
		this.authors = authors;
	}
	public Book() {
		super();
	}
	
	

}
