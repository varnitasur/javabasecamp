package com.mindtree.service.impl;

import java.util.Set;

import com.dao.DishDao;
import com.dao.Daoimpl.DishDaoImpl;
import com.mindtree.client.DishApp;
import com.mindtree.entity.Dish;
import com.mindtree.entity.Ingredient;
import com.mindtree.service.DishService;

public class DishServiceImpl implements DishService {
	DishDao dd= new DishDaoImpl();
	//static DishApp dr=new DishApp();
	
	
	@Override
	public boolean insertDishesAfterFilteringToDao(Set<Dish> dishes) {
		boolean isInserted=false;
		Set<Ingredient> result1=dd.getAllIngredientsFromDB();
		
		for (Dish dish : dishes) {
			for (Ingredient ingredient : dish.getIngredients()) {
				if(ingredient.equals(result1)) {
					
				}
			}
		}
		
				return isInserted;
	}

	@Override
	public Set<Ingredient> getListedIngredients() {
		Set<Ingredient> result=dd.getAllIngredientsFromDB();
		return result;
	}

	

}
