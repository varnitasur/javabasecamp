package com.mindtree.service;

import java.util.List;
import java.util.Set;

import com.mindtree.entity.Dish;
import com.mindtree.entity.Ingredient;

public interface DishService {
	
	
	//method to retrieve available ingredients from dao
	Set<Ingredient>  getListedIngredients();
	
	

	boolean insertDishesAfterFilteringToDao(Set<Dish> dishes);

}
