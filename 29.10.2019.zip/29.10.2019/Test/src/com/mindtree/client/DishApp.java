package com.mindtree.client;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import com.mindtree.entity.Dish;
import com.mindtree.entity.Ingredient;
import com.mindtree.service.DishService;
import com.mindtree.service.impl.DishServiceImpl;

public class DishApp {

	static DishService ds = new DishServiceImpl();
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		
		
		Set<Ingredient> result= ds.getListedIngredients();
		for (Ingredient ingredient : result) {
			System.out.println("====================================");
			System.out.println("Ingredient id :"+ingredient.getId());
			System.out.println("Ingredient Name :"+ingredient.getName());
		}
		
		
		
		
		
		
		// create dishes and send to service
		Set<Dish> dishes = createDishes();
		
		//ds.insertDishesAfterFilteringToDao(dishes);

		// accept status from service and print
		boolean isInserted=ds.insertDishesAfterFilteringToDao(dishes);
		System.out.println("Data insertion status is "+isInserted);
	}

	private static Set<Dish> createDishes() {
		Set<Dish> result = new HashSet<>();
		System.out.println("Enter number of dishes");
		int dishCount = sc.nextInt();
		for (int i = 0; i < dishCount; i++) {
			System.out.println("Enter details for " + (i + 1) + " th dish");
			System.out.println("===========================================");
			System.out.println("Enter dish ID:");
			int id = sc.nextInt();
			System.out.println("Enter dish Name:");
			String name = sc.next();

			Set<Ingredient> ingredients = createIngredients();
			Dish d = new Dish(id, name, ingredients);
			result.add(d);
		}
		return result;
	}

	private static Set<Ingredient> createIngredients() {
		Set<Ingredient> result = new HashSet<>();
		System.out.println("Enter Ingradient count for this dish:");
		int ingedientCount = sc.nextInt();
		for (int i = 0; i < ingedientCount; i++) {
			System.out.println("Enter details for " + (i + 1) + " th ingedient");
			System.out.println("===========================================");
			System.out.println("Enter ingedient ID:");
			int id = sc.nextInt();
			System.out.println("Enter ingedient Name:");
			String name = sc.next();

			Ingredient ingredient = new Ingredient(id, name);
			result.add(ingredient);
		}
		return result;
	}

}
