package com.dao.Daoimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import com.dao.DishDao;
import com.mindtree.entity.Dish;
import com.mindtree.entity.Ingredient;

public class DishDaoImpl implements DishDao {

	private Connection getConnection() {
		Connection result = null;

		try {
			result = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Welcome123");
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;

	}

	@Override
	public Set<Ingredient> getAllIngredientsFromDB() {
		// step 1: create connection
		Connection con = getConnection();
		// step 2: create query
		String query = "SELECT * FROM INGREDIENTS;";

		// step 3: choose between Statement/PreparedStatement/CallableStatement
		Statement st = null;
		ResultSet rs = null;
		try {
			st = con.createStatement();
			// step 4: execute query
			rs = st.executeQuery(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		Set<Ingredient> ingredients = new HashSet<>();

		try {
			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				Ingredient ingredient = new Ingredient(id, name);
				ingredients.add(ingredient);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return ingredients;
	}

	@Override
	public boolean insertDishes(Set<Dish> dishes) {
		return false;
	}

}
