package com.dao;

import java.util.Set;

import com.mindtree.entity.Dish;
import com.mindtree.entity.Ingredient;

public interface DishDao {

	//getting all the list of available ingredients
	Set<Ingredient> getAllIngredientsFromDB();
	
	//insert all the list of dishes
	boolean insertDishes(Set<Dish> dishes);
	
	
}
