import java.util.Arrays;
import java.util.Set;

public class Capability {

	int capabilityid;
	String capabilityname;
	String capabilitystatus;
	Set<Observation> observation;

}
