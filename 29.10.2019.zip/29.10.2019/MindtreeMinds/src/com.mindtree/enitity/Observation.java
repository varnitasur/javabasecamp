
public class Observation {

	int obid;
	int obname;

	public int getObid() {
		return obid;
	}

	public void setObid(int obid) {
		this.obid = obid;
	}

	public int getObname() {
		return obname;
	}

	public void setObname(int obname) {
		this.obname = obname;
	}

	public Observation(int obid, int obname) {
		super();
		this.obid = obid;
		this.obname = obname;
	}

	public Observation() {

	}

}
