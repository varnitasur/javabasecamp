import java.util.Set;

public class Track {

	int trackid;
	String trackName;
	Set<Capability> capability;
	public int getTrackid() {
		return trackid;
	}
	public void setTrackid(int trackid) {
		this.trackid = trackid;
	}
	public String getTrackName() {
		return trackName;
	}
	public void setTrackName(String trackName) {
		this.trackName = trackName;
	}
	public Set<Capability> getCapability() {
		return capability;
	}
	public void setCapability(Set<Capability> capability) {
		this.capability = capability;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((capability == null) ? 0 : capability.hashCode());
		result = prime * result + ((trackName == null) ? 0 : trackName.hashCode());
		result = prime * result + trackid;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Track other = (Track) obj;
		if (capability == null) {
			if (other.capability != null)
				return false;
		} else if (!capability.equals(other.capability))
			return false;
		if (trackName == null) {
			if (other.trackName != null)
				return false;
		} else if (!trackName.equals(other.trackName))
			return false;
		if (trackid != other.trackid)
			return false;
		return true;
	}
	public Track(int trackid, String trackName, Set<Capability> capability) {
		super();
		this.trackid = trackid;
		this.trackName = trackName;
		this.capability = capability;
	}
	public Track() {
	
	}
	
	
}
