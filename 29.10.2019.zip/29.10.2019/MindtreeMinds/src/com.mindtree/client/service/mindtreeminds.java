
public interface mindtreeminds {

	//get all capabilities by track
	//get all observation by track
	Set<Capabili>
}
