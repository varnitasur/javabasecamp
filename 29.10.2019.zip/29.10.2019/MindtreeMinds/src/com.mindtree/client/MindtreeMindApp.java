package client;
import java.util.Set;


public class MindtreeMindApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//create observation
		Set<Observation> observation = createObservation();
		
		//create capabilities
		//create tracks
	}

	private static Set<Observation> createObservation() {
		Set<Observation> result;
		
		
		return null;
	}

}
