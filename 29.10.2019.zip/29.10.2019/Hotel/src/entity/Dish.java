package entity;

public class Dish {

	private int dish_id;
	private String dish_name;
	public Dish(int dish_id, String dish_name) {
		super();
		this.dish_id = dish_id;
		this.dish_name = dish_name;
	}
	public int getDish_id() {
		return dish_id;
	}
	public void setDish_id(int dish_id) {
		this.dish_id = dish_id;
	}
	public String getDish_name() {
		return dish_name;
	}
	public void setDish_name(String dish_name) {
		this.dish_name = dish_name;
	}
	public Dish() {
		super();
	}
	
}
