package service.serviceimpl;

import entity.Dish;

public class Hotelserviceimpl {
	
	public static void main(String[] arg )
	static Dish d=new Dish();
	public static Dish getD() {
		return d;
	}
	
}
