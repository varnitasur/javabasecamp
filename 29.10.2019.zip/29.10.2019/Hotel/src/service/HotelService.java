package service;

import entity.Dish;

public interface HotelService {
	
	
	
}
