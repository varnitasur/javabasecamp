package client;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import entity.Dish;

public class HotelApp {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		System.out.println("Enter the no of dish");
		int count = sc.nextInt();
		//passing dishes to dao
		Set<Dish> dishes = createDish(count);

	}

	//Method to create dishes
	private static Set<Dish> createDish(int count) {
		Set<Dish> result = new HashSet<>();
		for (int i = 0; i < count; i++) {
			System.out.println("Enter the dish id");
			int id = sc.nextInt();
			System.out.println("Enter the dish name");
			String name = sc.next();
			Dish d = new Dish();
			result.add(d);

		}
		return result;
	}

}
