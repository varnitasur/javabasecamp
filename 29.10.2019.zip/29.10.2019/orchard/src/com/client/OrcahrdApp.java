package com.client;

import java.util.Scanner;

public class OrcahrdApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		
		//input for create lead
		Set<Lead> leads=new createLeads();
		//input for creating campus minds
		//input leadid to get all campus minds
		//input lead name to get all campus minds
		
		
	}

}
