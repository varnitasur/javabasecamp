package serviceimpl;

public interface OrchardService {
	
	
	
	//get all campus minds by lead id
	
	Set<CampusMind> getCampus
	//get all campusminds by lead name
	
	//get all campusminds
	
	Set<CampusMind> getAllCampusMinds();
	

}
