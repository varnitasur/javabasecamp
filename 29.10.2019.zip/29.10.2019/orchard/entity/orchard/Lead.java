package orchard;

import java.util.Set;

public class Lead {
	//get id and name
	private int leadId;
	private String leadName;
	private Set<CampusMind> campusMinds;
	public Lead(int leadId, String leadName, Set<CampusMind> campusMinds) {
		super();
		this.leadId = leadId;
		this.leadName = leadName;
		this.campusMinds = campusMinds;
	}
	public int getLeadId() {
		return leadId;
	}
	public void setLeadId(int leadId) {
		this.leadId = leadId;
	}
	public String getLeadName() {
		return leadName;
	}
	public void setLeadName(String leadName) {
		this.leadName = leadName;
	}
	public Set<CampusMind> getCampusMinds() {
		return campusMinds;
	}
	public void setCampusMinds(Set<CampusMind> campusMinds) {
		this.campusMinds = campusMinds;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((campusMinds == null) ? 0 : campusMinds.hashCode());
		result = prime * result + leadId;
		result = prime * result + ((leadName == null) ? 0 : leadName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Lead other = (Lead) obj;
		if (campusMinds == null) {
			if (other.campusMinds != null)
				return false;
		} else if (!campusMinds.equals(other.campusMinds))
			return false;
		if (leadId != other.leadId)
			return false;
		if (leadName == null) {
			if (other.leadName != null)
				return false;
		} else if (!leadName.equals(other.leadName))
			return false;
		return true;
	}

}
