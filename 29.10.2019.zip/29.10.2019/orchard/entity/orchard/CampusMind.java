package orchard;

public class CampusMind {
	
	int campusid;
	String cname;
	String trackname;
	public int getCampusid() {
		return campusid;
	}
	public void setCampusid(int campusid) {
		this.campusid = campusid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getTrackname() {
		return trackname;
	}
	public void setTrackname(String trackname) {
		this.trackname = trackname;
	}
	public CampusMind(int campusid, String cname, String trackname) {
		super();
		this.campusid = campusid;
		this.cname = cname;
		this.trackname = trackname;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + campusid;
		result = prime * result + ((cname == null) ? 0 : cname.hashCode());
		result = prime * result + ((trackname == null) ? 0 : trackname.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CampusMind other = (CampusMind) obj;
		if (campusid != other.campusid)
			return false;
		if (cname == null) {
			if (other.cname != null)
				return false;
		} else if (!cname.equals(other.cname))
			return false;
		if (trackname == null) {
			if (other.trackname != null)
				return false;
		} else if (!trackname.equals(other.trackname))
			return false;
		return true;
	}
	public CampusMind() {

	}
	
}
