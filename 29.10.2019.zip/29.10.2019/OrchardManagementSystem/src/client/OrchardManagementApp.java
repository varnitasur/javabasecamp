package client;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import enitity.Track;

public class OrchardManagementApp {

	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//create track
		System.out.println("Enter track count:");
		int count = sc.nextInt();
		Set<Track> track=createTracks(count);

	}
	private static Set<Track> createTracks(int count) {
		Set<Track> result=new HashSet<>();
		for (int i = 0; i < count; i++) {
			
			
		}
		return null;
	}

}
