package enitity;

import java.util.List;

public class Capability {

	private int capabilityid;
	private String capabilityname;
	private List<String> ko;
	public Capability(int capabilityid, String capabilityname, List<String> ko) {
		super();
		this.capabilityid = capabilityid;
		this.capabilityname = capabilityname;
		this.ko = ko;
	}
	public int getCapabilityid() {
		return capabilityid;
	}
	public void setCapabilityid(int capabilityid) {
		this.capabilityid = capabilityid;
	}
	public String getCapabilityname() {
		return capabilityname;
	}
	public void setCapabilityname(String capabilityname) {
		this.capabilityname = capabilityname;
	}
	public List<String> getKo() {
		return ko;
	}
	public void setKo(List<String> ko) {
		this.ko = ko;
	}
	public Capability() {
		
	}
	
}
