package enitity;

public class MindtreeMind {
	
	private int mid;
	private String mindtreemindname;
	private String role;
	public MindtreeMind(int mid, String mindtreemindname, String role) {
		super();
		this.mid = mid;
		this.mindtreemindname = mindtreemindname;
		this.role = role;
	}
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getMindtreemindname() {
		return mindtreemindname;
	}
	public void setMindtreemindname(String mindtreemindname) {
		this.mindtreemindname = mindtreemindname;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public MindtreeMind() {
		
	}
	

}
