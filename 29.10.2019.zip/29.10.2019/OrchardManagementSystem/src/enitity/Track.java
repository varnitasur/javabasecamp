package enitity;

import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class Track {
	
	private int trackid;
	private String trackname;
	private Set<Capability> capabilities;
	private HashMap<MindtreeMind,List<MindtreeMind>> mindtreeminds;
	
	public Track(int trackid, String trackname, Set<Capability> capabilities,
			HashMap<MindtreeMind, List<MindtreeMind>> mindtreeminds) {
		super();
		this.trackid = trackid;
		this.trackname = trackname;
		this.capabilities = capabilities;
		this.mindtreeminds = mindtreeminds;
	}
	public int getTrackid() {
		return trackid;
	}
	public void setTrackid(int trackid) {
		this.trackid = trackid;
	}
	public String getTrackname() {
		return trackname;
	}
	public void setTrackname(String trackname) {
		this.trackname = trackname;
	}
	public Set<Capability> getCapabilities() {
		return capabilities;
	}
	public void setCapabilities(Set<Capability> capabilities) {
		this.capabilities = capabilities;
	}
	public HashMap<MindtreeMind, List<MindtreeMind>> getMindtreeminds() {
		return mindtreeminds;
	}
	public void setMindtreeminds(HashMap<MindtreeMind, List<MindtreeMind>> mindtreeminds) {
		this.mindtreeminds = mindtreeminds;
	}
	public Track() {
	
	}
	
	

}
