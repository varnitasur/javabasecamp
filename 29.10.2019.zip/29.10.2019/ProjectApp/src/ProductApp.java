import java.util.Scanner;

public class ProductApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product[] products=createProduct();
		//traverse product and get all products of the particular brand name
		System.out.println("Enter the new Brand Name");
		Scanner sc=new Scanner(System.in);
		String newBrandName=sc.next();
		Product[] result=getRequierdProducts(products,newBrandName);
		
		
		
		
		

	}

	private static Product[] getRequierdProducts(Product[] products,String newbrandName) {
		int size=getsize(products);
		Product[] result=new Product[size];	
		int temp=0;
		for (int i = 0; i < result.length; i++) {
			if(products[i].b[i].getName=newbrandName) {
				result[temp]=products[i].b[i];
				
			}
		}
		return result;
	}

	private static int getsize(Product[] products) {
		int result=0;
		for (int i = 0; i < products.length; i++) {
			if(product[i].)
		}
	}

	private static Product[] createProduct() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of products");
		int size=sc.nextInt();
		Product[] result=new Product[size];
		for (int i = 0; i < result.length; i++) {
			result[i]=new Product();
			System.out.println("Enter the product id");
			int id=sc.nextInt();
			System.out.println("Enter the product name");
			String name=sc.next();
			System.out.println("Enter the product price");
			double price=sc.nextDouble();
			System.out.println("Enter the brand name");
			Brand[] b=createBrand();
			Product p=new Product();
			p.setId(id);
			p.setName(name);
			p.setPrice(price);
			result[i]=p;
			
			
		}
		
		return result;
	}

	private static Brand[] createBrand() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of brands");
		int size=sc.nextInt();
		Brand b[]=new Brand[size];
		for (int i = 0; i < b.length; i++) {
			b[i]=new Brand();
			System.out.println("Enter the brand id");
			int id=sc.nextInt();
			System.out.println("Enter the brand name");
			String name=sc.next();
			Brand brand=new Brand();
			brand.setId(id);
			brand.setName(name);
		}
		return b;
	
	}

}
