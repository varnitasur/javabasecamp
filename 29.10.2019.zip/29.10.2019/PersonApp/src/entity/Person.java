package entity;

public class Person {

	@Override
	public String toString() {
		return "Person [personid=" + personid + ", name=" + name + ", personnumber=" + personnumber + "]";
	}
	private int personid;
	private String name;
	private long personnumber;
	public Person(int personid, String name, long personnumber) {
		super();
		this.personid = personid;
		this.name = name;
		this.personnumber = personnumber;
	}
	public Person() {
		super();
	}
	public int getPersonid() {
		return personid;
	}
	public void setPersonid(int personid) {
		this.personid = personid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPersonnumber() {
		return personnumber;
	}
	public void setPersonnumber(long personnumber) {
		this.personnumber = personnumber;
	}
	
}
