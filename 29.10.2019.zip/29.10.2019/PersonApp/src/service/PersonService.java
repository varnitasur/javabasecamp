package service;

import java.util.Set;

import entity.Person;

public interface PersonService {

	Set<Person> getAlldetailsofPersonfromDB();
	//
	Set<Person> sendTodaofromservice(Set<Person> retrievedpersons);
}
