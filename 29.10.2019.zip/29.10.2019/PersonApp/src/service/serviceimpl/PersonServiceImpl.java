package service.serviceimpl;

import java.util.Set;

import dao.PersonDao;
import dao.daoimpl.PersonDaoImpl;
import entity.Person;
import service.PersonService;

public class PersonServiceImpl implements PersonService {

	
	static PersonDao pd=new PersonDaoImpl();
	@Override
	public Set<Person> getAlldetailsofPersonfromDB() {
		Set<Person> result=pd.getallthedetailsofPersonFromDB();
		return result;
	}

	@Override
	public Set<Person> sendTodaofromservice(Set<Person> retrievedpersons) {
		Set<Person> result=pd.sendalldatatoService();
		return result;
	}
	
	
}
