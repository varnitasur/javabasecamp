package client;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import entity.Person;
import service.PersonService;
import service.serviceimpl.PersonServiceImpl;

public class PersonApp {

	static PersonService pp=new PersonServiceImpl();
	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Set<Person> persons=createPerson();
		
		
		
	/*	Set<Person> result=pp.getAlldetailsofPersonfromDB();
		for (Person person : result) {
			System.out.println("====================================");
			System.out.println("Person id :"+person.getPersonid());
			System.out.println("Person Name :"+person.getName());
			System.out.println("Person number :"+person.getPersonnumber());
		}*/
		Set<Person> persons1=pp.sendTodaofromservice(persons);
		for (Person person : persons1) {
			System.out.println(person.toString());
		}
	}
	private static Set<Person> createPerson() {
		Set<Person> result = new HashSet<>();
		System.out.println("Enter Person count :");
		int personCount = sc.nextInt();
		for (int i = 0; i < personCount; i++) {
			System.out.println("Enter details for " + (i + 1) + " th Person");
			System.out.println("===========================================");
			System.out.println("Enter Person ID:");
			int id = sc.nextInt();
			System.out.println("Enter Person Name:");
			String name = sc.next();
			System.out.println("Enter Person Number:");
			long number=sc.nextLong();
			Person person = new Person(id, name,number);
			result.add(person);
		}
		return 	result;
	}
	

}
