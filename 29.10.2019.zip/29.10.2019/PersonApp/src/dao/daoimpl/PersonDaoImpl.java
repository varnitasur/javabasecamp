package dao.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.*;
import java.util.HashSet;
import java.util.Set;

import com.mysql.jdbc.*;

import DBUtility.DBUtil;
import dao.PersonDao;
import entity.Person;

public class PersonDaoImpl implements PersonDao {

	static DBUtil dd=new DBUtil();
	 
	public Set<Person> getallthedetailsofPersonFromDB() {
		//step1: create connection
		Connection con=dd.getConnection();
		//step 2: create query
		String query="SELECT * FROM PERSON;";
		Statement st=null;
		ResultSet rs=null;
		//step 3:choose statement 
		
		try {
			st = con.createStatement();
			rs=st.executeQuery(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Set<Person> persons=new HashSet<>();
		
		try {
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				long number=rs.getLong(3);
				Person person=new Person(id,name,number);
				persons.add(person);
				
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return persons;
	}

	public void sendFromServicetoDB(Set<Person> persons) {
		Connection con = dd.getConnection();
		for (Person person : persons) {
			System.out.println("Person id:"+person.getPersonid());
			System.out.println("Person id:"+person.getName());
			
		}
		String query="Insert into person (person_id,person_name,person_number)"+"values(?,?,?);";
		
		for (Person person : persons) {
			try {
				PreparedStatement preparedstatement=con.prepareStatement(query);
				preparedstatement.setInt(1, person.getPersonid());
				preparedstatement.setString(2, person.getName());
				preparedstatement.setLong(3, person.getPersonnumber());
				
				preparedstatement.execute();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		try {
			con.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		
	}
		@Override
	public Set<Person> sendalldatatoService() {
			Set<Person> retrievedpersons=new HashSet<Person>();
			
	     Connection con=dd.getConnection();
	     try {
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("SELECT * FROM PERSON;");
			while(rs.next())
			{
				Person p=new Person(rs.getInt(1),rs.getString(2),rs.getLong(3));
				retrievedpersons.add(p);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
			
		return retrievedpersons;
	}
		
	
	}
	
	
	
	

