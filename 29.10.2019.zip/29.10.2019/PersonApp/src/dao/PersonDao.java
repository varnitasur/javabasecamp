package dao;

import java.util.Set;

import entity.Person;

public interface PersonDao {

	Set<Person> getallthedetailsofPersonFromDB();
	Set<Person> sendalldatatoService();
}
